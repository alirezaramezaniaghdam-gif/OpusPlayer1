package com.opusplayer.app

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer

/**
 * Lives for the whole app process. PlayerService attaches it to ExoPlayer's
 * real audio session as soon as playback starts, and both the Service and
 * the ViewModel/UI (same process) can read/write it directly.
 */
object AudioEffectsManager {

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var currentSessionId: Int = -1

    val isReady: Boolean get() = equalizer != null

    data class BandInfo(val index: Int, val centerFreqHz: Int, val minLevel: Short, val maxLevel: Short)

    fun attach(audioSessionId: Int) {
        if (audioSessionId == currentSessionId && equalizer != null) return
        release()
        if (audioSessionId == 0) return
        try {
            equalizer = Equalizer(0, audioSessionId).apply { enabled = true }
            bassBoost = BassBoost(0, audioSessionId).apply { enabled = true }
            currentSessionId = audioSessionId
        } catch (_: Exception) {
            equalizer = null
            bassBoost = null
        }
    }

    fun release() {
        try { equalizer?.release() } catch (_: Exception) {}
        try { bassBoost?.release() } catch (_: Exception) {}
        equalizer = null
        bassBoost = null
        currentSessionId = -1
    }

    fun getBands(): List<BandInfo> {
        val eq = equalizer ?: return emptyList()
        return (0 until eq.numberOfBands).map { i ->
            val idx = i.toShort()
            BandInfo(
                index = i,
                centerFreqHz = eq.getCenterFreq(idx) / 1000,
                minLevel = eq.bandLevelRange[0],
                maxLevel = eq.bandLevelRange[1]
            )
        }
    }

    fun getBandLevel(bandIndex: Int): Short = equalizer?.getBandLevel(bandIndex.toShort()) ?: 0

    fun setBandLevel(bandIndex: Int, level: Short) {
        try { equalizer?.setBandLevel(bandIndex.toShort(), level) } catch (_: Exception) {}
    }

    fun getPresets(): List<String> {
        val eq = equalizer ?: return emptyList()
        return (0 until eq.numberOfPresets).map { eq.getPresetName(it.toShort()) }
    }

    fun usePreset(index: Int) {
        try { equalizer?.usePreset(index.toShort()) } catch (_: Exception) {}
    }

    fun setBassBoostStrength(strength: Short) {
        try { bassBoost?.setStrength(strength) } catch (_: Exception) {}
    }

    fun getBassBoostStrength(): Short = try { bassBoost?.roundedStrength ?: 0 } catch (_: Exception) { 0 }
}
