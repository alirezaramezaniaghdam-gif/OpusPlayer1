package com.opusplayer.app

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object MusicRepository {

    /**
     * Scans MediaStore for all audio files, including .opus files which are
     * sometimes not flagged as IS_MUSIC by the system. We query broadly and
     * then rely on Media3's ExoPlayer (which bundles an Ogg/WebM extractor)
     * to actually decode Opus at playback time.
     */
    suspend fun loadTracks(context: Context): List<Track> = withContext(Dispatchers.IO) {
        val tracks = mutableListOf<Track>()

        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.DISPLAY_NAME
        )

        // No IS_MUSIC filter: some .opus files get tagged as podcasts/notifications
        // by the media scanner. We instead filter by mime-type/extension below.
        val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"

        context.contentResolver.query(collection, projection, null, null, sortOrder)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val displayName = cursor.getString(nameCol) ?: ""
                val mime = cursor.getString(mimeCol)

                val isAudioLike = mime?.startsWith("audio/") == true ||
                    displayName.endsWith(".opus", true) ||
                    displayName.endsWith(".ogg", true) ||
                    displayName.endsWith(".mp3", true) ||
                    displayName.endsWith(".m4a", true) ||
                    displayName.endsWith(".flac", true) ||
                    displayName.endsWith(".wav", true)

                if (!isAudioLike) continue

                val title = cursor.getString(titleCol) ?: displayName
                val artist = cursor.getString(artistCol) ?: "Unknown Artist"
                val album = cursor.getString(albumCol) ?: "Unknown Album"
                val duration = cursor.getLong(durationCol)
                val uri = ContentUris.withAppendedId(collection, id)

                tracks.add(Track(id, title, artist, album, duration, uri, mime))
            }
        }

        tracks
    }
}
