package com.opusplayer.app

import androidx.compose.runtime.compositionLocalOf

enum class AppLanguage { FA, EN }

data class AppStrings(
    val appName: String,
    val navSongs: String,
    val navFolders: String,
    val navPlaylists: String,
    val navSettings: String,
    val emptyLibrary: String,
    val emptyPlaylists: String,
    val emptyPlaylistDetail: String,
    val addToPlaylist: String,
    val createPlaylist: String,
    val playlistName: String,
    val create: String,
    val cancel: String,
    val close: String,
    val songsCount: String,
    val settingsTitle: String,
    val languageLabel: String,
    val persian: String,
    val english: String,
    val equalizerTitle: String,
    val equalizerEnable: String,
    val bassBoost: String,
    val presets: String,
    val sleepTimerTitle: String,
    val sleepTimerOff: String,
    val sleepTimerActive: String,
    val minutes: String,
    val foldersTitle: String,
    val backToPlaylists: String
)

val FaStrings = AppStrings(
    appName = "Opus Player",
    navSongs = "آهنگ‌ها",
    navFolders = "پوشه‌ها",
    navPlaylists = "پلی‌لیست‌ها",
    navSettings = "تنظیمات",
    emptyLibrary = "هیچ فایل صوتی‌ای پیدا نشد.\nفایل‌های mp3, opus, ogg, flac خودت رو روی گوشی کپی کن.",
    emptyPlaylists = "هنوز پلی‌لیستی نساختی.\nبا دکمه‌ی + یکی بساز!",
    emptyPlaylistDetail = "این پلی‌لیست خالیه.\nاز صفحه‌ی آهنگ‌ها، روی یه آهنگ نگه‌دار و بهش اضافه‌ش کن.",
    addToPlaylist = "افزودن به پلی‌لیست",
    createPlaylist = "پلی‌لیست جدید",
    playlistName = "اسم پلی‌لیست",
    create = "ساخت",
    cancel = "انصراف",
    close = "بستن",
    songsCount = "آهنگ",
    settingsTitle = "تنظیمات",
    languageLabel = "زبان برنامه",
    persian = "فارسی",
    english = "English",
    equalizerTitle = "اکولایزر",
    equalizerEnable = "فعال کردن اکولایزر",
    bassBoost = "تقویت بیس",
    presets = "پریست‌های آماده",
    sleepTimerTitle = "تایمر خواب",
    sleepTimerOff = "خاموش",
    sleepTimerActive = "فعال — پخش بعد از %d دقیقه دیگه متوقف میشه",
    minutes = "دقیقه",
    foldersTitle = "پوشه‌ها",
    backToPlaylists = "بازگشت"
)

val EnStrings = AppStrings(
    appName = "Opus Player",
    navSongs = "Songs",
    navFolders = "Folders",
    navPlaylists = "Playlists",
    navSettings = "Settings",
    emptyLibrary = "No audio files found.\nCopy some mp3, opus, ogg, or flac files to your phone.",
    emptyPlaylists = "You haven't made a playlist yet.\nTap + to create one!",
    emptyPlaylistDetail = "This playlist is empty.\nLong-press a song in the Songs tab to add it here.",
    addToPlaylist = "Add to playlist",
    createPlaylist = "New playlist",
    playlistName = "Playlist name",
    create = "Create",
    cancel = "Cancel",
    close = "Close",
    songsCount = "songs",
    settingsTitle = "Settings",
    languageLabel = "App language",
    persian = "فارسی",
    english = "English",
    equalizerTitle = "Equalizer",
    equalizerEnable = "Enable equalizer",
    bassBoost = "Bass boost",
    presets = "Presets",
    sleepTimerTitle = "Sleep timer",
    sleepTimerOff = "Off",
    sleepTimerActive = "Active — playback stops in %d min",
    minutes = "minutes",
    foldersTitle = "Folders",
    backToPlaylists = "Back"
)

val LocalAppStrings = compositionLocalOf { FaStrings }
val LocalAppLanguage = compositionLocalOf { AppLanguage.FA }
