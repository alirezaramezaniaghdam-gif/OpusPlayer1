package com.opusplayer.app

data class Playlist(
    val id: String,
    val name: String,
    val trackIds: MutableList<Long> = mutableListOf()
)
