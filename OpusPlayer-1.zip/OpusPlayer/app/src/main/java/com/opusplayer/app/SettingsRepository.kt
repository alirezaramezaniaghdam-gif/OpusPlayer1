package com.opusplayer.app

import android.content.Context

object SettingsRepository {
    private const val PREFS_NAME = "opus_player_settings"
    private const val KEY_LANGUAGE = "language"

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun loadLanguage(context: Context): AppLanguage {
        val value = prefs(context).getString(KEY_LANGUAGE, AppLanguage.FA.name)
        return try {
            AppLanguage.valueOf(value ?: AppLanguage.FA.name)
        } catch (_: Exception) {
            AppLanguage.FA
        }
    }

    fun saveLanguage(context: Context, language: AppLanguage) {
        prefs(context).edit().putString(KEY_LANGUAGE, language.name).apply()
    }
}
