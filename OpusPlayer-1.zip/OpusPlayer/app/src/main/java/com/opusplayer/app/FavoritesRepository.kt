package com.opusplayer.app

import android.content.Context

object FavoritesRepository {
    private const val PREFS_NAME = "opus_player_favorites"
    private const val KEY_FAVORITES = "favorite_ids"

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun loadFavorites(context: Context): Set<Long> {
        val stored = prefs(context).getStringSet(KEY_FAVORITES, emptySet()) ?: emptySet()
        return stored.mapNotNull { it.toLongOrNull() }.toSet()
    }

    fun toggleFavorite(context: Context, trackId: Long): Set<Long> {
        val current = loadFavorites(context).toMutableSet()
        if (!current.add(trackId)) {
            current.remove(trackId)
        }
        prefs(context).edit()
            .putStringSet(KEY_FAVORITES, current.map { it.toString() }.toSet())
            .apply()
        return current
    }
}
