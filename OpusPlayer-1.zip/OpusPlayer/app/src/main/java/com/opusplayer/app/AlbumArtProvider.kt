package com.opusplayer.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Loads embedded album art from audio files (works for mp3 ID3 covers,
 * flac/ogg/opus Vorbis-comment covers, m4a, etc.) and caches the decoded
 * bitmaps in memory so we don't re-read every file on every recomposition.
 */
object AlbumArtProvider {

    // Cache holds up to ~30 small cover bitmaps in memory.
    private val cache = object : LruCache<Long, Bitmap?>(30) {}

    suspend fun getArt(context: Context, track: Track): Bitmap? {
        cache.get(track.id)?.let { return it }

        return withContext(Dispatchers.IO) {
            var bitmap: Bitmap? = null
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(context, track.uri)
                val art = retriever.embeddedPicture
                if (art != null) {
                    // Downscale while decoding to keep memory usage low.
                    val options = BitmapFactory.Options().apply { inSampleSize = 2 }
                    bitmap = BitmapFactory.decodeByteArray(art, 0, art.size, options)
                }
            } catch (_: Exception) {
                // No embedded art, or file couldn't be read — fall back to icon.
            } finally {
                try {
                    retriever.release()
                } catch (_: Exception) {
                }
            }
            cache.put(track.id, bitmap)
            bitmap
        }
    }
}
