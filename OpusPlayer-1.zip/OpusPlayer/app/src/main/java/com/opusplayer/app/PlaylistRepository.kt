package com.opusplayer.app

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.util.UUID

/**
 * Simple local playlist storage backed by SharedPreferences + Gson.
 * No server/database needed — everything lives on-device.
 */
object PlaylistRepository {

    private const val PREFS_NAME = "opus_player_playlists"
    private const val KEY_PLAYLISTS = "playlists_json"

    private val gson = Gson()

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun loadPlaylists(context: Context): List<Playlist> {
        val json = prefs(context).getString(KEY_PLAYLISTS, null) ?: return emptyList()
        val type = object : TypeToken<List<Playlist>>() {}.type
        return try {
            gson.fromJson(json, type) ?: emptyList()
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun save(context: Context, playlists: List<Playlist>) {
        val json = gson.toJson(playlists)
        prefs(context).edit().putString(KEY_PLAYLISTS, json).apply()
    }

    fun createPlaylist(context: Context, name: String): List<Playlist> {
        val playlists = loadPlaylists(context).toMutableList()
        playlists.add(Playlist(id = UUID.randomUUID().toString(), name = name))
        save(context, playlists)
        return playlists
    }

    fun deletePlaylist(context: Context, playlistId: String): List<Playlist> {
        val playlists = loadPlaylists(context).filterNot { it.id == playlistId }
        save(context, playlists)
        return playlists
    }

    fun addTrackToPlaylist(context: Context, playlistId: String, trackId: Long): List<Playlist> {
        val playlists = loadPlaylists(context).map { playlist ->
            if (playlist.id == playlistId && !playlist.trackIds.contains(trackId)) {
                playlist.copy(trackIds = (playlist.trackIds + trackId).toMutableList())
            } else playlist
        }
        save(context, playlists)
        return playlists
    }

    fun removeTrackFromPlaylist(context: Context, playlistId: String, trackId: Long): List<Playlist> {
        val playlists = loadPlaylists(context).map { playlist ->
            if (playlist.id == playlistId) {
                playlist.copy(trackIds = playlist.trackIds.filterNot { it == trackId }.toMutableList())
            } else playlist
        }
        save(context, playlists)
        return playlists
    }
}
