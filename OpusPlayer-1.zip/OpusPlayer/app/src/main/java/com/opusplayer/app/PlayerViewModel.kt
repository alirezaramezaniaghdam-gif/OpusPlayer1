package com.opusplayer.app

import android.app.Application
import android.content.ComponentName
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class PlayerUiState(
    val allTracks: List<Track> = emptyList(),
    val playlists: List<Playlist> = emptyList(),
    val activeQueue: List<Track> = emptyList(),
    val activeQueueName: String = "All Songs",
    val currentIndex: Int = -1,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val isLoading: Boolean = true,
    val language: AppLanguage = AppLanguage.FA,
    val sleepTimerMinutesLeft: Int? = null,
    val equalizerReady: Boolean = false,
    val equalizerEnabled: Boolean = true,
    val bassBoostStrength: Int = 0
)

class PlayerViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(PlayerUiState())
    val uiState: StateFlow<PlayerUiState> = _uiState.asStateFlow()

    private var controller: MediaController? = null
    private var sleepTimerJob: Job? = null

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _uiState.value = _uiState.value.copy(isPlaying = isPlaying)
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val index = controller?.currentMediaItemIndex ?: -1
            _uiState.value = _uiState.value.copy(currentIndex = index)
        }
    }

    init {
        val context = application.applicationContext
        val language = SettingsRepository.loadLanguage(context)
        _uiState.value = _uiState.value.copy(language = language)

        val sessionToken = SessionToken(context, ComponentName(context, PlayerService::class.java))
        val controllerFuture = MediaController.Builder(context, sessionToken).buildAsync()
        controllerFuture.addListener({
            controller = controllerFuture.get()
            controller?.addListener(playerListener)
            loadLibrary()
            startPositionPolling()
            startEqualizerPolling()
        }, MoreExecutors.directExecutor())
    }

    private fun loadLibrary() {
        viewModelScope.launch {
            val tracks = MusicRepository.loadTracks(getApplication())
            val playlists = PlaylistRepository.loadPlaylists(getApplication())
            _uiState.value = _uiState.value.copy(
                allTracks = tracks,
                playlists = playlists,
                activeQueue = tracks,
                activeQueueName = "All Songs",
                isLoading = false
            )
            setQueue(tracks, prepare = true)
        }
    }

    private fun setQueue(tracks: List<Track>, prepare: Boolean) {
        val mediaItems = tracks.map { track ->
            MediaItem.Builder()
                .setUri(track.uri)
                .setMediaId(track.id.toString())
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(track.title)
                        .setArtist(track.artist)
                        .setAlbumTitle(track.album)
                        .build()
                )
                .build()
        }
        controller?.setMediaItems(mediaItems)
        if (prepare) controller?.prepare()
    }

    private fun startPositionPolling() {
        viewModelScope.launch {
            while (true) {
                val c = controller
                if (c != null) {
                    _uiState.value = _uiState.value.copy(
                        positionMs = c.currentPosition.coerceAtLeast(0L),
                        durationMs = c.duration.coerceAtLeast(0L),
                        currentIndex = c.currentMediaItemIndex
                    )
                }
                delay(500)
            }
        }
    }

    /** The equalizer only becomes attachable once ExoPlayer has an audio session, so poll briefly until ready. */
    private fun startEqualizerPolling() {
        viewModelScope.launch {
            while (!AudioEffectsManager.isReady) {
                delay(300)
            }
            _uiState.value = _uiState.value.copy(
                equalizerReady = true,
                bassBoostStrength = AudioEffectsManager.getBassBoostStrength().toInt()
            )
        }
    }

    private fun switchQueueAndPlay(queueName: String, tracks: List<Track>, index: Int) {
        val state = _uiState.value
        if (state.activeQueueName != queueName || state.activeQueue != tracks) {
            setQueue(tracks, prepare = false)
            _uiState.value = state.copy(activeQueue = tracks, activeQueueName = queueName)
        }
        controller?.seekTo(index, 0L)
        controller?.play()
    }

    fun playFromAllSongs(index: Int) {
        switchQueueAndPlay("All Songs", _uiState.value.allTracks, index)
    }

    fun playFromPlaylist(playlist: Playlist, index: Int) {
        val tracks = playlist.trackIds.mapNotNull { id -> _uiState.value.allTracks.find { it.id == id } }
        switchQueueAndPlay(playlist.name, tracks, index)
    }

    fun playFromFolder(folderName: String, tracks: List<Track>, index: Int) {
        switchQueueAndPlay(folderName, tracks, index)
    }

    fun togglePlayPause() {
        controller?.let {
            if (it.isPlaying) it.pause() else it.play()
        }
    }

    fun next() {
        controller?.seekToNextMediaItem()
    }

    fun previous() {
        controller?.seekToPreviousMediaItem()
    }

    fun seekTo(positionMs: Long) {
        controller?.seekTo(positionMs)
    }

    // --- Playlist management ---

    fun createPlaylist(name: String) {
        if (name.isBlank()) return
        val updated = PlaylistRepository.createPlaylist(getApplication(), name.trim())
        _uiState.value = _uiState.value.copy(playlists = updated)
    }

    fun deletePlaylist(playlistId: String) {
        val updated = PlaylistRepository.deletePlaylist(getApplication(), playlistId)
        _uiState.value = _uiState.value.copy(playlists = updated)
    }

    fun addTrackToPlaylist(playlistId: String, trackId: Long) {
        val updated = PlaylistRepository.addTrackToPlaylist(getApplication(), playlistId, trackId)
        _uiState.value = _uiState.value.copy(playlists = updated)
    }

    fun removeTrackFromPlaylist(playlistId: String, trackId: Long) {
        val updated = PlaylistRepository.removeTrackFromPlaylist(getApplication(), playlistId, trackId)
        _uiState.value = _uiState.value.copy(playlists = updated)
    }

    // --- Settings: language ---

    fun setLanguage(language: AppLanguage) {
        SettingsRepository.saveLanguage(getApplication(), language)
        _uiState.value = _uiState.value.copy(language = language)
    }

    // --- Sleep timer ---

    fun setSleepTimer(minutes: Int?) {
        sleepTimerJob?.cancel()
        if (minutes == null) {
            _uiState.value = _uiState.value.copy(sleepTimerMinutesLeft = null)
            return
        }
        _uiState.value = _uiState.value.copy(sleepTimerMinutesLeft = minutes)
        sleepTimerJob = viewModelScope.launch {
            var remaining = minutes
            while (remaining > 0) {
                delay(60_000L)
                remaining -= 1
                _uiState.value = _uiState.value.copy(sleepTimerMinutesLeft = remaining)
            }
            controller?.pause()
            _uiState.value = _uiState.value.copy(sleepTimerMinutesLeft = null)
        }
    }

    fun cancelSleepTimer() = setSleepTimer(null)

    // --- Equalizer ---

    fun equalizerBands() = AudioEffectsManager.getBands()

    fun getBandLevel(index: Int) = AudioEffectsManager.getBandLevel(index)

    fun setBandLevel(index: Int, level: Short) {
        AudioEffectsManager.setBandLevel(index, level)
    }

    fun equalizerPresets() = AudioEffectsManager.getPresets()

    fun useEqualizerPreset(index: Int) {
        AudioEffectsManager.usePreset(index)
    }

    fun setBassBoost(strength: Int) {
        AudioEffectsManager.setBassBoostStrength(strength.toShort())
        _uiState.value = _uiState.value.copy(bassBoostStrength = strength)
    }

    override fun onCleared() {
        controller?.removeListener(playerListener)
        controller?.release()
        controller = null
        super.onCleared()
    }
}
