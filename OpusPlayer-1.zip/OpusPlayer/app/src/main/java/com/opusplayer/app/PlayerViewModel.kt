package com.opusplayer.app

import android.app.Application
import android.content.ComponentName
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class PlayerUiState(
    val allTracks: List<Track> = emptyList(),
    val playlists: List<Playlist> = emptyList(),
    val activeQueue: List<Track> = emptyList(),
    val activeQueueName: String = "All Songs",
    val currentIndex: Int = -1,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val isLoading: Boolean = true
)

class PlayerViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(PlayerUiState())
    val uiState: StateFlow<PlayerUiState> = _uiState.asStateFlow()

    private var controller: MediaController? = null

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _uiState.value = _uiState.value.copy(isPlaying = isPlaying)
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val index = controller?.currentMediaItemIndex ?: -1
            _uiState.value = _uiState.value.copy(currentIndex = index)
        }
    }

    init {
        val context = application.applicationContext
        val sessionToken = SessionToken(context, ComponentName(context, PlayerService::class.java))
        val controllerFuture = MediaController.Builder(context, sessionToken).buildAsync()
        controllerFuture.addListener({
            controller = controllerFuture.get()
            controller?.addListener(playerListener)
            loadLibrary()
            startPositionPolling()
        }, MoreExecutors.directExecutor())
    }

    private fun loadLibrary() {
        viewModelScope.launch {
            val tracks = MusicRepository.loadTracks(getApplication())
            val playlists = PlaylistRepository.loadPlaylists(getApplication())
            _uiState.value = _uiState.value.copy(
                allTracks = tracks,
                playlists = playlists,
                activeQueue = tracks,
                activeQueueName = "All Songs",
                isLoading = false
            )
            setQueue(tracks, prepare = true)
        }
    }

    private fun setQueue(tracks: List<Track>, prepare: Boolean) {
        val mediaItems = tracks.map { track ->
            MediaItem.Builder()
                .setUri(track.uri)
                .setMediaId(track.id.toString())
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(track.title)
                        .setArtist(track.artist)
                        .setAlbumTitle(track.album)
                        .build()
                )
                .build()
        }
        controller?.setMediaItems(mediaItems)
        if (prepare) controller?.prepare()
    }

    private fun startPositionPolling() {
        viewModelScope.launch {
            while (true) {
                val c = controller
                if (c != null) {
                    _uiState.value = _uiState.value.copy(
                        positionMs = c.currentPosition.coerceAtLeast(0L),
                        durationMs = c.duration.coerceAtLeast(0L),
                        currentIndex = c.currentMediaItemIndex
                    )
                }
                delay(500)
            }
        }
    }

    /** Switch playback queue to "All Songs" and play the tapped index. */
    fun playFromAllSongs(index: Int) {
        val state = _uiState.value
        if (state.activeQueueName != "All Songs") {
            setQueue(state.allTracks, prepare = false)
            _uiState.value = state.copy(activeQueue = state.allTracks, activeQueueName = "All Songs")
        }
        controller?.seekTo(index, 0L)
        controller?.play()
    }

    /** Switch playback queue to a specific playlist and play the tapped index. */
    fun playFromPlaylist(playlist: Playlist, index: Int) {
        val state = _uiState.value
        val queueTracks = playlist.trackIds.mapNotNull { id -> state.allTracks.find { it.id == id } }
        setQueue(queueTracks, prepare = false)
        _uiState.value = state.copy(activeQueue = queueTracks, activeQueueName = playlist.name)
        controller?.seekTo(index, 0L)
        controller?.play()
    }

    fun togglePlayPause() {
        controller?.let {
            if (it.isPlaying) it.pause() else it.play()
        }
    }

    fun next() {
        controller?.seekToNextMediaItem()
    }

    fun previous() {
        controller?.seekToPreviousMediaItem()
    }

    fun seekTo(positionMs: Long) {
        controller?.seekTo(positionMs)
    }

    // --- Playlist management ---

    fun createPlaylist(name: String) {
        if (name.isBlank()) return
        val updated = PlaylistRepository.createPlaylist(getApplication(), name.trim())
        _uiState.value = _uiState.value.copy(playlists = updated)
    }

    fun deletePlaylist(playlistId: String) {
        val updated = PlaylistRepository.deletePlaylist(getApplication(), playlistId)
        _uiState.value = _uiState.value.copy(playlists = updated)
    }

    fun addTrackToPlaylist(playlistId: String, trackId: Long) {
        val updated = PlaylistRepository.addTrackToPlaylist(getApplication(), playlistId, trackId)
        _uiState.value = _uiState.value.copy(playlists = updated)
    }

    fun removeTrackFromPlaylist(playlistId: String, trackId: Long) {
        val updated = PlaylistRepository.removeTrackFromPlaylist(getApplication(), playlistId, trackId)
        _uiState.value = _uiState.value.copy(playlists = updated)
    }

    override fun onCleared() {
        controller?.removeListener(playerListener)
        controller?.release()
        controller = null
        super.onCleared()
    }
}
