package com.opusplayer.app

import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * Foreground service that hosts the ExoPlayer instance and exposes it through
 * a MediaSession so the OS media notification, lock screen controls,
 * Bluetooth/headset buttons, and Android Auto all work automatically.
 *
 * ExoPlayer ships with an Ogg extractor that decodes Opus audio natively
 * (both .opus and .ogg containers), so no extra codec setup is required.
 */
class PlayerService : MediaSessionService() {

    private var mediaSession: MediaSession? = null

    override fun onCreate() {
        super.onCreate()

        val player = ExoPlayer.Builder(this)
            .setHandleAudioBecomingNoisy(true)
            .build()

        player.repeatMode = Player.REPEAT_MODE_OFF

        // Attach the real equalizer/bass-boost effects to this player's audio
        // session as soon as one exists, and re-attach if it ever changes.
        if (player.audioSessionId != 0) {
            AudioEffectsManager.attach(player.audioSessionId)
        }
        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                AudioEffectsManager.attach(audioSessionId)
            }
        })

        mediaSession = MediaSession.Builder(this, player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onDestroy() {
        AudioEffectsManager.release()
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        super.onDestroy()
    }
}
