package com.opusplayer.app

import android.content.Intent
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * Foreground service that hosts the ExoPlayer instance and exposes it through
 * a MediaSession so the OS media notification, lock screen controls,
 * Bluetooth/headset buttons, and Android Auto all work automatically.
 *
 * ExoPlayer ships with an Ogg extractor that decodes Opus audio natively
 * (both .opus and .ogg containers), so no extra codec setup is required.
 *
 * It also keeps the home-screen widget (PlayerWidgetProvider) in sync, and
 * handles the widget's play/pause/next/prev button taps directly since the
 * widget can't hold a MediaController of its own.
 */
class PlayerService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private var player: ExoPlayer? = null

    override fun onCreate() {
        super.onCreate()

        val exoPlayer = ExoPlayer.Builder(this)
            .setHandleAudioBecomingNoisy(true)
            .build()
        player = exoPlayer

        exoPlayer.repeatMode = Player.REPEAT_MODE_ALL

        if (exoPlayer.audioSessionId != 0) {
            AudioEffectsManager.attach(exoPlayer.audioSessionId)
        }

        exoPlayer.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                AudioEffectsManager.attach(audioSessionId)
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                pushWidgetUpdate()
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                pushWidgetUpdate()
            }
        })

        mediaSession = MediaSession.Builder(this, exoPlayer).build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            PlayerWidgetProvider.ACTION_PLAY_PAUSE -> {
                player?.let { if (it.isPlaying) it.pause() else it.play() }
                return START_STICKY
            }
            PlayerWidgetProvider.ACTION_NEXT -> {
                player?.seekToNextMediaItem()
                return START_STICKY
            }
            PlayerWidgetProvider.ACTION_PREV -> {
                player?.seekToPreviousMediaItem()
                return START_STICKY
            }
        }
        return super.onStartCommand(intent, flags, startId)
    }

    private fun pushWidgetUpdate() {
        val p = player ?: return
        val metadata = p.currentMediaItem?.mediaMetadata
        val title = metadata?.title?.toString() ?: "Opus Player"
        val artist = metadata?.artist?.toString() ?: ""
        PlayerWidgetProvider.updateAll(this, title, artist, p.isPlaying)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onDestroy() {
        AudioEffectsManager.release()
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        super.onDestroy()
    }
}
