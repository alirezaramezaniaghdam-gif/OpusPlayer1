package com.opusplayer.app

import android.net.Uri

data class Track(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val uri: Uri,
    val mimeType: String?
) {
    val isOpus: Boolean
        get() = mimeType?.contains("opus", ignoreCase = true) == true ||
            title.endsWith(".opus", ignoreCase = true)
}
