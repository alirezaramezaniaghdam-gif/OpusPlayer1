package com.opusplayer.app.ui.theme

import androidx.compose.ui.graphics.Color

val PurpleAccent = Color(0xFF8A2BE2)
val BackgroundDark = Color(0xFF121212)
val SurfaceDark = Color(0xFF1E1E1E)
val TextPrimary = Color(0xFFF5F5F5)
val TextSecondary = Color(0xFFA0A0A0)
