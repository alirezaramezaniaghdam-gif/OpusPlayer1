package com.opusplayer.app

import android.Manifest
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.opusplayer.app.ui.theme.OpusPlayerTheme
import com.opusplayer.app.ui.theme.PurpleAccent
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {

    private val viewModel: PlayerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        startService(Intent(this, PlayerService::class.java))

        setContent {
            OpusPlayerTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    RequestAudioPermission()
                    RootScreen(viewModel)
                }
            }
        }
    }
}

@Composable
fun RequestAudioPermission() {
    val permission = if (Build.VERSION.SDK_INT >= 33) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    LaunchedEffect(Unit) {
        launcher.launch(permission)
    }
}

private sealed class Screen {
    object AllSongs : Screen()
    object Playlists : Screen()
    data class PlaylistDetail(val playlistId: String) : Screen()
}

@Composable
fun RootScreen(viewModel: PlayerViewModel) {
    val state by viewModel.uiState.collectAsState()
    var screen by remember { mutableStateOf<Screen>(Screen.AllSongs) }
    var addToPlaylistTrack by remember { mutableStateOf<Track?>(null) }
    var showCreatePlaylistDialog by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        TopBar()

        Box(modifier = Modifier.weight(1f)) {
            when (val s = screen) {
                is Screen.AllSongs -> {
                    when {
                        state.isLoading -> LoadingView()
                        state.allTracks.isEmpty() -> EmptyView()
                        else -> TrackList(
                            tracks = state.allTracks,
                            currentIndex = if (state.activeQueueName == "All Songs") state.currentIndex else -1,
                            onTrackClick = { index -> viewModel.playFromAllSongs(index) },
                            onTrackLongClick = { track -> addToPlaylistTrack = track }
                        )
                    }
                }
                is Screen.Playlists -> PlaylistsScreen(
                    playlists = state.playlists,
                    onCreateClick = { showCreatePlaylistDialog = true },
                    onOpenPlaylist = { playlist -> screen = Screen.PlaylistDetail(playlist.id) },
                    onDeletePlaylist = { viewModel.deletePlaylist(it) }
                )
                is Screen.PlaylistDetail -> {
                    val playlist = state.playlists.find { it.id == s.playlistId }
                    if (playlist == null) {
                        screen = Screen.Playlists
                    } else {
                        val playlistTracks = playlist.trackIds.mapNotNull { id -> state.allTracks.find { it.id == id } }
                        PlaylistDetailScreen(
                            playlist = playlist,
                            tracks = playlistTracks,
                            currentIndex = if (state.activeQueueName == playlist.name) state.currentIndex else -1,
                            onBack = { screen = Screen.Playlists },
                            onTrackClick = { index -> viewModel.playFromPlaylist(playlist, index) },
                            onRemoveTrack = { trackId -> viewModel.removeTrackFromPlaylist(playlist.id, trackId) }
                        )
                    }
                }
            }
        }

        if (state.currentIndex in state.activeQueue.indices) {
            NowPlayingBar(
                track = state.activeQueue[state.currentIndex],
                isPlaying = state.isPlaying,
                positionMs = state.positionMs,
                durationMs = state.durationMs,
                onPlayPause = { viewModel.togglePlayPause() },
                onNext = { viewModel.next() },
                onPrevious = { viewModel.previous() },
                onSeek = { viewModel.seekTo(it) }
            )
        }

        BottomNavBar(
            currentScreen = screen,
            onSelectAllSongs = { screen = Screen.AllSongs },
            onSelectPlaylists = { screen = Screen.Playlists }
        )
    }

    addToPlaylistTrack?.let { track ->
        AddToPlaylistDialog(
            track = track,
            playlists = state.playlists,
            onDismiss = { addToPlaylistTrack = null },
            onToggle = { playlistId, alreadyIn ->
                if (alreadyIn) viewModel.removeTrackFromPlaylist(playlistId, track.id)
                else viewModel.addTrackToPlaylist(playlistId, track.id)
            },
            onCreateNew = { showCreatePlaylistDialog = true }
        )
    }

    if (showCreatePlaylistDialog) {
        CreatePlaylistDialog(
            onDismiss = { showCreatePlaylistDialog = false },
            onCreate = { name ->
                viewModel.createPlaylist(name)
                showCreatePlaylistDialog = false
            }
        )
    }
}

@Composable
fun BottomNavBar(
    currentScreen: Screen,
    onSelectAllSongs: () -> Unit,
    onSelectPlaylists: () -> Unit
) {
    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
        NavigationBarItem(
            selected = currentScreen is Screen.AllSongs,
            onClick = onSelectAllSongs,
            icon = { Icon(Icons.Filled.LibraryMusic, contentDescription = null) },
            label = { Text("آهنگ‌ها") },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = PurpleAccent, indicatorColor = PurpleAccent.copy(alpha = 0.2f))
        )
        NavigationBarItem(
            selected = currentScreen is Screen.Playlists || currentScreen is Screen.PlaylistDetail,
            onClick = onSelectPlaylists,
            icon = { Icon(Icons.Filled.QueueMusic, contentDescription = null) },
            label = { Text("پلی‌لیست‌ها") },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = PurpleAccent, indicatorColor = PurpleAccent.copy(alpha = 0.2f))
        )
    }
}

@Composable
fun TopBar() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.GraphicEq, contentDescription = null, tint = PurpleAccent)
        Spacer(modifier = Modifier.width(10.dp))
        Text("Opus Player", style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
fun LoadingView() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = PurpleAccent)
    }
}

@Composable
fun EmptyView() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(
            "هیچ فایل صوتی‌ای پیدا نشد.\nفایل‌های mp3/opus/ogg/flac خودت رو روی گوشی کپی کن.",
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(32.dp)
        )
    }
}

@Composable
fun TrackList(
    tracks: List<Track>,
    currentIndex: Int,
    onTrackClick: (Int) -> Unit,
    onTrackLongClick: (Track) -> Unit
) {
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(tracks.size) { index ->
            val track = tracks[index]
            TrackRow(
                track = track,
                isCurrent = index == currentIndex,
                onClick = { onTrackClick(index) },
                onLongClick = { onTrackLongClick(track) }
            )
        }
    }
}

@Composable
fun TrackRow(
    track: Track,
    isCurrent: Boolean,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null
) {
    val context = LocalContext.current
    var artwork by remember(track.id) { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(track.id) {
        artwork = AlbumArtProvider.getArt(context, track)
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick,
                onLongClick = onLongClick
            )
            .background(if (isCurrent) PurpleAccent.copy(alpha = 0.15f) else Color.Transparent)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color.DarkGray),
            contentAlignment = Alignment.Center
        ) {
            val art = artwork
            if (art != null) {
                Image(
                    bitmap = art.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(
                    imageVector = if (isCurrent) Icons.Filled.Equalizer else Icons.Filled.MusicNote,
                    contentDescription = null,
                    tint = if (isCurrent) PurpleAccent else Color.Gray,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                track.title,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                track.artist,
                style = MaterialTheme.typography.bodySmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (track.isOpus) {
            OpusBadge()
        }
        trailing?.invoke()
    }
}

@Composable
fun OpusBadge() {
    Box(
        modifier = Modifier
            .background(PurpleAccent, shape = MaterialTheme.shapes.small)
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text("OPUS", color = Color.White, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun PlaylistsScreen(
    playlists: List<Playlist>,
    onCreateClick: () -> Unit,
    onOpenPlaylist: (Playlist) -> Unit,
    onDeletePlaylist: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("پلی‌لیست‌های من", style = MaterialTheme.typography.titleMedium)
            FilledTonalIconButton(
                onClick = onCreateClick,
                colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = PurpleAccent)
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Create playlist")
            }
        }

        if (playlists.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "هنوز پلی‌لیستی نساختی.\nبا دکمه‌ی + یکی بساز!",
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(32.dp)
                )
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(playlists.size) { index ->
                    val playlist = playlists[index]
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenPlaylist(playlist) }
                            .padding(horizontal = 20.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(PurpleAccent.copy(alpha = 0.25f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.QueueMusic, contentDescription = null, tint = PurpleAccent)
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(playlist.name, style = MaterialTheme.typography.titleMedium)
                            Text(
                                "${playlist.trackIds.size} آهنگ",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        IconButton(onClick = { onDeletePlaylist(playlist.id) }) {
                            Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete", tint = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PlaylistDetailScreen(
    playlist: Playlist,
    tracks: List<Track>,
    currentIndex: Int,
    onBack: () -> Unit,
    onTrackClick: (Int) -> Unit,
    onRemoveTrack: (Long) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(playlist.name, style = MaterialTheme.typography.titleMedium)
        }

        if (tracks.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "این پلی‌لیست خالیه.\nاز صفحه‌ی آهنگ‌ها، روی یه آهنگ نگه‌دار و بهش اضافه‌ش کن.",
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(32.dp)
                )
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(tracks.size) { index ->
                    val track = tracks[index]
                    TrackRow(
                        track = track,
                        isCurrent = index == currentIndex,
                        onClick = { onTrackClick(index) },
                        trailing = {
                            IconButton(onClick = { onRemoveTrack(track.id) }) {
                                Icon(Icons.Filled.Close, contentDescription = "Remove", tint = Color.Gray)
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun AddToPlaylistDialog(
    track: Track,
    playlists: List<Playlist>,
    onDismiss: () -> Unit,
    onToggle: (playlistId: String, alreadyIn: Boolean) -> Unit,
    onCreateNew: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("افزودن به پلی‌لیست") },
        text = {
            Column {
                Text(track.title, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(modifier = Modifier.height(12.dp))
                if (playlists.isEmpty()) {
                    Text("هنوز پلی‌لیستی نداری.", style = MaterialTheme.typography.bodyMedium)
                } else {
                    playlists.forEach { playlist ->
                        val alreadyIn = playlist.trackIds.contains(track.id)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onToggle(playlist.id, alreadyIn) }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = alreadyIn,
                                onCheckedChange = { onToggle(playlist.id, alreadyIn) },
                                colors = CheckboxDefaults.colors(checkedColor = PurpleAccent)
                            )
                            Text(playlist.name)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                TextButton(onClick = onCreateNew) {
                    Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ساخت پلی‌لیست جدید")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("بستن") }
        }
    )
}

@Composable
fun CreatePlaylistDialog(onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("پلی‌لیست جدید") },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("اسم پلی‌لیست") },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = PurpleAccent)
            )
        },
        confirmButton = {
            TextButton(onClick = { onCreate(name) }, enabled = name.isNotBlank()) {
                Text("ساخت")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("انصراف") }
        }
    )
}

@Composable
fun NowPlayingBar(
    track: Track,
    isPlaying: Boolean,
    positionMs: Long,
    durationMs: Long,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Long) -> Unit
) {
    val context = LocalContext.current
    var artwork by remember(track.id) { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(track.id) {
        artwork = AlbumArtProvider.getArt(context, track)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.DarkGray),
                contentAlignment = Alignment.Center
            ) {
                val art = artwork
                if (art != null) {
                    Image(
                        bitmap = art.asImageBitmap(),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(Icons.Filled.MusicNote, contentDescription = null, tint = Color.Gray)
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(track.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(track.artist, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Slider(
            value = if (durationMs > 0) positionMs.toFloat() / durationMs.toFloat() else 0f,
            onValueChange = { fraction -> onSeek((fraction * durationMs).toLong()) },
            colors = SliderDefaults.colors(thumbColor = PurpleAccent, activeTrackColor = PurpleAccent)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(formatTime(positionMs), style = MaterialTheme.typography.bodySmall)
            Text(formatTime(durationMs), style = MaterialTheme.typography.bodySmall)
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onPrevious) {
                Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous", modifier = Modifier.size(36.dp))
            }
            Spacer(modifier = Modifier.width(16.dp))
            FilledIconButton(
                onClick = onPlayPause,
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = PurpleAccent),
                modifier = Modifier.size(56.dp)
            ) {
                Icon(
                    if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = "Play/Pause",
                    modifier = Modifier.size(32.dp)
                )
            }
            Spacer(modifier = Modifier.width(16.dp))
            IconButton(onClick = onNext) {
                Icon(Icons.Filled.SkipNext, contentDescription = "Next", modifier = Modifier.size(36.dp))
            }
        }
    }
}

fun formatTime(ms: Long): String {
    if (ms <= 0) return "0:00"
    val minutes = TimeUnit.MILLISECONDS.toMinutes(ms)
    val seconds = TimeUnit.MILLISECONDS.toSeconds(ms) % 60
    return String.format("%d:%02d", minutes, seconds)
}
