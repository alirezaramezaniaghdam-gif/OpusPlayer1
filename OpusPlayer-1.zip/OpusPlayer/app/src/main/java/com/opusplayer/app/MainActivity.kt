package com.opusplayer.app

import android.Manifest
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.opusplayer.app.ui.theme.OpusPlayerTheme
import com.opusplayer.app.ui.theme.PurpleAccent
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {

    private val viewModel: PlayerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        startService(Intent(this, PlayerService::class.java))

        setContent {
            OpusPlayerTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    RequestAudioPermission()
                    val state by viewModel.uiState.collectAsState()
                    val strings = if (state.language == AppLanguage.FA) FaStrings else EnStrings
                    val direction = if (state.language == AppLanguage.FA) LayoutDirection.Rtl else LayoutDirection.Ltr

                    CompositionLocalProvider(
                        LocalAppStrings provides strings,
                        LocalAppLanguage provides state.language,
                        LocalLayoutDirection provides direction
                    ) {
                        RootScreen(viewModel)
                    }
                }
            }
        }
    }
}

@Composable
fun RequestAudioPermission() {
    val permission = if (Build.VERSION.SDK_INT >= 33) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    LaunchedEffect(Unit) {
        launcher.launch(permission)
    }
}

private sealed class Screen {
    data object AllSongs : Screen()
    data object Folders : Screen()
    data object Playlists : Screen()
    data object Settings : Screen()
    data class FolderDetail(val folderName: String) : Screen()
    data class PlaylistDetail(val playlistId: String) : Screen()
}

@Composable
fun RootScreen(viewModel: PlayerViewModel) {
    val state by viewModel.uiState.collectAsState()
    val strings = LocalAppStrings.current
    var screen by remember { mutableStateOf<Screen>(Screen.AllSongs) }
    var addToPlaylistTrack by remember { mutableStateOf<Track?>(null) }
    var showCreatePlaylistDialog by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        TopBar(title = strings.appName)

        Box(modifier = Modifier.weight(1f)) {
            when (val s = screen) {
                is Screen.AllSongs -> {
                    when {
                        state.isLoading -> LoadingView()
                        state.allTracks.isEmpty() -> EmptyView(strings.emptyLibrary)
                        else -> TrackList(
                            tracks = state.allTracks,
                            currentIndex = if (state.activeQueueName == "All Songs") state.currentIndex else -1,
                            onTrackClick = { index -> viewModel.playFromAllSongs(index) },
                            onTrackLongClick = { track -> addToPlaylistTrack = track }
                        )
                    }
                }
                is Screen.Folders -> FoldersScreen(
                    tracks = state.allTracks,
                    onOpenFolder = { folderName -> screen = Screen.FolderDetail(folderName) }
                )
                is Screen.FolderDetail -> {
                    val tracksInFolder = state.allTracks.filter { it.folder == s.folderName }
                    FolderDetailScreen(
                        folderName = s.folderName,
                        tracks = tracksInFolder,
                        currentIndex = if (state.activeQueueName == s.folderName) state.currentIndex else -1,
                        onBack = { screen = Screen.Folders },
                        onTrackClick = { index -> viewModel.playFromFolder(s.folderName, tracksInFolder, index) },
                        onTrackLongClick = { track -> addToPlaylistTrack = track }
                    )
                }
                is Screen.Playlists -> PlaylistsScreen(
                    playlists = state.playlists,
                    onCreateClick = { showCreatePlaylistDialog = true },
                    onOpenPlaylist = { playlist -> screen = Screen.PlaylistDetail(playlist.id) },
                    onDeletePlaylist = { viewModel.deletePlaylist(it) }
                )
                is Screen.PlaylistDetail -> {
                    val playlist = state.playlists.find { it.id == s.playlistId }
                    if (playlist == null) {
                        screen = Screen.Playlists
                    } else {
                        val playlistTracks = playlist.trackIds.mapNotNull { id -> state.allTracks.find { it.id == id } }
                        PlaylistDetailScreen(
                            playlist = playlist,
                            tracks = playlistTracks,
                            currentIndex = if (state.activeQueueName == playlist.name) state.currentIndex else -1,
                            onBack = { screen = Screen.Playlists },
                            onTrackClick = { index -> viewModel.playFromPlaylist(playlist, index) },
                            onRemoveTrack = { trackId -> viewModel.removeTrackFromPlaylist(playlist.id, trackId) }
                        )
                    }
                }
                is Screen.Settings -> SettingsScreen(viewModel = viewModel, state = state)
            }
        }

        if (state.currentIndex in state.activeQueue.indices) {
            NowPlayingBar(
                track = state.activeQueue[state.currentIndex],
                isPlaying = state.isPlaying,
                positionMs = state.positionMs,
                durationMs = state.durationMs,
                onPlayPause = { viewModel.togglePlayPause() },
                onNext = { viewModel.next() },
                onPrevious = { viewModel.previous() },
                onSeek = { viewModel.seekTo(it) }
            )
        }

        BottomNavBar(
            currentScreen = screen,
            strings = strings,
            onSelectAllSongs = { screen = Screen.AllSongs },
            onSelectFolders = { screen = Screen.Folders },
            onSelectPlaylists = { screen = Screen.Playlists },
            onSelectSettings = { screen = Screen.Settings }
        )
    }

    addToPlaylistTrack?.let { track ->
        AddToPlaylistDialog(
            track = track,
            playlists = state.playlists,
            strings = strings,
            onDismiss = { addToPlaylistTrack = null },
            onToggle = { playlistId, alreadyIn ->
                if (alreadyIn) viewModel.removeTrackFromPlaylist(playlistId, track.id)
                else viewModel.addTrackToPlaylist(playlistId, track.id)
            },
            onCreateNew = { showCreatePlaylistDialog = true }
        )
    }

    if (showCreatePlaylistDialog) {
        CreatePlaylistDialog(
            strings = strings,
            onDismiss = { showCreatePlaylistDialog = false },
            onCreate = { name ->
                viewModel.createPlaylist(name)
                showCreatePlaylistDialog = false
            }
        )
    }
}

@Composable
private fun BottomNavBar(
    currentScreen: Screen,
    strings: AppStrings,
    onSelectAllSongs: () -> Unit,
    onSelectFolders: () -> Unit,
    onSelectPlaylists: () -> Unit,
    onSelectSettings: () -> Unit
) {
    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
        NavigationBarItem(
            selected = currentScreen is Screen.AllSongs,
            onClick = onSelectAllSongs,
            icon = { Icon(Icons.Filled.LibraryMusic, contentDescription = null) },
            label = { Text(strings.navSongs) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = PurpleAccent, indicatorColor = PurpleAccent.copy(alpha = 0.2f))
        )
        NavigationBarItem(
            selected = currentScreen is Screen.Folders || currentScreen is Screen.FolderDetail,
            onClick = onSelectFolders,
            icon = { Icon(Icons.Filled.Folder, contentDescription = null) },
            label = { Text(strings.navFolders) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = PurpleAccent, indicatorColor = PurpleAccent.copy(alpha = 0.2f))
        )
        NavigationBarItem(
            selected = currentScreen is Screen.Playlists || currentScreen is Screen.PlaylistDetail,
            onClick = onSelectPlaylists,
            icon = { Icon(Icons.Filled.QueueMusic, contentDescription = null) },
            label = { Text(strings.navPlaylists) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = PurpleAccent, indicatorColor = PurpleAccent.copy(alpha = 0.2f))
        )
        NavigationBarItem(
            selected = currentScreen is Screen.Settings,
            onClick = onSelectSettings,
            icon = { Icon(Icons.Filled.Settings, contentDescription = null) },
            label = { Text(strings.navSettings) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = PurpleAccent, indicatorColor = PurpleAccent.copy(alpha = 0.2f))
        )
    }
}

@Composable
fun TopBar(title: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.GraphicEq, contentDescription = null, tint = PurpleAccent)
        Spacer(modifier = Modifier.width(10.dp))
        Text(title, style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
fun LoadingView() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = PurpleAccent)
    }
}

@Composable
fun EmptyView(message: String) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(
            message,
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(32.dp)
        )
    }
}

@Composable
fun TrackList(
    tracks: List<Track>,
    currentIndex: Int,
    onTrackClick: (Int) -> Unit,
    onTrackLongClick: (Track) -> Unit
) {
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(tracks.size) { index ->
            val track = tracks[index]
            TrackRow(
                track = track,
                isCurrent = index == currentIndex,
                onClick = { onTrackClick(index) },
                onLongClick = { onTrackLongClick(track) }
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun TrackRow(
    track: Track,
    isCurrent: Boolean,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null
) {
    val context = LocalContext.current
    var artwork by remember(track.id) { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(track.id) {
        artwork = AlbumArtProvider.getArt(context, track)
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick,
                onLongClick = onLongClick
            )
            .background(if (isCurrent) PurpleAccent.copy(alpha = 0.15f) else Color.Transparent)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color.DarkGray),
            contentAlignment = Alignment.Center
        ) {
            val art = artwork
            if (art != null) {
                Image(
                    bitmap = art.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(
                    imageVector = if (isCurrent) Icons.Filled.Equalizer else Icons.Filled.MusicNote,
                    contentDescription = null,
                    tint = if (isCurrent) PurpleAccent else Color.Gray,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                track.title,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                track.artist,
                style = MaterialTheme.typography.bodySmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (track.isOpus) {
            OpusBadge()
        }
        trailing?.invoke()
    }
}

@Composable
fun OpusBadge() {
    Box(
        modifier = Modifier
            .background(PurpleAccent, shape = MaterialTheme.shapes.small)
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text("OPUS", color = Color.White, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
    }
}

// --- Folders ---

@Composable
fun FoldersScreen(tracks: List<Track>, onOpenFolder: (String) -> Unit) {
    val strings = LocalAppStrings.current
    val folderGroups = remember(tracks) {
        tracks.groupBy { it.folder }.toSortedMap()
    }

    if (folderGroups.isEmpty()) {
        EmptyView(strings.emptyLibrary)
        return
    }

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(folderGroups.keys.toList()) { folderName ->
            val count = folderGroups[folderName]?.size ?: 0
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenFolder(folderName) }
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(PurpleAccent.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Folder, contentDescription = null, tint = PurpleAccent)
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(folderName, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("$count ${strings.songsCount}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun FolderDetailScreen(
    folderName: String,
    tracks: List<Track>,
    currentIndex: Int,
    onBack: () -> Unit,
    onTrackClick: (Int) -> Unit,
    onTrackLongClick: (Track) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(folderName, style = MaterialTheme.typography.titleMedium)
        }
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(tracks.size) { index ->
                val track = tracks[index]
                TrackRow(
                    track = track,
                    isCurrent = index == currentIndex,
                    onClick = { onTrackClick(index) },
                    onLongClick = { onTrackLongClick(track) }
                )
            }
        }
    }
}

// --- Playlists ---

@Composable
fun PlaylistsScreen(
    playlists: List<Playlist>,
    onCreateClick: () -> Unit,
    onOpenPlaylist: (Playlist) -> Unit,
    onDeletePlaylist: (String) -> Unit
) {
    val strings = LocalAppStrings.current
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(strings.navPlaylists, style = MaterialTheme.typography.titleMedium)
            FilledTonalIconButton(
                onClick = onCreateClick,
                colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = PurpleAccent)
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Create playlist")
            }
        }

        if (playlists.isEmpty()) {
            EmptyView(strings.emptyPlaylists)
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(playlists.size) { index ->
                    val playlist = playlists[index]
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenPlaylist(playlist) }
                            .padding(horizontal = 20.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(PurpleAccent.copy(alpha = 0.25f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.QueueMusic, contentDescription = null, tint = PurpleAccent)
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(playlist.name, style = MaterialTheme.typography.titleMedium)
                            Text("${playlist.trackIds.size} ${strings.songsCount}", style = MaterialTheme.typography.bodySmall)
                        }
                        IconButton(onClick = { onDeletePlaylist(playlist.id) }) {
                            Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete", tint = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PlaylistDetailScreen(
    playlist: Playlist,
    tracks: List<Track>,
    currentIndex: Int,
    onBack: () -> Unit,
    onTrackClick: (Int) -> Unit,
    onRemoveTrack: (Long) -> Unit
) {
    val strings = LocalAppStrings.current
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(playlist.name, style = MaterialTheme.typography.titleMedium)
        }

        if (tracks.isEmpty()) {
            EmptyView(strings.emptyPlaylistDetail)
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(tracks.size) { index ->
                    val track = tracks[index]
                    TrackRow(
                        track = track,
                        isCurrent = index == currentIndex,
                        onClick = { onTrackClick(index) },
                        trailing = {
                            IconButton(onClick = { onRemoveTrack(track.id) }) {
                                Icon(Icons.Filled.Close, contentDescription = "Remove", tint = Color.Gray)
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun AddToPlaylistDialog(
    track: Track,
    playlists: List<Playlist>,
    strings: AppStrings,
    onDismiss: () -> Unit,
    onToggle: (playlistId: String, alreadyIn: Boolean) -> Unit,
    onCreateNew: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(strings.addToPlaylist) },
        text = {
            Column {
                Text(track.title, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(modifier = Modifier.height(12.dp))
                if (playlists.isEmpty()) {
                    Text(strings.emptyPlaylists, style = MaterialTheme.typography.bodyMedium)
                } else {
                    playlists.forEach { playlist ->
                        val alreadyIn = playlist.trackIds.contains(track.id)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onToggle(playlist.id, alreadyIn) }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = alreadyIn,
                                onCheckedChange = { onToggle(playlist.id, alreadyIn) },
                                colors = CheckboxDefaults.colors(checkedColor = PurpleAccent)
                            )
                            Text(playlist.name)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                TextButton(onClick = onCreateNew) {
                    Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(strings.createPlaylist)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(strings.close) }
        }
    )
}

@Composable
fun CreatePlaylistDialog(strings: AppStrings, onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(strings.createPlaylist) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text(strings.playlistName) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = PurpleAccent)
            )
        },
        confirmButton = {
            TextButton(onClick = { onCreate(name) }, enabled = name.isNotBlank()) {
                Text(strings.create)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(strings.cancel) }
        }
    )
}

// --- Settings (language, sleep timer, equalizer) ---

@Composable
fun SettingsScreen(viewModel: PlayerViewModel, state: PlayerUiState) {
    val strings = LocalAppStrings.current
    val scroll = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(20.dp)
    ) {
        Text(strings.settingsTitle, style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(20.dp))

        // Language
        Text(strings.languageLabel, style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            FilterChip(
                selected = state.language == AppLanguage.FA,
                onClick = { viewModel.setLanguage(AppLanguage.FA) },
                label = { Text(strings.persian) },
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PurpleAccent)
            )
            Spacer(modifier = Modifier.width(10.dp))
            FilterChip(
                selected = state.language == AppLanguage.EN,
                onClick = { viewModel.setLanguage(AppLanguage.EN) },
                label = { Text(strings.english) },
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PurpleAccent)
            )
        }

        Spacer(modifier = Modifier.height(28.dp))
        HorizontalDivider()
        Spacer(modifier = Modifier.height(20.dp))

        // Sleep timer
        Text(strings.sleepTimerTitle, style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(8.dp))
        if (state.sleepTimerMinutesLeft != null) {
            Text(
                strings.sleepTimerActive.format(state.sleepTimerMinutesLeft),
                style = MaterialTheme.typography.bodyMedium,
                color = PurpleAccent
            )
            Spacer(modifier = Modifier.height(8.dp))
            TextButton(onClick = { viewModel.cancelSleepTimer() }) {
                Text(strings.sleepTimerOff)
            }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(15, 30, 45, 60).forEach { minutes ->
                    OutlinedButton(onClick = { viewModel.setSleepTimer(minutes) }) {
                        Text("$minutes")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))
        HorizontalDivider()
        Spacer(modifier = Modifier.height(20.dp))

        // Equalizer
        Text(strings.equalizerTitle, style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(12.dp))
        if (!state.equalizerReady) {
            Text("...", style = MaterialTheme.typography.bodySmall)
        } else {
            EqualizerControls(viewModel = viewModel, strings = strings, bassBoostStrength = state.bassBoostStrength)
        }
    }
}

@Composable
fun EqualizerControls(viewModel: PlayerViewModel, strings: AppStrings, bassBoostStrength: Int) {
    val bands = remember { viewModel.equalizerBands() }
    val presets = remember { viewModel.equalizerPresets() }

    if (bands.isEmpty()) {
        Text("—", style = MaterialTheme.typography.bodySmall)
        return
    }

    var levels by remember {
        mutableStateOf(bands.map { viewModel.getBandLevel(it.index).toFloat() })
    }

    Column {
        bands.forEachIndexed { i, band ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "${band.centerFreqHz}Hz",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.width(56.dp)
                )
                Slider(
                    value = levels[i],
                    onValueChange = { newValue ->
                        levels = levels.toMutableList().also { it[i] = newValue }
                        viewModel.setBandLevel(band.index, newValue.toInt().toShort())
                    },
                    valueRange = band.minLevel.toFloat()..band.maxLevel.toFloat(),
                    colors = SliderDefaults.colors(thumbColor = PurpleAccent, activeTrackColor = PurpleAccent),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(strings.bassBoost, style = MaterialTheme.typography.bodyMedium)
        Slider(
            value = bassBoostStrength.toFloat(),
            onValueChange = { viewModel.setBassBoost(it.toInt()) },
            valueRange = 0f..1000f,
            colors = SliderDefaults.colors(thumbColor = PurpleAccent, activeTrackColor = PurpleAccent)
        )

        if (presets.isNotEmpty()) {
            Spacer(modifier = Modifier.height(16.dp))
            Text(strings.presets, style = MaterialTheme.typography.bodyMedium)
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                presets.forEachIndexed { index, name ->
                    OutlinedButton(onClick = {
                        viewModel.useEqualizerPreset(index)
                        levels = bands.map { viewModel.getBandLevel(it.index).toFloat() }
                    }) {
                        Text(name)
                    }
                }
            }
        }
    }
}

@Composable
fun NowPlayingBar(
    track: Track,
    isPlaying: Boolean,
    positionMs: Long,
    durationMs: Long,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Long) -> Unit
) {
    val context = LocalContext.current
    var artwork by remember(track.id) { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(track.id) {
        artwork = AlbumArtProvider.getArt(context, track)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.DarkGray),
                contentAlignment = Alignment.Center
            ) {
                val art = artwork
                if (art != null) {
                    Image(
                        bitmap = art.asImageBitmap(),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(Icons.Filled.MusicNote, contentDescription = null, tint = Color.Gray)
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(track.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(track.artist, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Slider(
            value = if (durationMs > 0) positionMs.toFloat() / durationMs.toFloat() else 0f,
            onValueChange = { fraction -> onSeek((fraction * durationMs).toLong()) },
            colors = SliderDefaults.colors(thumbColor = PurpleAccent, activeTrackColor = PurpleAccent)
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(positionMs), style = MaterialTheme.typography.bodySmall)
            Text(formatTime(durationMs), style = MaterialTheme.typography.bodySmall)
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onPrevious) {
                Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous", modifier = Modifier.size(36.dp))
            }
            Spacer(modifier = Modifier.width(16.dp))
            FilledIconButton(
                onClick = onPlayPause,
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = PurpleAccent),
                modifier = Modifier.size(56.dp)
            ) {
                Icon(
                    if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = "Play/Pause",
                    modifier = Modifier.size(32.dp)
                )
            }
            Spacer(modifier = Modifier.width(16.dp))
            IconButton(onClick = onNext) {
                Icon(Icons.Filled.SkipNext, contentDescription = "Next", modifier = Modifier.size(36.dp))
            }
        }
    }
}

fun formatTime(ms: Long): String {
    if (ms <= 0) return "0:00"
    val minutes = TimeUnit.MILLISECONDS.toMinutes(ms)
    val seconds = TimeUnit.MILLISECONDS.toSeconds(ms) % 60
    return String.format("%d:%02d", minutes, seconds)
}
