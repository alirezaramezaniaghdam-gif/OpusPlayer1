package com.opusplayer.app

import android.Manifest
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.opusplayer.app.ui.theme.OpusPlayerTheme
import com.opusplayer.app.ui.theme.PurpleAccent
import kotlinx.coroutines.delay
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {

    private val viewModel: PlayerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        startService(Intent(this, PlayerService::class.java))

        setContent {
            val state by viewModel.uiState.collectAsState()
            OpusPlayerTheme(darkTheme = state.darkMode) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    RequestAudioPermission(onGranted = { viewModel.refreshLibrary() })
                    val strings = if (state.language == AppLanguage.FA) FaStrings else EnStrings
                    val direction = if (state.language == AppLanguage.FA) LayoutDirection.Rtl else LayoutDirection.Ltr

                    CompositionLocalProvider(
                        LocalAppStrings provides strings,
                        LocalAppLanguage provides state.language,
                        LocalLayoutDirection provides direction
                    ) {
                        RootScreen(viewModel)
                    }
                }
            }
        }
    }
}

@Composable
fun RequestAudioPermission(onGranted: () -> Unit) {
    val permission = if (Build.VERSION.SDK_INT >= 33) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) onGranted()
    }

    LaunchedEffect(Unit) {
        launcher.launch(permission)
    }
}

private sealed class Screen {
    data object AllSongs : Screen()
    data object Folders : Screen()
    data object Playlists : Screen()
    data object Settings : Screen()
    data object FavoritesDetail : Screen()
    data class FolderDetail(val folderName: String) : Screen()
    data class PlaylistDetail(val playlistId: String) : Screen()
}

@Composable
fun RootScreen(viewModel: PlayerViewModel) {
    val state by viewModel.uiState.collectAsState()
    val strings = LocalAppStrings.current
    var screen by remember { mutableStateOf<Screen>(Screen.AllSongs) }
    var addToPlaylistTrack by remember { mutableStateOf<Track?>(null) }
    var showCreatePlaylistDialog by remember { mutableStateOf(false) }
    var showFullPlayer by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
    Column(modifier = Modifier.fillMaxSize()) {
        TopBar(title = strings.appName)

        Box(modifier = Modifier.weight(1f)) {
            when (val s = screen) {
                is Screen.AllSongs -> {
                    when {
                        state.isLoading -> LoadingView()
                        state.allTracks.isEmpty() -> EmptyView(strings.emptyLibrary)
                        else -> AllSongsScreen(
                            tracks = state.allTracks,
                            currentIndex = state.currentIndex,
                            activeQueueName = state.activeQueueName,
                            strings = strings,
                            favoriteIds = state.favoriteIds,
                            onTrackClick = { queue, index -> viewModel.playCustomQueue("All Songs", queue, index) },
                            onTrackLongClick = { track -> addToPlaylistTrack = track },
                            onToggleFavorite = { viewModel.toggleFavorite(it) }
                        )
                    }
                }
                is Screen.Folders -> FoldersScreen(
                    tracks = state.allTracks,
                    onOpenFolder = { folderName -> screen = Screen.FolderDetail(folderName) }
                )
                is Screen.FolderDetail -> {
                    val tracksInFolder = state.allTracks.filter { it.folder == s.folderName }
                    FolderDetailScreen(
                        folderName = s.folderName,
                        tracks = tracksInFolder,
                        currentIndex = if (state.activeQueueName == s.folderName) state.currentIndex else -1,
                        onBack = { screen = Screen.Folders },
                        onTrackClick = { index -> viewModel.playFromFolder(s.folderName, tracksInFolder, index) },
                        onTrackLongClick = { track -> addToPlaylistTrack = track },
                        favoriteIds = state.favoriteIds,
                        onToggleFavorite = { viewModel.toggleFavorite(it) }
                    )
                }
                is Screen.Playlists -> PlaylistsScreen(
                    playlists = state.playlists,
                    favoritesCount = state.favoriteIds.size,
                    onCreateClick = { showCreatePlaylistDialog = true },
                    onOpenPlaylist = { playlist -> screen = Screen.PlaylistDetail(playlist.id) },
                    onOpenFavorites = { screen = Screen.FavoritesDetail },
                    onDeletePlaylist = { viewModel.deletePlaylist(it) }
                )
                is Screen.FavoritesDetail -> {
                    val favoriteTracks = state.allTracks.filter { state.favoriteIds.contains(it.id) }
                    FavoritesDetailScreen(
                        tracks = favoriteTracks,
                        currentIndex = if (state.activeQueueName == "Favorites") state.currentIndex else -1,
                        strings = strings,
                        onBack = { screen = Screen.Playlists },
                        onTrackClick = { index -> viewModel.playFromFavorites(favoriteTracks, index) },
                        onToggleFavorite = { viewModel.toggleFavorite(it) }
                    )
                }
                is Screen.PlaylistDetail -> {
                    val playlist = state.playlists.find { it.id == s.playlistId }
                    if (playlist == null) {
                        screen = Screen.Playlists
                    } else {
                        val playlistTracks = playlist.trackIds.mapNotNull { id -> state.allTracks.find { it.id == id } }
                        PlaylistDetailScreen(
                            playlist = playlist,
                            tracks = playlistTracks,
                            currentIndex = if (state.activeQueueName == playlist.name) state.currentIndex else -1,
                            onBack = { screen = Screen.Playlists },
                            onTrackClick = { index -> viewModel.playFromPlaylist(playlist, index) },
                            onRemoveTrack = { trackId -> viewModel.removeTrackFromPlaylist(playlist.id, trackId) },
                            onMoveTrack = { trackId, delta -> viewModel.moveTrackInPlaylist(playlist.id, trackId, delta) }
                        )
                    }
                }
                is Screen.Settings -> SettingsScreen(viewModel = viewModel, state = state)
            }
        }

        if (state.currentIndex in state.activeQueue.indices) {
            NowPlayingBar(
                track = state.activeQueue[state.currentIndex],
                isPlaying = state.isPlaying,
                positionMs = state.positionMs,
                durationMs = state.durationMs,
                shuffleEnabled = state.shuffleEnabled,
                repeatMode = state.repeatMode,
                onPlayPause = { viewModel.togglePlayPause() },
                onNext = { viewModel.next() },
                onPrevious = { viewModel.previous() },
                onSeek = { viewModel.seekTo(it) },
                onToggleShuffle = { viewModel.toggleShuffle() },
                onCycleRepeat = { viewModel.cycleRepeatMode() },
                onOpenFullPlayer = { showFullPlayer = true }
            )
        }

        BottomNavBar(
            currentScreen = screen,
            strings = strings,
            onSelectAllSongs = { screen = Screen.AllSongs },
            onSelectFolders = { screen = Screen.Folders },
            onSelectPlaylists = { screen = Screen.Playlists },
            onSelectSettings = { screen = Screen.Settings }
        )
    }

    addToPlaylistTrack?.let { track ->
        AddToPlaylistDialog(
            track = track,
            playlists = state.playlists,
            strings = strings,
            onDismiss = { addToPlaylistTrack = null },
            onToggle = { playlistId, alreadyIn ->
                if (alreadyIn) viewModel.removeTrackFromPlaylist(playlistId, track.id)
                else viewModel.addTrackToPlaylist(playlistId, track.id)
            },
            onCreateNew = { showCreatePlaylistDialog = true }
        )
    }

    if (showCreatePlaylistDialog) {
        CreatePlaylistDialog(
            strings = strings,
            onDismiss = { showCreatePlaylistDialog = false },
            onCreate = { name ->
                viewModel.createPlaylist(name)
                showCreatePlaylistDialog = false
            }
        )
    }

    if (showFullPlayer && state.currentIndex in state.activeQueue.indices) {
        val currentTrack = state.activeQueue[state.currentIndex]
        FullPlayerScreen(
            track = currentTrack,
            isPlaying = state.isPlaying,
            positionMs = state.positionMs,
            durationMs = state.durationMs,
            isFavorite = state.favoriteIds.contains(currentTrack.id),
            shuffleEnabled = state.shuffleEnabled,
            repeatMode = state.repeatMode,
            onClose = { showFullPlayer = false },
            onPlayPause = { viewModel.togglePlayPause() },
            onNext = { viewModel.next() },
            onPrevious = { viewModel.previous() },
            onSeek = { viewModel.seekTo(it) },
            onToggleShuffle = { viewModel.toggleShuffle() },
            onCycleRepeat = { viewModel.cycleRepeatMode() },
            onToggleFavorite = { viewModel.toggleFavorite(currentTrack.id) },
            onOpenEqualizer = {
                showFullPlayer = false
                screen = Screen.Settings
            }
        )
    }
    }
}

@Composable
private fun BottomNavBar(
    currentScreen: Screen,
    strings: AppStrings,
    onSelectAllSongs: () -> Unit,
    onSelectFolders: () -> Unit,
    onSelectPlaylists: () -> Unit,
    onSelectSettings: () -> Unit
) {
    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
        NavigationBarItem(
            selected = currentScreen is Screen.AllSongs,
            onClick = onSelectAllSongs,
            icon = { Icon(Icons.Filled.LibraryMusic, contentDescription = null) },
            label = { Text(strings.navSongs) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = PurpleAccent, indicatorColor = PurpleAccent.copy(alpha = 0.2f))
        )
        NavigationBarItem(
            selected = currentScreen is Screen.Folders || currentScreen is Screen.FolderDetail,
            onClick = onSelectFolders,
            icon = { Icon(Icons.Filled.Folder, contentDescription = null) },
            label = { Text(strings.navFolders) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = PurpleAccent, indicatorColor = PurpleAccent.copy(alpha = 0.2f))
        )
        NavigationBarItem(
            selected = currentScreen is Screen.Playlists || currentScreen is Screen.PlaylistDetail,
            onClick = onSelectPlaylists,
            icon = { Icon(Icons.Filled.QueueMusic, contentDescription = null) },
            label = { Text(strings.navPlaylists) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = PurpleAccent, indicatorColor = PurpleAccent.copy(alpha = 0.2f))
        )
        NavigationBarItem(
            selected = currentScreen is Screen.Settings,
            onClick = onSelectSettings,
            icon = { Icon(Icons.Filled.Settings, contentDescription = null) },
            label = { Text(strings.navSettings) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = PurpleAccent, indicatorColor = PurpleAccent.copy(alpha = 0.2f))
        )
    }
}

@Composable
fun TopBar(title: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.GraphicEq, contentDescription = null, tint = PurpleAccent)
        Spacer(modifier = Modifier.width(10.dp))
        Text(title, style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
fun LoadingView() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = PurpleAccent)
    }
}

@Composable
fun EmptyView(message: String) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(
            message,
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(32.dp)
        )
    }
}

private enum class SortMode { TITLE, ARTIST, DURATION }

@Composable
fun AllSongsScreen(
    tracks: List<Track>,
    currentIndex: Int,
    activeQueueName: String,
    strings: AppStrings,
    favoriteIds: Set<Long>,
    onTrackClick: (List<Track>, Int) -> Unit,
    onTrackLongClick: (Track) -> Unit,
    onToggleFavorite: (Long) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var sortMode by remember { mutableStateOf(SortMode.TITLE) }
    var sortMenuExpanded by remember { mutableStateOf(false) }

    val filteredSorted = remember(tracks, query, sortMode) {
        val filtered = if (query.isBlank()) tracks else tracks.filter {
            it.title.contains(query, ignoreCase = true) || it.artist.contains(query, ignoreCase = true)
        }
        when (sortMode) {
            SortMode.TITLE -> filtered.sortedBy { it.title.lowercase() }
            SortMode.ARTIST -> filtered.sortedBy { it.artist.lowercase() }
            SortMode.DURATION -> filtered.sortedBy { it.durationMs }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text(strings.searchHint, style = MaterialTheme.typography.bodySmall) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = PurpleAccent)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Box {
                IconButton(onClick = { sortMenuExpanded = true }) {
                    Icon(Icons.Filled.Sort, contentDescription = "Sort")
                }
                DropdownMenu(expanded = sortMenuExpanded, onDismissRequest = { sortMenuExpanded = false }) {
                    DropdownMenuItem(text = { Text(strings.sortByTitle) }, onClick = { sortMode = SortMode.TITLE; sortMenuExpanded = false })
                    DropdownMenuItem(text = { Text(strings.sortByArtist) }, onClick = { sortMode = SortMode.ARTIST; sortMenuExpanded = false })
                    DropdownMenuItem(text = { Text(strings.sortByDuration) }, onClick = { sortMode = SortMode.DURATION; sortMenuExpanded = false })
                }
            }
        }

        TrackList(
            tracks = filteredSorted,
            currentIndex = if (activeQueueName == "All Songs") currentIndex else -1,
            onTrackClick = { index -> onTrackClick(filteredSorted, index) },
            onTrackLongClick = onTrackLongClick,
            favoriteIds = favoriteIds,
            onToggleFavorite = onToggleFavorite
        )
    }
}

@Composable
fun TrackList(
    tracks: List<Track>,
    currentIndex: Int,
    onTrackClick: (Int) -> Unit,
    onTrackLongClick: (Track) -> Unit,
    favoriteIds: Set<Long> = emptySet(),
    onToggleFavorite: ((Long) -> Unit)? = null
) {
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(count = tracks.size, key = { index -> tracks[index].id }) { index ->
            val track = tracks[index]
            TrackRow(
                track = track,
                isCurrent = index == currentIndex,
                onClick = { onTrackClick(index) },
                onLongClick = { onTrackLongClick(track) },
                isFavorite = favoriteIds.contains(track.id),
                onToggleFavorite = onToggleFavorite?.let { { it(track.id) } }
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun TrackRow(
    track: Track,
    isCurrent: Boolean,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    isFavorite: Boolean = false,
    onToggleFavorite: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null
) {
    val context = LocalContext.current
    var artwork by remember(track.id) { mutableStateOf(AlbumArtProvider.peek(track.id)) }

    LaunchedEffect(track.id) {
        if (artwork != null) return@LaunchedEffect
        // If this row scrolls out of view quickly, this coroutine gets cancelled
        // before the delay finishes, so we never even start the expensive decode.
        delay(120)
        artwork = AlbumArtProvider.getArt(context, track)
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick,
                onLongClick = onLongClick
            )
            .background(if (isCurrent) PurpleAccent.copy(alpha = 0.15f) else Color.Transparent)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color.DarkGray),
            contentAlignment = Alignment.Center
        ) {
            val art = artwork
            if (art != null) {
                Image(
                    bitmap = art.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(
                    imageVector = if (isCurrent) Icons.Filled.Equalizer else Icons.Filled.MusicNote,
                    contentDescription = null,
                    tint = if (isCurrent) PurpleAccent else Color.Gray,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                track.title,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                track.artist,
                style = MaterialTheme.typography.bodySmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (onToggleFavorite != null) {
            IconButton(onClick = onToggleFavorite, modifier = Modifier.size(36.dp)) {
                Icon(
                    imageVector = if (isFavorite) Icons.Filled.Star else Icons.Filled.StarBorder,
                    contentDescription = "Favorite",
                    tint = if (isFavorite) PurpleAccent else Color.Gray
                )
            }
        }
        if (track.isOpus) {
            OpusBadge()
        }
        trailing?.invoke()
    }
}

@Composable
fun OpusBadge() {
    Box(
        modifier = Modifier
            .background(PurpleAccent, shape = MaterialTheme.shapes.small)
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text("OPUS", color = Color.White, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
    }
}

// --- Folders ---

@Composable
fun FoldersScreen(tracks: List<Track>, onOpenFolder: (String) -> Unit) {
    val strings = LocalAppStrings.current
    val folderGroups = remember(tracks) {
        tracks.groupBy { it.folder }.toSortedMap()
    }

    if (folderGroups.isEmpty()) {
        EmptyView(strings.emptyLibrary)
        return
    }

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(folderGroups.keys.toList()) { folderName ->
            val count = folderGroups[folderName]?.size ?: 0
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenFolder(folderName) }
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(PurpleAccent.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Folder, contentDescription = null, tint = PurpleAccent)
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(folderName, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("$count ${strings.songsCount}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun FolderDetailScreen(
    folderName: String,
    tracks: List<Track>,
    currentIndex: Int,
    onBack: () -> Unit,
    onTrackClick: (Int) -> Unit,
    onTrackLongClick: (Track) -> Unit,
    favoriteIds: Set<Long> = emptySet(),
    onToggleFavorite: ((Long) -> Unit)? = null
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(folderName, style = MaterialTheme.typography.titleMedium)
        }
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(count = tracks.size, key = { index -> tracks[index].id }) { index ->
                val track = tracks[index]
                TrackRow(
                    track = track,
                    isCurrent = index == currentIndex,
                    onClick = { onTrackClick(index) },
                    onLongClick = { onTrackLongClick(track) },
                    isFavorite = favoriteIds.contains(track.id),
                    onToggleFavorite = onToggleFavorite?.let { { it(track.id) } }
                )
            }
        }
    }
}

// --- Playlists ---

@Composable
fun PlaylistsScreen(
    playlists: List<Playlist>,
    favoritesCount: Int,
    onCreateClick: () -> Unit,
    onOpenPlaylist: (Playlist) -> Unit,
    onOpenFavorites: () -> Unit,
    onDeletePlaylist: (String) -> Unit
) {
    val strings = LocalAppStrings.current
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(strings.navPlaylists, style = MaterialTheme.typography.titleMedium)
            FilledTonalIconButton(
                onClick = onCreateClick,
                colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = PurpleAccent)
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Create playlist")
            }
        }

        // Favorites is a built-in pseudo-playlist: always shown, never deletable.
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onOpenFavorites() }
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(PurpleAccent.copy(alpha = 0.25f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Star, contentDescription = null, tint = PurpleAccent)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(strings.favorites, style = MaterialTheme.typography.titleMedium)
                Text("$favoritesCount ${strings.songsCount}", style = MaterialTheme.typography.bodySmall)
            }
        }
        HorizontalDivider()

        if (playlists.isEmpty()) {
            EmptyView(strings.emptyPlaylists)
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(count = playlists.size, key = { index -> playlists[index].id }) { index ->
                    val playlist = playlists[index]
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenPlaylist(playlist) }
                            .padding(horizontal = 20.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(PurpleAccent.copy(alpha = 0.25f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.QueueMusic, contentDescription = null, tint = PurpleAccent)
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(playlist.name, style = MaterialTheme.typography.titleMedium)
                            Text("${playlist.trackIds.size} ${strings.songsCount}", style = MaterialTheme.typography.bodySmall)
                        }
                        IconButton(onClick = { onDeletePlaylist(playlist.id) }) {
                            Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete", tint = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PlaylistDetailScreen(
    playlist: Playlist,
    tracks: List<Track>,
    currentIndex: Int,
    onBack: () -> Unit,
    onTrackClick: (Int) -> Unit,
    onRemoveTrack: (Long) -> Unit,
    onMoveTrack: (Long, Int) -> Unit
) {
    val strings = LocalAppStrings.current
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(playlist.name, style = MaterialTheme.typography.titleMedium)
        }

        if (tracks.isEmpty()) {
            EmptyView(strings.emptyPlaylistDetail)
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(count = tracks.size, key = { index -> tracks[index].id }) { index ->
                    val track = tracks[index]
                    TrackRow(
                        track = track,
                        isCurrent = index == currentIndex,
                        onClick = { onTrackClick(index) },
                        trailing = {
                            Row {
                                IconButton(onClick = { onMoveTrack(track.id, -1) }, enabled = index > 0) {
                                    Icon(Icons.Filled.KeyboardArrowUp, contentDescription = "Move up", tint = if (index > 0) Color.Gray else Color.DarkGray)
                                }
                                IconButton(onClick = { onMoveTrack(track.id, 1) }, enabled = index < tracks.size - 1) {
                                    Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Move down", tint = if (index < tracks.size - 1) Color.Gray else Color.DarkGray)
                                }
                                IconButton(onClick = { onRemoveTrack(track.id) }) {
                                    Icon(Icons.Filled.Close, contentDescription = "Remove", tint = Color.Gray)
                                }
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun FavoritesDetailScreen(
    tracks: List<Track>,
    currentIndex: Int,
    strings: AppStrings,
    onBack: () -> Unit,
    onTrackClick: (Int) -> Unit,
    onToggleFavorite: (Long) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(strings.favorites, style = MaterialTheme.typography.titleMedium)
        }

        if (tracks.isEmpty()) {
            EmptyView(strings.emptyFavorites)
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(count = tracks.size, key = { index -> tracks[index].id }) { index ->
                    val track = tracks[index]
                    TrackRow(
                        track = track,
                        isCurrent = index == currentIndex,
                        onClick = { onTrackClick(index) },
                        isFavorite = true,
                        onToggleFavorite = { onToggleFavorite(track.id) }
                    )
                }
            }
        }
    }
}

@Composable
fun AddToPlaylistDialog(
    track: Track,
    playlists: List<Playlist>,
    strings: AppStrings,
    onDismiss: () -> Unit,
    onToggle: (playlistId: String, alreadyIn: Boolean) -> Unit,
    onCreateNew: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(strings.addToPlaylist) },
        text = {
            Column {
                Text(track.title, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(modifier = Modifier.height(12.dp))
                if (playlists.isEmpty()) {
                    Text(strings.emptyPlaylists, style = MaterialTheme.typography.bodyMedium)
                } else {
                    playlists.forEach { playlist ->
                        val alreadyIn = playlist.trackIds.contains(track.id)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onToggle(playlist.id, alreadyIn) }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = alreadyIn,
                                onCheckedChange = { onToggle(playlist.id, alreadyIn) },
                                colors = CheckboxDefaults.colors(checkedColor = PurpleAccent)
                            )
                            Text(playlist.name)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                TextButton(onClick = onCreateNew) {
                    Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(strings.createPlaylist)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(strings.close) }
        }
    )
}

@Composable
fun CreatePlaylistDialog(strings: AppStrings, onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(strings.createPlaylist) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text(strings.playlistName) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = PurpleAccent)
            )
        },
        confirmButton = {
            TextButton(onClick = { onCreate(name) }, enabled = name.isNotBlank()) {
                Text(strings.create)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(strings.cancel) }
        }
    )
}

// --- Settings (language, sleep timer, equalizer) ---

@Composable
fun SettingsScreen(viewModel: PlayerViewModel, state: PlayerUiState) {
    val strings = LocalAppStrings.current
    val scroll = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(20.dp)
    ) {
        Text(strings.settingsTitle, style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(20.dp))

        // Language
        Text(strings.languageLabel, style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            FilterChip(
                selected = state.language == AppLanguage.FA,
                onClick = { viewModel.setLanguage(AppLanguage.FA) },
                label = { Text(strings.persian) },
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PurpleAccent)
            )
            Spacer(modifier = Modifier.width(10.dp))
            FilterChip(
                selected = state.language == AppLanguage.EN,
                onClick = { viewModel.setLanguage(AppLanguage.EN) },
                label = { Text(strings.english) },
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PurpleAccent)
            )
        }

        Spacer(modifier = Modifier.height(28.dp))
        HorizontalDivider()
        Spacer(modifier = Modifier.height(20.dp))

        // Theme
        Text(strings.themeLabel, style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            FilterChip(
                selected = state.darkMode,
                onClick = { viewModel.setDarkMode(true) },
                label = { Text(strings.darkMode) },
                leadingIcon = { Icon(Icons.Filled.DarkMode, contentDescription = null, modifier = Modifier.size(18.dp)) },
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PurpleAccent)
            )
            Spacer(modifier = Modifier.width(10.dp))
            FilterChip(
                selected = !state.darkMode,
                onClick = { viewModel.setDarkMode(false) },
                label = { Text(strings.lightMode) },
                leadingIcon = { Icon(Icons.Filled.LightMode, contentDescription = null, modifier = Modifier.size(18.dp)) },
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PurpleAccent)
            )
        }

        Spacer(modifier = Modifier.height(28.dp))
        HorizontalDivider()
        Spacer(modifier = Modifier.height(20.dp))

        // Sleep timer
        Text(strings.sleepTimerTitle, style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(8.dp))
        if (state.sleepTimerMinutesLeft != null) {
            Text(
                strings.sleepTimerActive.format(state.sleepTimerMinutesLeft),
                style = MaterialTheme.typography.bodyMedium,
                color = PurpleAccent
            )
            Spacer(modifier = Modifier.height(8.dp))
            TextButton(onClick = { viewModel.cancelSleepTimer() }) {
                Text(strings.sleepTimerOff)
            }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(15, 30, 45, 60).forEach { minutes ->
                    OutlinedButton(onClick = { viewModel.setSleepTimer(minutes) }) {
                        Text("$minutes")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))
        HorizontalDivider()
        Spacer(modifier = Modifier.height(20.dp))

        // Equalizer
        Text(strings.equalizerTitle, style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(12.dp))
        if (!state.equalizerReady) {
            Text("...", style = MaterialTheme.typography.bodySmall)
        } else {
            EqualizerControls(viewModel = viewModel, strings = strings, bassBoostStrength = state.bassBoostStrength)
        }
    }
}

@Composable
fun EqualizerControls(viewModel: PlayerViewModel, strings: AppStrings, bassBoostStrength: Int) {
    val bands = remember { viewModel.equalizerBands() }
    val presets = remember { viewModel.equalizerPresets() }

    if (bands.isEmpty()) {
        Text("—", style = MaterialTheme.typography.bodySmall)
        return
    }

    var levels by remember {
        mutableStateOf(bands.map { viewModel.getBandLevel(it.index).toFloat() })
    }

    Column {
        bands.forEachIndexed { i, band ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "${band.centerFreqHz}Hz",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.width(56.dp)
                )
                Slider(
                    value = levels[i],
                    onValueChange = { newValue ->
                        levels = levels.toMutableList().also { it[i] = newValue }
                        viewModel.setBandLevel(band.index, newValue.toInt().toShort())
                    },
                    valueRange = band.minLevel.toFloat()..band.maxLevel.toFloat(),
                    colors = SliderDefaults.colors(thumbColor = PurpleAccent, activeTrackColor = PurpleAccent),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(strings.bassBoost, style = MaterialTheme.typography.bodyMedium)
        Slider(
            value = bassBoostStrength.toFloat(),
            onValueChange = { viewModel.setBassBoost(it.toInt()) },
            valueRange = 0f..1000f,
            colors = SliderDefaults.colors(thumbColor = PurpleAccent, activeTrackColor = PurpleAccent)
        )

        if (presets.isNotEmpty()) {
            Spacer(modifier = Modifier.height(16.dp))
            Text(strings.presets, style = MaterialTheme.typography.bodyMedium)
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                presets.forEachIndexed { index, name ->
                    OutlinedButton(onClick = {
                        viewModel.useEqualizerPreset(index)
                        levels = bands.map { viewModel.getBandLevel(it.index).toFloat() }
                    }) {
                        Text(name)
                    }
                }
            }
        }
    }
}

@Composable
fun NowPlayingBar(
    track: Track,
    isPlaying: Boolean,
    positionMs: Long,
    durationMs: Long,
    shuffleEnabled: Boolean,
    repeatMode: Int,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Long) -> Unit,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    onOpenFullPlayer: () -> Unit
) {
    val context = LocalContext.current
    var artwork by remember(track.id) { mutableStateOf(AlbumArtProvider.peek(track.id)) }

    LaunchedEffect(track.id) {
        if (artwork != null) return@LaunchedEffect
        artwork = AlbumArtProvider.getArt(context, track)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.clickable { onOpenFullPlayer() }
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.DarkGray),
                contentAlignment = Alignment.Center
            ) {
                val art = artwork
                if (art != null) {
                    Image(
                        bitmap = art.asImageBitmap(),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(Icons.Filled.MusicNote, contentDescription = null, tint = Color.Gray)
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(track.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(track.artist, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Slider(
            value = if (durationMs > 0) positionMs.toFloat() / durationMs.toFloat() else 0f,
            onValueChange = { fraction -> onSeek((fraction * durationMs).toLong()) },
            colors = SliderDefaults.colors(thumbColor = PurpleAccent, activeTrackColor = PurpleAccent)
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(positionMs), style = MaterialTheme.typography.bodySmall)
            Text(formatTime(durationMs), style = MaterialTheme.typography.bodySmall)
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onToggleShuffle) {
                Icon(
                    Icons.Filled.Shuffle,
                    contentDescription = "Shuffle",
                    tint = if (shuffleEnabled) PurpleAccent else Color.Gray
                )
            }
            IconButton(onClick = onPrevious) {
                Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous", modifier = Modifier.size(36.dp))
            }
            Spacer(modifier = Modifier.width(8.dp))
            FilledIconButton(
                onClick = onPlayPause,
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = PurpleAccent),
                modifier = Modifier.size(56.dp)
            ) {
                Icon(
                    if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = "Play/Pause",
                    modifier = Modifier.size(32.dp)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(onClick = onNext) {
                Icon(Icons.Filled.SkipNext, contentDescription = "Next", modifier = Modifier.size(36.dp))
            }
            IconButton(onClick = onCycleRepeat) {
                Icon(
                    imageVector = if (repeatMode == 1) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                    contentDescription = "Repeat",
                    tint = if (repeatMode != 0) PurpleAccent else Color.Gray
                )
            }
        }
    }
}

@Composable
fun FullPlayerScreen(
    track: Track,
    isPlaying: Boolean,
    positionMs: Long,
    durationMs: Long,
    isFavorite: Boolean,
    shuffleEnabled: Boolean,
    repeatMode: Int,
    onClose: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Long) -> Unit,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    onToggleFavorite: () -> Unit,
    onOpenEqualizer: () -> Unit
) {
    val context = LocalContext.current
    var artwork by remember(track.id) { mutableStateOf(AlbumArtProvider.peek(track.id)) }

    LaunchedEffect(track.id) {
        if (artwork != null) return@LaunchedEffect
        artwork = AlbumArtProvider.getArt(context, track)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 24.dp, vertical = 16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) {
                Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Close", modifier = Modifier.size(32.dp))
            }
            IconButton(onClick = onOpenEqualizer) {
                Icon(Icons.Filled.Tune, contentDescription = "Equalizer")
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(20.dp))
                .background(Color.DarkGray),
            contentAlignment = Alignment.Center
        ) {
            val art = artwork
            if (art != null) {
                Image(
                    bitmap = art.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(
                    Icons.Filled.MusicNote,
                    contentDescription = null,
                    tint = Color.Gray,
                    modifier = Modifier.size(96.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    track.title,
                    style = MaterialTheme.typography.titleLarge,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    track.artist,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(onClick = onToggleFavorite) {
                Icon(
                    imageVector = if (isFavorite) Icons.Filled.Star else Icons.Filled.StarBorder,
                    contentDescription = "Favorite",
                    tint = if (isFavorite) PurpleAccent else Color.Gray,
                    modifier = Modifier.size(28.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Slider(
            value = if (durationMs > 0) positionMs.toFloat() / durationMs.toFloat() else 0f,
            onValueChange = { fraction -> onSeek((fraction * durationMs).toLong()) },
            colors = SliderDefaults.colors(thumbColor = PurpleAccent, activeTrackColor = PurpleAccent)
        )
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(positionMs), style = MaterialTheme.typography.bodySmall)
            Text(formatTime(durationMs), style = MaterialTheme.typography.bodySmall)
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onToggleShuffle) {
                Icon(
                    Icons.Filled.Shuffle,
                    contentDescription = "Shuffle",
                    tint = if (shuffleEnabled) PurpleAccent else Color.Gray
                )
            }
            IconButton(onClick = onPrevious) {
                Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous", modifier = Modifier.size(40.dp))
            }
            FilledIconButton(
                onClick = onPlayPause,
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = PurpleAccent),
                modifier = Modifier.size(72.dp)
            ) {
                Icon(
                    if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = "Play/Pause",
                    modifier = Modifier.size(40.dp)
                )
            }
            IconButton(onClick = onNext) {
                Icon(Icons.Filled.SkipNext, contentDescription = "Next", modifier = Modifier.size(40.dp))
            }
            IconButton(onClick = onCycleRepeat) {
                Icon(
                    imageVector = if (repeatMode == 1) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                    contentDescription = "Repeat",
                    tint = if (repeatMode != 0) PurpleAccent else Color.Gray
                )
            }
        }
    }
}

fun formatTime(ms: Long): String {
    if (ms <= 0) return "0:00"
    val minutes = TimeUnit.MILLISECONDS.toMinutes(ms)
    val seconds = TimeUnit.MILLISECONDS.toSeconds(ms) % 60
    return String.format("%d:%02d", minutes, seconds)
}
