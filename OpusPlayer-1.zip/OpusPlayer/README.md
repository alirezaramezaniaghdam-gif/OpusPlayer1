# Opus Player

یک موزیک پلیر اندروید حرفه‌ای با پشتیبانی کامل از فرمت **Opus** (و همچنین mp3، flac، wav، ogg، m4a).

## چی داخلشه؟
- پخش با **Media3 / ExoPlayer** (که به‌صورت native از Opus پشتیبانی می‌کنه، نیازی به کتابخانه اضافه نیست)
- کنترل از نوتیفیکیشن، صفحه قفل، هندزفری بلوتوث (از طریق MediaSession)
- اسکن خودکار فایل‌های صوتی گوشی (MediaStore)
- رابط کاربری با Jetpack Compose (تم تیره + رنگ بنفش)
- نشان (Badge) مخصوص برای فایل‌های Opus توی لیست

## ساختار پروژه
```
OpusPlayer/
├── app/
│   └── src/main/java/com/opusplayer/app/
│       ├── MainActivity.kt        (UI کامل با Compose)
│       ├── PlayerService.kt       (سرویس پخش در پس‌زمینه)
│       ├── PlayerViewModel.kt     (منطق ارتباط UI ↔ پلیر)
│       ├── MusicRepository.kt     (اسکن فایل‌های صوتی گوشی)
│       └── Track.kt
├── build.gradle.kts
└── settings.gradle.kts
```

---

## 🔧 مراحل ساخت APK (قدم‌به‌قدم)

### گام ۱: نصب Android Studio
از سایت رسمی دانلود کن: https://developer.android.com/studio
(نسخه‌ی جدید Android Studio خودش JDK لازم رو داره، نیازی به نصب جدا نیست)

### گام ۲: باز کردن پروژه
1. فایل zip رو از حالت فشرده خارج کن (Extract)
2. توی Android Studio: `File → Open` و پوشه‌ی `OpusPlayer` رو انتخاب کن
3. صبر کن تا Gradle Sync تموم بشه (بار اول ممکنه چند دقیقه طول بکشه چون باید کتابخونه‌ها رو دانلود کنه — نیاز به اینترنت داره)

### گام ۳: اتصال گوشی یا استفاده از شبیه‌ساز
- **گوشی واقعی:** توی تنظیمات گوشی، "USB debugging" رو از قسمت Developer Options فعال کن و با کابل وصلش کن
- **یا از Emulator داخل Android Studio استفاده کن** (Device Manager → Create Device)

### گام ۴: اجرا یا ساخت APK
- برای تست سریع: دکمه‌ی سبز رنگ ▶ Run بالای Android Studio رو بزن
- برای گرفتن فایل APK نهایی:
  - از منو: `Build → Build Bundle(s) / APK(s) → Build APK(s)`
  - بعد از اتمام، یک لینک "locate" پایین صفحه ظاهر میشه که فایل APK رو نشونت میده
  - مسیر معمول: `app/build/outputs/apk/debug/app-debug.apk`

### گام ۵: نصب روی گوشی
فایل APK رو به گوشی منتقل کن و نصبش کن (باید "نصب از منابع ناشناس" رو موقتاً فعال کنی).

---

## نکته درباره فایل‌های Opus
اندروید معمولاً فایل‌های `.opus` رو توی گالری موزیک پیش‌فرض نشون نمی‌ده، ولی این اپ مستقیماً از `MediaStore` همه‌ی فایل‌های صوتی (از جمله opus) رو اسکن می‌کنه. کافیه فایل‌های `.opus` خودت رو توی پوشه‌ی Music گوشی کپی کنی.

## قدم بعدی (اختیاری)
اگه خواستی بعداً امضای release واقعی (signed APK) برای انتشار توی Google Play بگیری، به من بگو تا مراحل ساخت keystore و signing رو هم قدم‌به‌قدم توضیح بدم.
