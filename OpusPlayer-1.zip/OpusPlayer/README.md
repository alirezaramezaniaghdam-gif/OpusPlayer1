# Opus Player

یک موزیک پلیر اندروید حرفه‌ای و کامل با:

- 🎵 پشتیبانی از **همه‌ی فرمت‌های صوتی**: Opus, MP3, FLAC, OGG, WAV, M4A
- 🖼️ **نمایش عکس کاور آهنگ‌ها** (از خود فایل استخراج میشه)
- 📃 **ساخت و مدیریت پلی‌لیست** (نگه‌داشتن روی آهنگ → افزودن به پلی‌لیست)
- 🔔 کنترل کامل از نوتیفیکیشن و صفحه قفل (Media3/ExoPlayer)
- 🎨 آیکون اختصاصی بنفش با طرح موج صدا + دکمه پخش
- 🌙 تم تیره مدرن با Jetpack Compose

---

## 🔧 ساخت APK از طریق GitHub Actions (بدون نیاز به لپ‌تاپ)

اگه قبلاً یه ریپازیتوری به اسم OpusPlayer1 روی گیت‌هابت ساختی، همون رو دوباره استفاده کن (نیازی به ساخت جدید نیست، فقط فایل‌های قدیمی رو با این نسخه جایگزین کن).

### گام ۱: حذف فایل‌های قدیمی (اگه از قبل هست)
1. برو توی ریپازیتوری قبلی‌ت روی github.com
2. فایل zip قدیمی (مثل `OpusPlayer-1.zip`) و پوشه‌ی `.github/workflows` قدیمی رو با زدن روی هرکدوم و بعد آیکون **سطل زباله (Delete file)** پاک کن، و Commit کن

### گام ۲: آپلود فایل زیپ جدید
1. توی صفحه‌ی اصلی ریپازیتوری، دنبال دکمه‌ی **Add file → Upload files** بگرد (بالای لیست فایل‌ها)
2. فایل **OpusPlayer.zip** (همینی که الان گرفتی) رو انتخاب و آپلود کن
3. پایین صفحه، دکمه‌ی سبز **Commit changes** رو بزن
4. **مهم:** اسم دقیق فایلی که آپلود شد رو یادداشت کن (اگه قبلاً فایلی با همین اسم بوده، گیت‌هاب ممکنه خودش `-1` بهش اضافه کنه)

### گام ۳: ساخت فایل build.yml
1. دوباره از **Add file → Create new file** استفاده کن
2. اسم فایل رو دقیقاً همین بنویس:
```
.github/workflows/build.yml
```
3. این محتوا رو داخلش کپی کن (اگه اسم زیپ فرق داره، جای `OpusPlayer.zip` توی خط اول اسم درستش رو بذار):

```yaml
name: Build APK

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Unzip project
        run: unzip -o OpusPlayer.zip

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'

      - name: Grant execute permission for gradlew
        run: cd OpusPlayer && gradle wrapper && chmod +x gradlew

      - name: Build Debug APK
        run: cd OpusPlayer && ./gradlew assembleDebug

      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: opus-player-apk
          path: OpusPlayer/app/build/outputs/apk/debug/app-debug.apk
```

4. پایین صفحه **Commit changes** رو بزن

### گام ۴: دیدن نتیجه و دانلود APK
1. بالای صفحه تب **Actions** رو بزن
2. صبر کن (۳ تا ۷ دقیقه) تا از 🟡 زرد (در حال ساخت) به ✅ سبز (موفق) تبدیل بشه
3. روی همون ردیف سبز بزن
4. پایین صفحه، زیر بخش **Artifacts**، فایل **opus-player-apk** رو دانلود کن
5. فایل دانلودی یه zip هست — Extract کن، داخلش **app-debug.apk** هست
6. اون رو نصب کن (اگه پیام "منبع ناشناس" اومد، اجازه بده)

---

## نحوه‌ی استفاده از پلی‌لیست‌ها
- تب پایین صفحه **"آهنگ‌ها"** و **"پلی‌لیست‌ها"** رو می‌بینی
- روی هر آهنگ توی لیست اصلی، **نگه‌دار (Long Press)** تا منوی افزودن به پلی‌لیست باز بشه
- از تب پلی‌لیست‌ها، با دکمه‌ی **+** پلی‌لیست جدید بساز
- با زدن روی یه پلی‌لیست، آهنگ‌های داخلش رو می‌بینی و می‌تونی پخش کنی
