# شب شمشیر: ساخت APK با GitHub

## ساخت APK (بدون نصب چیزی روی کامپیوتر)
1. تو github.com یه مخزن (repository) جدید بساز (می‌تونه Private باشه).
2. زیپ رو باز کن و **همه‌ی فایل‌ها** رو به مخزن آپلود کن (Add file ← Upload files).
   - اگه پوشه‌ی `.github` آپلود نشد (چون با نقطه شروع می‌شه): Add file ← Create new file، اسمش رو بنویس `.github/workflows/android.yml` و محتوای فایل `android.yml.txt` رو توش بذار.
3. تب **Actions** ← «Build APK» ← اگه دکمه‌ی Run workflow بود بزن. حدود ۵ تا ۱۰ دقیقه طول می‌کشه.
4. بعد از سبز شدن، وارد اجرا شو و پایین صفحه از قسمت **Artifacts** فایل `ShabShamshir-apk` رو دانلود کن (zip، داخلش app-debug.apk).
5. روی گوشی نصبش کن (اجازه‌ی نصب از منبع ناشناس رو بده).

## تست روی کامپیوتر
```
npm install
npm run serve
```
بعد صفحه‌ی نشون‌داده‌شده رو باز کن.

## اضافه کردن انیمیشن
فایل FBX (Without Skin) رو بذار تو `www/assets/anims/hero/` و اسمش رو توی `www/assets/manifest.json` تو بخش heroAnims اضافه کن.
انیمیشن‌های پارکور هم تو `www/assets/anims/parkour/` هستن (فعلاً استفاده نشدن).

## کنترل
گوشی: جوی‌استیک چپ، کشیدن انگشت راست برای دوربین، ⚔ حمله، 🛡 بلاک (نگه دار)، 💨 غلت.
کیبورد: WASD، J حمله، K بلاک، Shift یا Space غلت.
