const fs=require('fs');
fs.mkdirSync('www/lib',{recursive:true});
[['build/three.min.js','three.min.js'],['examples/js/libs/fflate.min.js','fflate.min.js'],['examples/js/loaders/FBXLoader.js','FBXLoader.js'],['examples/js/utils/SkeletonUtils.js','SkeletonUtils.js']]
 .forEach(([a,b])=>fs.copyFileSync('node_modules/three/'+a,'www/lib/'+b));
console.log('libs copied');
