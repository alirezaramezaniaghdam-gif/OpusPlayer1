// copies three.js + loaders from node_modules into www/lib (so the app works offline)
const fs = require('fs');
fs.mkdirSync('www/lib', { recursive: true });
const files = [
  ['build/three.min.js', 'three.min.js'],
  ['examples/js/libs/fflate.min.js', 'fflate.min.js'],
  ['examples/js/loaders/FBXLoader.js', 'FBXLoader.js'],
  ['examples/js/utils/SkeletonUtils.js', 'SkeletonUtils.js'],
];
for (const [a, b] of files) {
  const src = 'node_modules/three/' + a;
  if (!fs.existsSync(src)) { console.error('missing file: ' + src); process.exit(1); }
  fs.copyFileSync(src, 'www/lib/' + b);
}
console.log('libs localized');
