const fs=require('fs');
const p='android/app/src/main/AndroidManifest.xml';
let x=fs.readFileSync(p,'utf8');
if(!x.includes('screenOrientation')) x=x.replace('<activity','<activity android:screenOrientation="sensorLandscape"');
fs.writeFileSync(p,x);
const sp='android/app/src/main/res/values/styles.xml';
if(fs.existsSync(sp)){let s=fs.readFileSync(sp,'utf8');
 s=s.replace(/(<style name="AppTheme\.NoActionBar"[^>]*>)/,'$1\n        <item name="android:windowFullscreen">true</item>');fs.writeFileSync(sp,s)}
console.log('android patched');
