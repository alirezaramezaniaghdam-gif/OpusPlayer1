
(function(){
var T=THREE,SU=T.SkeletonUtils,$=function(i){return document.getElementById(i)},R=function(a,b){return a+Math.random()*(b-a)};
var fa=function(n){return String(n).replace(/\d/g,function(d){return "۰۱۲۳۴۵۶۷۸۹"[d]})};
var ren=new T.WebGLRenderer({antialias:true});ren.setPixelRatio(Math.min(devicePixelRatio,1.75));ren.setSize(innerWidth,innerHeight);
ren.outputEncoding=T.sRGBEncoding;ren.toneMapping=T.ACESFilmicToneMapping;ren.toneMappingExposure=1.05;ren.shadowMap.enabled=true;ren.shadowMap.type=T.PCFSoftShadowMap;document.body.appendChild(ren.domElement);
var scene=new T.Scene();scene.fog=new T.Fog(0x0b1020,14,85);
var cam=new T.PerspectiveCamera(60,innerWidth/innerHeight,.1,400);
scene.add(new T.Mesh(new T.SphereGeometry(300,24,16),new T.ShaderMaterial({side:T.BackSide,depthWrite:false,fog:false,vertexShader:"varying vec3 p;void main(){p=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}",
 fragmentShader:"varying vec3 p;void main(){float h=normalize(p).y;vec3 a=vec3(.1,.13,.22),b=vec3(.02,.03,.07);gl_FragColor=vec4(mix(a,b,smoothstep(0.,.5,h)),1.);}"})));
function glowTex(){var c=document.createElement("canvas");c.width=c.height=64;var x=c.getContext("2d"),g=x.createRadialGradient(32,32,0,32,32,32);g.addColorStop(0,"rgba(255,255,255,1)");g.addColorStop(.3,"rgba(255,255,255,.4)");g.addColorStop(1,"rgba(255,255,255,0)");x.fillStyle=g;x.fillRect(0,0,64,64);return new T.CanvasTexture(c)}
var GT=glowTex();
function glow(col,s,x,y,z,fog){var sp=new T.Sprite(new T.SpriteMaterial({map:GT,color:col,blending:T.AdditiveBlending,depthWrite:false,fog:!!fog,transparent:true}));sp.scale.set(s,s,1);sp.position.set(x,y,z);scene.add(sp);return sp}
glow(0x9fb4ff,150,-90,80,-170);var moon=new T.Mesh(new T.SphereGeometry(7,20,16),new T.MeshBasicMaterial({color:0xeef3ff,fog:false}));moon.position.set(-90,80,-170);scene.add(moon);
scene.add(new T.HemisphereLight(0x6a7ab0,0x14141c,.6));
var sun=new T.DirectionalLight(0x9fb4ff,1.0);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);var sc=sun.shadow.camera;sc.left=-24;sc.right=24;sc.top=24;sc.bottom=-24;sc.far=90;sun.shadow.bias=-.0006;scene.add(sun);scene.add(sun.target);
var torch=new T.PointLight(0xffa050,1.5,18,2);scene.add(torch);
var grad=new T.DataTexture(new Uint8Array([70,140,200,255]),4,1,T.LuminanceFormat);grad.minFilter=grad.magFilter=T.NearestFilter;grad.needsUpdate=true;
function toon(c,e){return new T.MeshToonMaterial({color:c,gradientMap:grad,emissive:e||0})}
function mk(g,c,x,y,z,e){var m=new T.Mesh(g,toon(c,e));m.position.set(x,y,z);m.castShadow=m.receiveShadow=true;scene.add(m);return m}
// arena
var COL=[];
var gr=new T.Mesh(new T.CircleGeometry(120,48),toon(0x1e2230));gr.rotation.x=-Math.PI/2;gr.receiveShadow=true;scene.add(gr);
var fl=new T.Mesh(new T.CircleGeometry(31,48),toon(0x33384a));fl.rotation.x=-Math.PI/2;fl.position.y=.02;fl.receiveShadow=true;scene.add(fl);
mk(new T.CylinderGeometry(5,5.4,.4,24),0x3d4357,0,.2,0);mk(new T.TorusGeometry(30.5,.4,6,48),0x555c72,0,.3,0).rotation.x=Math.PI/2;
for(var i=0;i<12;i++){var a=i/12*6.283,hh=R(2.5,7),px=Math.cos(a)*27,pz=Math.sin(a)*27;mk(new T.CylinderGeometry(.9,1.1,hh,8),0x4a5066,px,hh/2,pz);if(i%2)mk(new T.BoxGeometry(2,.6,2),0x4a5066,px+R(-1,1),hh+.3,pz);COL.push({x:px,z:pz,r:1.3})}
for(i=0;i<5;i++){var ra=R(0,6.28),rr=R(8,20),bx=Math.cos(ra)*rr,bz=Math.sin(ra)*rr;mk(new T.BoxGeometry(R(1,2),R(.6,1.4),R(1,2)),0x3a4054,bx,.5,bz);COL.push({x:bx,z:bz,r:1.2})}
[[-12,-12],[12,-12],[-12,12],[12,12]].forEach(function(p,k){mk(new T.CylinderGeometry(.5,.7,1.2,8),0x2a2d38,p[0],.6,p[1]);mk(new T.SphereGeometry(.45,10,8),0xff7a2a,p[0],1.5,p[1],0xff6a1a);glow(0xff8a30,6,p[0],1.7,p[1]);COL.push({x:p[0],z:p[1],r:.9});if(k<2){var pl2=new T.PointLight(0xff8a30,.9,14,2);pl2.position.set(p[0],2,p[1]);scene.add(pl2)}});
for(i=0;i<40;i++){var ta=R(0,6.28),tr=R(36,90),tx=Math.cos(ta)*tr,tz=Math.sin(ta)*tr,th=R(5,11);var t1=mk(new T.CylinderGeometry(.15,.4,th,5),0x1a1c24,tx,th/2,tz);t1.rotation.z=R(-.15,.15);mk(new T.ConeGeometry(R(.5,1),R(2,4),5),0x15171e,tx+R(-1,1),th*.8,tz)}
for(i=0;i<14;i++){var ma=i/14*6.28,mt=new T.Mesh(new T.ConeGeometry(R(25,45),R(40,80),6),new T.MeshLambertMaterial({color:0x10131e}));mt.position.set(Math.cos(ma)*R(170,210),-3,Math.sin(ma)*R(170,210));scene.add(mt)}
var EN2=150,eg=new T.BufferGeometry(),ea=new Float32Array(EN2*3);for(i=0;i<EN2;i++){ea[i*3]=R(-30,30);ea[i*3+1]=R(0,12);ea[i*3+2]=R(-30,30)}eg.setAttribute("position",new T.BufferAttribute(ea,3));
scene.add(new T.Points(eg,new T.PointsMaterial({color:0xff9a4a,size:.18,transparent:true,opacity:.85,blending:T.AdditiveBlending,depthWrite:false})));
// particles
var P=[],sg=new T.SphereGeometry(.1,6,5);for(i=0;i<80;i++){var pm=new T.Mesh(sg,new T.MeshBasicMaterial({color:0xffffff,transparent:true,blending:T.AdditiveBlending,depthWrite:false}));pm.visible=false;pm.v=new T.Vector3();pm.l=0;pm.m=1;scene.add(pm);P.push(pm)}
function burst(x,y,z,n,col,sp){for(var k=0,j=0;k<P.length&&j<n;k++){var m=P[k];if(m.l<=0){m.l=m.m=R(.3,.6);m.position.set(x,y,z);m.v.set(R(-.5,.5)*sp,R(.1,.9)*sp,R(-.5,.5)*sp);m.material.color.setHex(col);m.visible=true;j++}}}
// loaders & anim
var FL=new T.FBXLoader(),MF=null,BASE="assets/";
function getBuf(u){return fetch(BASE+u).then(function(r){if(!r.ok)throw new Error(u);return r.arrayBuffer()})}
function tex(u){var t=new T.TextureLoader().load(BASE+u);t.encoding=T.sRGBEncoding;return t}
function proto(ab,tm,h){var o=FL.parse(ab,""),cache={},first=Object.keys(tm)[0];
 function mat(n){var k=tm[n]?n:first;return cache[k]||(cache[k]=new T.MeshToonMaterial({map:tex(tm[k]),gradientMap:grad,skinning:true}))}
 o.traverse(function(m){if(m.isMesh){m.material=Array.isArray(m.material)?m.material.map(function(x){return mat(x.name)}):mat(m.material.name);m.castShadow=true;m.frustumCulled=false}});
 var w=new T.Group();w.add(o);var bb=new T.Box3().setFromObject(w),s=h/Math.max(bb.max.y-bb.min.y,1e-3);o.scale.multiplyScalar(s);bb=new T.Box3().setFromObject(w);o.position.y-=bb.min.y;return{w:w,s:s}}
function loadClips(map){var ks=Object.keys(map);return Promise.all(ks.map(function(k){return getBuf(map[k]).then(function(ab){var g=FL.parse(ab,""),c=g.animations[0];c.name=k;c.tracks.forEach(function(t){if(/Hips\.position$/.test(t.name)){var v=t.values;for(var j=0;j<v.length;j+=3){v[j]=v[0];v[j+2]=v[2]}}});return c})})).then(function(a){var o={};a.forEach(function(c){o[c.name]=c});return o})}
function mkC(root,cl){return{mix:new T.AnimationMixer(root),cl:cl,cn:null,ca:null,hold:0}}
function act(C,n,once,dur,fade){var c=C.cl[n];if(!c||(C.cn===n&&!once))return;var a=C.mix.clipAction(c),f=fade==null?.12:fade;a.reset();a.enabled=true;a.setLoop(once?T.LoopOnce:T.LoopRepeat,Infinity);a.clampWhenFinished=!!once;a.timeScale=dur?c.duration/dur:1;a.fadeIn(f);if(C.ca&&C.ca!==a)C.ca.fadeOut(f);a.play();C.ca=a;C.cn=n;C.hold=once?(dur||c.duration):0}
// save + coins
var SV={coins:0,own:["ch44"],sel:"ch44"};
try{var q0=JSON.parse(localStorage.getItem("sbSave")||"null");if(q0){SV.coins=q0.coins|0;SV.own=q0.own||SV.own;SV.sel=q0.sel||SV.sel}}catch(e){}
function save(){try{localStorage.setItem("sbSave",JSON.stringify(SV))}catch(e){}}
function gain(e){SV.coins+=e.boss?60+H.wave*5:4+H.wave;hud()}
// hero
var hg=new T.Group();scene.add(hg);var ph=new T.Group();ph.add(mk(new T.CylinderGeometry(.35,.4,1.2,10),0x3f6fd8,0,.7,0));ph.add(mk(new T.SphereGeometry(.3,12,10),0xffdcc0,0,1.55,0));hg.add(ph);
var HC={mix:null,cl:{},cn:null,ca:null,hold:0},sw=null,swI=2,curRoot=null,heroBusy=false;
var SWO=[[0,0,0],[Math.PI,0,0],[0,0,-Math.PI/2],[0,0,Math.PI/2],[Math.PI/2,0,0],[-Math.PI/2,0,0]];
function attachSword(w,s){var hand=w.getObjectByName("mixamorigRightHand");sw=null;if(!hand)return;sw=new T.Group();sw.scale.setScalar(1/s);
 var bl=new T.Mesh(new T.BoxGeometry(.05,1.4,.12),new T.MeshBasicMaterial({color:0xcff6ff}));bl.position.y=.75;sw.add(bl);sw.add(new T.Mesh(new T.BoxGeometry(.3,.07,.12),new T.MeshBasicMaterial({color:0xffd24a})));hand.add(sw);var o=SWO[swI];sw.rotation.set(o[0],o[1],o[2])}
function skinOf(id){var r=null;MF.skins.forEach(function(x){if(x.c===id)r=x});return r}
function setHero(id){var sk=skinOf(id);if(!sk||heroBusy)return Promise.resolve();heroBusy=true;var ch=MF.chars[id];
 return getBuf(ch.fbx).then(function(ab){var pr=proto(ab,ch.tex,sk.h);if(curRoot)hg.remove(curRoot);else hg.remove(ph);curRoot=pr.w;hg.add(pr.w);HC.mix=new T.AnimationMixer(pr.w);HC.cn=null;HC.ca=null;HC.hold=0;attachSword(pr.w,pr.s);act(HC,"idle",false,0,0);SV.sel=id;save()})
  .catch(function(e){console.log(e);toast("بارگذاری شخصیت ناموفق بود")}).then(function(){heroBusy=false})}
$("sw").addEventListener("pointerdown",function(e){e.preventDefault();if(!sw)return;swI=(swI+1)%6;var o=SWO[swI];sw.rotation.set(o[0],o[1],o[2]);toast("جهت شمشیر: "+fa(swI+1)+" از ۶")});
function renderShop(){var h='<div style="color:#ffd24a">🪙 '+fa(SV.coins)+'</div>';MF.skins.forEach(function(s){var own=SV.own.indexOf(s.c)>=0;h+='<button data-c="'+s.c+'">'+s.n+' · '+(own?(SV.sel===s.c?"✅ انتخاب‌شده":"انتخاب"):fa(s.p)+" 🪙")+'</button>'});$("shop").innerHTML=h}
$("shop").onclick=function(e){var b=e.target.closest("button");if(!b||!MF)return;var c=b.dataset.c,sk=skinOf(c);if(!sk)return;
 if(SV.own.indexOf(c)<0){if(SV.coins<sk.p){toast("سکه کافی نیست");return}SV.coins-=sk.p;SV.own.push(c)}
 save();hud();setHero(c).then(renderShop)};
$("sh").onclick=function(){var s=$("shop");s.style.display=s.style.display==="flex"?"none":"flex";if(MF)renderShop()};
// enemies data
var ET={},ZC=null,EN=[],ready=false;
var TYPES={zgirl:{h:1.75,hp:4,spd:3.3,dmg:8,rng:1.7},yaku:{h:1.8,hp:5,spd:2.2,dmg:10,rng:1.8},skel:{h:1.85,hp:5,spd:2.7,dmg:10,rng:1.8},para:{h:1.8,hp:6,spd:3.6,dmg:9,rng:1.7},hulk:{h:2.9,hp:45,spd:1.9,dmg:26,rng:2.7,boss:1}};
function loadEnemies(){var keys=["zgirl","yaku","skel","para","hulk"];return loadClips(MF.zombieAnims).then(function(z){ZC=z;return keys.reduce(function(p,k){return p.then(function(){var ch=MF.chars[k];return getBuf(ch.fbx).then(function(ab){ET[k]=proto(ab,ch.tex,TYPES[k].h)})})},Promise.resolve())}).then(function(){ready=true;$("ld").textContent="✅ همه‌چیز آماده"})}
function boot(){fetch(BASE+"manifest.json").then(function(r){return r.json()}).then(function(m){MF=m;$("ld").textContent="در حال بارگذاری شخصیت...";return loadClips(m.heroAnims).then(function(c){HC.cl=c;return setHero(SV.sel)})})
 .then(function(){$("ld").textContent="در حال بارگذاری دشمن‌ها...";return loadEnemies()}).catch(function(e){console.log(e);$("ld").textContent="خطا در بارگذاری فایل‌ها: پوشه‌ی assets کنار صفحه هست؟"})}
boot();
function mkEnemy(key){var ty=TYPES[key],g=new T.Group(),e={key:key,g:g,hp:ty.hp,spd:ty.spd,dmg:ty.dmg,rng:ty.rng,boss:!!ty.boss,dead:0,spawn:1.1,stun:0,cd:R(.3,1),atk:0,hit:1,flash:0,kx:0,kz:0,mats:[],C:{mix:null,cl:{},cn:null,ca:null,hold:0}};
 if(ready&&ET[key]){var m=SU.clone(ET[key].w);m.traverse(function(o){if(o.isMesh){o.material=Array.isArray(o.material)?o.material.map(function(x){var c=x.clone();e.mats.push(c);return c}):(function(x){var c=x.clone();e.mats.push(c);return c})(o.material)}});g.add(m);e.C=mkC(m,ZC);act(e.C,"zScream",true,1.1,.05)}
 else{var b=mk(new T.CylinderGeometry(.4,.5,1.3,8),0x552233,0,.75,0);g.add(b);g.add(mk(new T.SphereGeometry(.35,10,8),0x884455,0,1.65,0));e.mats.push(b.material)}
 var a=R(0,6.28);g.position.set(Math.cos(a)*25,0,Math.sin(a)*25);scene.add(g);EN.push(e);return e}
// hero state
var H={on:0,x:0,z:8,vx:0,vz:0,face:Math.PI,yaw:0,hp:100,stam:100,mode:"free",at:0,dur:0,hitT:0,hitDone:1,ci:0,comboT:0,buf:0,inv:0,jx:0,jy:0,keys:{},blockHeld:0,rx:0,rz:0,shake:0,ts:1,wave:0,kills:0,next:0,dead:0};
var ATK=[{n:"s1",d:.5,h:.4,dmg:1,l:4.5},{n:"s2",d:.5,h:.4,dmg:1,l:4.5},{n:"s3",d:.75,h:.42,dmg:1.6,l:5.5},{n:"s4",d:.6,h:.4,dmg:2.2,l:6}];function gy(x,z){var r=Math.hypot(x,z);return r<=5?.4:r<5.4?.4*(5.4-r)/.4:0}
function moveClip(){var f=H.face,sn=Math.sin(f),cs=Math.cos(f),vf=H.vx*sn+H.vz*cs,vl=H.vx*cs-H.vz*sn,sp=Math.hypot(vf,vl);if(sp<.8)return["idle",1];var run=sp>5.5,n,nat;
 if(Math.abs(vl)>Math.abs(vf)*.8){n=vl>0?(run?"rL":"sL"):(run?"rR":"sR");nat={rL:2.6,rR:3.4,sL:1.46,sR:1.68}[n]}else if(vf>0){n=run?"runF":"walkF";nat=run?4.7:1.4}else{n=run?"runB":"walkB";nat=run?2.95:1.27}
 return[n,Math.min(2.8,Math.max(.6,sp/nat))]}
function toast(s){var t=$("toast");t.textContent=s;t.style.opacity=1;clearTimeout(toast.h);toast.h=setTimeout(function(){t.style.opacity=0},1500)}
function hud(){$("hp").style.width=Math.max(0,H.hp)+"%";$("sp").style.width=Math.max(0,H.stam)+"%";$("wv").textContent="موج "+fa(H.wave);$("kl").textContent="☠ "+fa(H.kills);$("cn").textContent="🪙 "+fa(SV.coins)}
function nearest(r){var b=null,bd=r;EN.forEach(function(e){if(e.dead||e.spawn>0)return;var d=Math.hypot(e.g.position.x-H.x,e.g.position.z-H.z);if(d<bd){bd=d;b=e}});return b}
function startAtk(){if(H.stam<8)return;var idx=H.comboT>0?(H.ci+1)%4:0,a=ATK[idx];H.ci=idx;H.mode="atk";H.at=0;H.dur=a.d;H.hitT=a.d*a.h;H.hitDone=0;H.buf=0;H.stam-=10;
 var n=nearest(7);if(n)H.face=Math.atan2(n.g.position.x-H.x,n.g.position.z-H.z);else if(Math.hypot(H.jx,H.jy)>.3){var sn=Math.sin(H.yaw),cs=Math.cos(H.yaw);H.face=Math.atan2(H.jx*cs+H.jy*sn,-H.jx*sn+H.jy*cs)}
 act(HC,a.n,true,a.d,.06)}
function attack(){if(!H.on||H.dead)return;if(H.mode==="free"||H.mode==="block")startAtk();else if(H.mode==="atk")H.buf=1}
function strike(){var a=ATK[H.ci],fx=Math.sin(H.face),fz=Math.cos(H.face),rg=H.ci===3?3.6:3.1,any=0;
 EN.forEach(function(e){if(e.dead)return;var dx=e.g.position.x-H.x,dz=e.g.position.z-H.z,d=Math.hypot(dx,dz)||1;if(d<rg&&(dx*fx+dz*fz)/d>.1){any=1;e.hp-=a.dmg;e.flash=.12;e.stun=e.boss?.12:(H.ci>=2?.6:.35);var kb=(e.boss?2:H.ci>=2?9:5);e.kx=dx/d*kb;e.kz=dz/d*kb;e.atk=0;e.hit=1;
  burst(e.g.position.x,1.2,e.g.position.z,H.ci>=2?16:9,H.ci>=2?0xffd24a:0xbfe0ff,6);
  if(e.hp<=0){e.dead=2.6;act(e.C,"zDie",true,1.4,.08);H.kills++;gain(e);burst(e.g.position.x,1,e.g.position.z,26,0xff5a3a,8);hud()}}});
 if(any){H.ts=.1;H.shake=H.ci>=2?.45:.22}}
function dodge(){if(!H.on||H.dead||H.stam<20||H.mode==="roll"||H.mode==="hit")return;var sn=Math.sin(H.yaw),cs=Math.cos(H.yaw),d=Math.hypot(H.jx,H.jy);
 if(d>.3){var ix=H.jx/d,iy=H.jy/d;H.rx=ix*cs+iy*sn;H.rz=-ix*sn+iy*cs}else{H.rx=Math.sin(H.face);H.rz=Math.cos(H.face)}
 H.face=Math.atan2(H.rx,H.rz);H.mode="roll";H.at=0;H.stam-=20;H.inv=.55;act(HC,"roll",true,.5,.05);burst(H.x,.3,H.z,8,0x8890a8,3)}
function hurtHero(dmg,src){if(H.dead||H.inv>0)return;var dx=src.g.position.x-H.x,dz=src.g.position.z-H.z,d=Math.hypot(dx,dz)||1,front=(dx*Math.sin(H.face)+dz*Math.cos(H.face))/d>.2;
 if(H.mode==="block"&&front&&H.stam>0){H.stam-=14;burst(H.x+dx/d*.8,1.3,H.z+dz/d*.8,12,0xffe9a0,5);H.shake=.2;H.inv=.2;if(H.stam<=0){H.stam=0;stagger()}return}
 H.hp-=dmg;H.inv=.5;H.shake=.5;burst(H.x,1.2,H.z,12,0xaa1020,5);hud();if(H.hp<=0){die();return}stagger()}
function stagger(){H.mode="hit";H.at=0;act(HC,"hit",true,.5,.05)}
function die(){save();H.dead=1;H.mode="dead";act(HC,"die",true,1.8,.08);setTimeout(function(){H.on=0;$("msg").innerHTML="💀 سقوط کردی.<br>به موج "+fa(H.wave)+" رسیدی و "+fa(H.kills)+" دشمن کشتی.";$("go").textContent="دوباره";$("ov").style.display="flex"},2000)}
function bl(v){H.blockHeld=v}
function wave(){H.wave++;var ks=["zgirl","yaku","skel","para"],n=Math.min(2+Math.floor(H.wave*1.4),9);for(var i=0;i<n;i++)mkEnemy(ks[(Math.random()*4)|0]);if(H.wave%5===0){mkEnemy("hulk");toast("⚠ غول کدوئی!")}else toast("موج "+fa(H.wave));hud()}
function reset(){EN.forEach(function(e){scene.remove(e.g)});EN.length=0;H.hp=100;H.stam=100;H.x=0;H.z=8;H.mode="free";H.dead=0;H.wave=0;H.kills=0;H.inv=0;H.on=1;H.next=0;H.face=Math.PI;act(HC,"idle",false,0,0);hud();wave()}
$("go").onclick=function(){$("ov").style.display="none";reset()};
// input
var joy=$("joy"),knob=$("knob"),jid=null,cid=null,lx=0;
function jm(e){var r=joy.getBoundingClientRect(),dx=e.clientX-(r.left+65),dy=e.clientY-(r.top+65),d=Math.hypot(dx,dy);if(d>55){dx*=55/d;dy*=55/d}knob.style.left=(45+dx)+"px";knob.style.top=(45+dy)+"px";H.jx=dx/55;H.jy=dy/55}
joy.addEventListener("pointerdown",function(e){jid=e.pointerId;joy.setPointerCapture(jid);jm(e)});joy.addEventListener("pointermove",function(e){if(e.pointerId===jid)jm(e)});
function je(e){if(e.pointerId===jid){jid=null;H.jx=H.jy=0;knob.style.left="45px";knob.style.top="45px"}}joy.addEventListener("pointerup",je);joy.addEventListener("pointercancel",je);
ren.domElement.addEventListener("pointerdown",function(e){if(cid===null&&e.clientX>innerWidth*.35){cid=e.pointerId;lx=e.clientX}});
addEventListener("pointermove",function(e){if(e.pointerId===cid){H.yaw-=(e.clientX-lx)*.008;lx=e.clientX}});addEventListener("pointerup",function(e){if(e.pointerId===cid)cid=null});
$("at").addEventListener("pointerdown",function(e){e.preventDefault();attack()});$("dg").addEventListener("pointerdown",function(e){e.preventDefault();dodge()});
var blb=$("bl");blb.addEventListener("pointerdown",function(e){e.preventDefault();blb.setPointerCapture(e.pointerId);bl(1)});blb.addEventListener("pointerup",function(){bl(0)});blb.addEventListener("pointercancel",function(){bl(0)});
addEventListener("keydown",function(e){var k=e.key.toLowerCase();H.keys[k]=1;if(k==="j")attack();if(k==="shift"||k===" ")dodge();if(k==="k")bl(1)});addEventListener("keyup",function(e){var k=e.key.toLowerCase();H.keys[k]=0;if(k==="k")bl(0)});
addEventListener("resize",function(){cam.aspect=innerWidth/innerHeight;cam.updateProjectionMatrix();ren.setSize(innerWidth,innerHeight)});
function collide(o,r){COL.forEach(function(c){var dx=o.x-c.x,dz=o.z-c.z,d=Math.hypot(dx,dz),m=c.r+r;if(d<m&&d>0){o.x=c.x+dx/d*m;o.z=c.z+dz/d*m}});var rr=Math.hypot(o.x,o.z);if(rr>29){o.x*=29/rr;o.z*=29/rr}}
// loop
var clk=new T.Clock(),camP=new T.Vector3(),ang=function(a){return Math.atan2(Math.sin(a),Math.cos(a))};
function loop(){requestAnimationFrame(loop);var raw=Math.min(clk.getDelta(),.05);H.ts=Math.min(1,H.ts+raw*7);var dt=raw*H.ts,t=clk.elapsedTime;
 if(H.on&&!H.dead){H.inv-=dt;H.comboT-=dt;H.stam=Math.min(100,H.stam+(H.mode==="block"?3:(H.mode==="atk"?5:24))*dt);
  var ix=H.jx+(H.keys.d||H.keys.arrowright?1:0)-(H.keys.a||H.keys.arrowleft?1:0),iy=H.jy+(H.keys.s||H.keys.arrowdown?1:0)-(H.keys.w||H.keys.arrowup?1:0),d=Math.hypot(ix,iy);if(d>1){ix/=d;iy/=d;d=1}
  var sn=Math.sin(H.yaw),cs=Math.cos(H.yaw),mx=ix*cs+iy*sn,mz=-ix*sn+iy*cs,tx=0,tz=0;
  if(H.mode==="free"||H.mode==="block"){var want=H.blockHeld&&H.stam>0;if(want&&H.mode!=="block"){H.mode="block";act(HC,"block",true,.45,.1)}else if(!want&&H.mode==="block"){H.mode="free";HC.hold=0}
   var lt=nearest(12),spd=H.mode==="block"?3.4:(lt?8.2:9.8);tx=mx*spd;tz=mz*spd;
   if(lt){H.face+=ang(Math.atan2(lt.g.position.x-H.x,lt.g.position.z-H.z)-H.face)*Math.min(1,dt*16)}else if(d>.1&&H.mode==="free")H.face+=ang(Math.atan2(mx,mz)-H.face)*Math.min(1,dt*14);
   if(HC.hold<=0&&H.mode==="free"){var mc=moveClip();act(HC,mc[0],false,0,.12);if(HC.ca&&HC.cn===mc[0])HC.ca.timeScale=mc[1]}}
  else if(H.mode==="atk"){H.at+=dt;var a=ATK[H.ci],lk=H.at<H.hitT?a.l:0;tx=Math.sin(H.face)*lk;tz=Math.cos(H.face)*lk;if(!H.hitDone&&H.at>=H.hitT){H.hitDone=1;strike()}
   if(H.at>=H.dur){H.comboT=.55;H.mode="free";HC.hold=0;if(H.buf)startAtk()}}
  else if(H.mode==="roll"){H.at+=dt;tx=H.rx*15;tz=H.rz*15;if(H.at>=.5){H.mode="free";HC.hold=0}}
  else if(H.mode==="hit"){H.at+=dt;if(H.at>=.45){H.mode="free";HC.hold=0}}
  H.vx+=(tx-H.vx)*Math.min(1,dt*16);H.vz+=(tz-H.vz)*Math.min(1,dt*16);H.x+=H.vx*dt;H.z+=H.vz*dt;collide(H,.45);
  // enemies
  var alive=0;
  for(var q=EN.length-1;q>=0;q--){var e=EN[q],p=e.g.position;if(e.C.mix)e.C.mix.update(dt);
   if(e.dead){e.dead-=dt;if(e.dead<1)p.y-=dt*.7;if(e.dead<=0){scene.remove(e.g);EN.splice(q,1)}continue}alive++;
   if(e.spawn>0){e.spawn-=dt;if(e.spawn<=0)e.C.hold=0;continue}
   var dx=H.x-p.x,dz=H.z-p.z,dd=Math.hypot(dx,dz)||1;
   if(e.flash>0){e.flash-=dt;e.mats.forEach(function(m){if(m.emissive)m.emissive.setHex(0xffffff)})}else e.mats.forEach(function(m){if(m.emissive)m.emissive.setHex(0)});
   p.x+=e.kx*dt;p.z+=e.kz*dt;e.kx*=.86;e.kz*=.86;
   if(e.stun>0){e.stun-=dt;if(e.C.hold<=0)act(e.C,"zIdle",false,0,.1)}
   else if(e.atk>0){e.atk-=dt;e.cd=e.boss?1.4:1.1;if(!e.hit&&e.atk<=e.ad*.5){e.hit=1;if(dd<e.rng+.8)hurtHero(e.dmg,e)}if(e.atk<=0)e.C.hold=0}
   else{e.cd-=dt;
    if(dd>e.rng){var sp2=e.spd*1.2*(1+H.wave*.02);p.x+=dx/dd*sp2*dt;p.z+=dz/dd*sp2*dt;act(e.C,sp2>2.5?"zRun":"zWalk",false,0,.2);if(e.C.ca)e.C.ca.timeScale=Math.max(.7,sp2/(sp2>2.5?3.4:2))}
    else if(e.cd<=0){e.ad=e.boss?1.3:1;e.atk=e.ad;e.hit=0;act(e.C,"zAtk",true,e.ad,.1)}
    else act(e.C,"zIdle",false,0,.15)}
   e.g.rotation.y+=ang(Math.atan2(dx,dz)-e.g.rotation.y)*Math.min(1,dt*(e.atk>0?3:9));
   for(var w=0;w<EN.length;w++){var o=EN[w];if(o===e||o.dead)continue;var ox=p.x-o.g.position.x,oz=p.z-o.g.position.z,od=Math.hypot(ox,oz);if(od<1&&od>0){p.x+=ox/od*dt*2;p.z+=oz/od*dt*2}}
   collide(p,.5);p.y=gy(p.x,p.z)}
  if(alive===0&&H.on){H.next+=dt;if(H.next>3){H.next=0;H.hp=Math.min(100,H.hp+20);H.stam=100;SV.coins+=15+H.wave*5;save();wave()}}
  hud()}
 if(HC.mix)HC.mix.update(dt);
 for(var k=0;k<P.length;k++){var m=P[k];if(m.l>0){m.l-=raw;m.v.y-=9*raw;m.position.addScaledVector(m.v,raw);m.scale.setScalar(Math.max(.01,m.l/m.m));if(m.l<=0)m.visible=false}}
 var ea2=eg.attributes.position.array;for(k=0;k<EN2;k++){ea2[k*3+1]+=raw*(.4+(k%4)*.15);ea2[k*3]+=Math.sin(t+k)*raw*.3;if(ea2[k*3+1]>14){ea2[k*3+1]=0;ea2[k*3]=H.x+R(-30,30);ea2[k*3+2]=H.z+R(-30,30)}}eg.attributes.position.needsUpdate=true;
 hg.position.set(H.x,gy(H.x,H.z),H.z);hg.rotation.y=H.face;torch.position.set(H.x,2.6,H.z);
 H.shake=Math.max(0,H.shake-raw*2);var cd=6.6;camP.set(H.x+Math.sin(H.yaw)*cd+R(-1,1)*H.shake,3.1+R(-1,1)*H.shake*.5,H.z+Math.cos(H.yaw)*cd);cam.position.lerp(camP,Math.min(1,raw*10));cam.lookAt(H.x,1.4+gy(H.x,H.z),H.z);
 sun.position.set(H.x-18,30,H.z-20);sun.target.position.set(H.x,0,H.z);
 ren.render(scene,cam)}
hud();loop();
})();
