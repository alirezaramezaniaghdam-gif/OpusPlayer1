// کتابخانه‌های CDN را دانلود و داخل APK می‌گذارد تا بازی بدون اینترنت هم اجرا شود
const fs=require('fs');
let h=fs.readFileSync('www/index.html','utf8');
fs.mkdirSync('www/libs',{recursive:true});
const list=[...h.matchAll(/<script src="(https:[^"]+)"><\/script>/g)];
(async()=>{
  for(const m of list){
    const u=m[1],n=u.split('/').pop();
    const r=await fetch(u); if(!r.ok) throw new Error('download failed: '+u);
    fs.writeFileSync('www/libs/'+n,Buffer.from(await r.arrayBuffer()));
    h=h.replace(u,'libs/'+n);
  }
  fs.writeFileSync('www/index.html',h);
  console.log('localized',list.length,'scripts');
})();
