package com.subflow.extractor

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFprobeKit
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

/**
 * Text-based subtitle codecs that ffmpeg can remux losslessly into .srt
 * (bitmap/image subtitle codecs like hdmv_pgs_subtitle or dvd_subtitle are
 * pictures, not text, so they are intentionally excluded).
 */
private val TEXT_SUBTITLE_CODECS = setOf(
    "subrip", "srt", "ass", "ssa", "mov_text", "webvtt", "text", "ttml"
)
private val IMAGE_SUBTITLE_CODECS = setOf(
    "hdmv_pgs_subtitle", "dvd_subtitle", "dvb_subtitle", "xsub"
)

data class SubtitleTrack(val index: Int, val codec: String, val language: String?)

class MainActivity : AppCompatActivity() {

    private lateinit var tvFileName: TextView
    private lateinit var tvStatus: TextView
    private lateinit var btnPick: TextView
    private lateinit var btnExtract: TextView
    private lateinit var btnShare: TextView

    private var inputFile: File? = null
    private var originalDisplayName: String = "video"
    private var pendingText: String = ""
    private var lastSavedUri: Uri? = null

    private val pickVideoLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) handlePickedVideo(uri)
    }

    private val createDocLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) writeTextToUri(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvFileName = findViewById(R.id.tv_file_name)
        tvStatus = findViewById(R.id.tv_status)
        btnPick = findViewById(R.id.btn_pick_video)
        btnExtract = findViewById(R.id.btn_extract)
        btnShare = findViewById(R.id.btn_share)

        btnPick.setOnClickListener {
            pickVideoLauncher.launch(arrayOf("*/*"))
        }

        btnExtract.setOnClickListener {
            if (inputFile != null) startExtraction()
        }

        btnShare.setOnClickListener { shareSavedFile() }
    }

    // ---------------- Step 1: copy the picked video into app cache ----------------

    private fun handlePickedVideo(uri: Uri) {
        originalDisplayName = queryDisplayName(uri) ?: "video"
        tvFileName.text = "در حال آماده‌سازی: $originalDisplayName"
        setExtractEnabled(false)
        btnShare.visibility = android.view.View.GONE

        CoroutineScope(Dispatchers.Main).launch {
            setStatus("در حال کپی ویدیو برای پردازش…")
            val file = withContext(Dispatchers.IO) { copyUriToCache(uri, originalDisplayName) }
            if (file == null) {
                setStatus("خطا در خواندن فایل انتخابی.")
                return@launch
            }
            inputFile = file
            tvFileName.text = "فایل انتخاب‌شده: $originalDisplayName"
            setStatus("آماده برای استخراج. دکمه‌ی ۲ را بزن.")
            setExtractEnabled(true)
        }
    }

    private fun copyUriToCache(uri: Uri, displayName: String): File? {
        return try {
            val ext = displayName.substringAfterLast('.', "mp4")
            val target = File(cacheDir, "input_${System.currentTimeMillis()}.$ext")
            contentResolver.openInputStream(uri)?.use { input ->
                target.outputStream().use { output -> input.copyTo(output) }
            } ?: return null
            target
        } catch (e: Exception) {
            null
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (cursor.moveToFirst() && nameIndex >= 0) cursor.getString(nameIndex) else null
            }
        } catch (e: Exception) {
            null
        }
    }

    // ---------------- Step 2: probe subtitle streams ----------------

    private fun startExtraction() {
        val file = inputFile ?: return
        setExtractEnabled(false)
        btnShare.visibility = android.view.View.GONE

        CoroutineScope(Dispatchers.Main).launch {
            setStatus("در حال بررسی زیرنویس‌های موجود در ویدیو…")
            val tracks = withContext(Dispatchers.IO) { probeSubtitleTracks(file) }

            if (tracks.text.isEmpty()) {
                setExtractEnabled(true)
                if (tracks.imageOnly) {
                    setStatus("این ویدیو فقط زیرنویس تصویری (مثل PGS/VobSub) دارد؛ این نوع زیرنویس عکس است نه متن و قابل استخراج به txt نیست.")
                } else {
                    setStatus("هیچ ردیف زیرنویس نرمی (soft sub) در این فایل پیدا نشد.")
                }
                return@launch
            }

            if (tracks.text.size == 1) {
                extractTrack(file, tracks.text.first())
            } else {
                val chosen = chooseTrackDialog(tracks.text)
                if (chosen != null) extractTrack(file, chosen) else setExtractEnabled(true)
            }
        }
    }

    private class ProbeResult(val text: List<SubtitleTrack>, val imageOnly: Boolean)

    private fun probeSubtitleTracks(file: File): ProbeResult {
        val command = "-v error -show_entries stream=index,codec_name,codec_type:stream_tags=language -of json \"${file.absolutePath}\""
        val session = FFprobeKit.execute(command)
        val output = session.output ?: return ProbeResult(emptyList(), false)

        val textTracks = mutableListOf<SubtitleTrack>()
        var foundImageSub = false
        try {
            val json = JSONObject(output)
            val streams = json.optJSONArray("streams") ?: return ProbeResult(emptyList(), false)
            for (i in 0 until streams.length()) {
                val s = streams.getJSONObject(i)
                if (s.optString("codec_type") != "subtitle") continue
                val codec = s.optString("codec_name")
                val index = s.optInt("index")
                val lang = s.optJSONObject("tags")?.optString("language")
                when {
                    TEXT_SUBTITLE_CODECS.contains(codec) -> textTracks.add(SubtitleTrack(index, codec, lang))
                    IMAGE_SUBTITLE_CODECS.contains(codec) -> foundImageSub = true
                }
            }
        } catch (e: Exception) {
            // ignore, return what we have
        }
        return ProbeResult(textTracks, foundImageSub && textTracks.isEmpty())
    }

    private suspend fun chooseTrackDialog(tracks: List<SubtitleTrack>): SubtitleTrack? =
        kotlinx.coroutines.suspendCancellableCoroutine { cont ->
            val labels = tracks.map { "ردیف ${it.index} — ${it.language ?: "زبان نامشخص"} (${it.codec})" }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle("چند زیرنویس پیدا شد — یکی را انتخاب کن")
                .setItems(labels) { _, which -> cont.resume(tracks[which]) { } }
                .setOnCancelListener { cont.resume(null) { } }
                .show()
        }

    // ---------------- Step 3: extract + clean the chosen track ----------------

    private fun extractTrack(file: File, track: SubtitleTrack) {
        CoroutineScope(Dispatchers.Main).launch {
            setStatus("در حال استخراج متن (ردیف ${track.index})…")
            val result = withContext(Dispatchers.IO) { runExtraction(file, track) }
            setExtractEnabled(true)

            if (result == null) {
                setStatus("استخراج ناموفق بود. شاید این فایل خراب است یا فرمت زیرنویس پشتیبانی نمی‌شود.")
                return@launch
            }
            if (result.isBlank()) {
                setStatus("زیرنویس پیدا شد ولی متنی داخلش نبود.")
                return@launch
            }

            pendingText = result
            setStatus("✅ استخراج موفق بود (${result.length} کاراکتر). حالا محل ذخیره فایل txt را انتخاب کن.")
            val suggestedName = originalDisplayName.substringBeforeLast('.') + ".txt"
            createDocLauncher.launch(suggestedName)
        }
    }

    private fun runExtraction(file: File, track: SubtitleTrack): String? {
        val srtFile = File(cacheDir, "sub_${System.currentTimeMillis()}.srt")
        val command = "-y -i \"${file.absolutePath}\" -map 0:${track.index} -f srt \"${srtFile.absolutePath}\""
        val session = FFmpegKit.execute(command)

        if (!ReturnCode.isSuccess(session.returnCode)) return null
        if (!srtFile.exists()) return null

        val plainText = srtToPlainText(srtFile.readText(Charsets.UTF_8))
        srtFile.delete()
        return plainText
    }

    /** Strips SRT index numbers, timestamps and basic style tags, keeping only dialogue lines. */
    private fun srtToPlainText(srt: String): String {
        val lines = srt.replace("\r\n", "\n").split("\n")
        val out = StringBuilder()
        val timeRegex = Regex("""\d{2}:\d{2}:\d{2}[,.]\d{3}\s*-->\s*\d{2}:\d{2}:\d{2}[,.]\d{3}""")
        val indexRegex = Regex("""^\d+$""")
        val tagRegex = Regex("""\{[^}]*}|<[^>]*>""")

        for (rawLine in lines) {
            val line = rawLine.trim()
            if (line.isEmpty() || indexRegex.matches(line) || timeRegex.containsMatchIn(line)) continue
            val cleaned = tagRegex.replace(line, "").trim()
            if (cleaned.isNotEmpty()) out.append(cleaned).append('\n')
        }
        return out.toString().trim()
    }

    // ---------------- Step 4: save & share ----------------

    private fun writeTextToUri(uri: Uri) {
        try {
            contentResolver.openOutputStream(uri)?.use { out ->
                out.write(pendingText.toByteArray(Charsets.UTF_8))
            }
            lastSavedUri = uri
            btnShare.visibility = android.view.View.VISIBLE
            setStatus("فایل txt ذخیره شد ✅")
            Toast.makeText(this, "ذخیره شد", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            setStatus("ذخیره‌سازی فایل با خطا مواجه شد.")
        }
    }

    private fun shareSavedFile() {
        val uri = lastSavedUri ?: return
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "اشتراک‌گذاری فایل زیرنویس"))
    }

    // ---------------- helpers ----------------

    private fun setStatus(text: String) {
        tvStatus.text = text
    }

    private fun setExtractEnabled(enabled: Boolean) {
        btnExtract.isClickable = enabled
        btnExtract.alpha = if (enabled) 1f else 0.4f
    }
}
