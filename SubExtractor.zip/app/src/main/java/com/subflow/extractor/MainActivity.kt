package com.subflow.extractor

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFprobeKit
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Bitmap/image subtitle codecs -- these are pictures, not text, so they can
 * never be turned into a .txt file without OCR (out of scope here).
 * Anything else reported as codec_type=subtitle is treated as a text candidate,
 * since minimal ffmpeg builds can name codecs in ways we can't fully predict.
 */
private val IMAGE_SUBTITLE_CODECS = setOf(
    "hdmv_pgs_subtitle", "dvd_subtitle", "dvb_subtitle", "xsub"
)

data class SubtitleTrack(val index: Int, val codec: String, val language: String?)

class MainActivity : AppCompatActivity() {

    private lateinit var tvFileName: TextView
    private lateinit var tvStatus: TextView
    private lateinit var btnPick: TextView
    private lateinit var btnExtract: TextView
    private lateinit var btnShare: TextView

    private var inputFile: File? = null
    private var originalDisplayName: String = "video"
    private var pendingText: String = ""
    private var lastSavedUri: Uri? = null

    private val pickVideoLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) handlePickedVideo(uri)
    }

    private val createDocLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) writeTextToUri(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvFileName = findViewById(R.id.tv_file_name)
        tvStatus = findViewById(R.id.tv_status)
        btnPick = findViewById(R.id.btn_pick_video)
        btnExtract = findViewById(R.id.btn_extract)
        btnShare = findViewById(R.id.btn_share)

        btnPick.setOnClickListener {
            pickVideoLauncher.launch(arrayOf("*/*"))
        }

        btnExtract.setOnClickListener {
            if (inputFile != null) startExtraction()
        }

        btnShare.setOnClickListener { shareSavedFile() }
    }

    // ---------------- Step 1: copy the picked video into app cache ----------------

    private fun handlePickedVideo(uri: Uri) {
        originalDisplayName = queryDisplayName(uri) ?: "video"
        tvFileName.text = "در حال آماده‌سازی: $originalDisplayName"
        setExtractEnabled(false)
        btnShare.visibility = android.view.View.GONE

        CoroutineScope(Dispatchers.Main).launch {
            setStatus("در حال کپی ویدیو برای پردازش…")
            val file = withContext(Dispatchers.IO) { copyUriToCache(uri, originalDisplayName) }
            if (file == null) {
                setStatus("خطا در خواندن فایل انتخابی.")
                return@launch
            }
            inputFile = file
            tvFileName.text = "فایل انتخاب‌شده: $originalDisplayName"
            setStatus("آماده برای استخراج. دکمه‌ی ۲ را بزن.")
            setExtractEnabled(true)
        }
    }

    private fun copyUriToCache(uri: Uri, displayName: String): File? {
        return try {
            val ext = displayName.substringAfterLast('.', "mp4")
            val target = File(cacheDir, "input_${System.currentTimeMillis()}.$ext")
            contentResolver.openInputStream(uri)?.use { input ->
                target.outputStream().use { output -> input.copyTo(output) }
            } ?: return null
            target
        } catch (e: Exception) {
            null
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (cursor.moveToFirst() && nameIndex >= 0) cursor.getString(nameIndex) else null
            }
        } catch (e: Exception) {
            null
        }
    }

    // ---------------- Step 2: probe subtitle streams ----------------

    private fun startExtraction() {
        val file = inputFile ?: return
        setExtractEnabled(false)
        btnShare.visibility = android.view.View.GONE

        CoroutineScope(Dispatchers.Main).launch {
            setStatus("در حال بررسی زیرنویس‌های موجود در ویدیو…")
            val tracks = withContext(Dispatchers.IO) { probeSubtitleTracks(file) }

            if (tracks.text.isEmpty()) {
                setExtractEnabled(true)
                if (tracks.imageOnly) {
                    setStatus("این ویدیو فقط زیرنویس تصویری (مثل PGS/VobSub) دارد؛ این نوع زیرنویس عکس است نه متن و قابل استخراج به txt نیست.")
                } else {
                    setStatus("هیچ ردیف زیرنویسی در این فایل شناسایی نشد.\n\nخروجی خام ffprobe برای بررسی:\n${tracks.debugOutput.take(600)}")
                }
                return@launch
            }

            if (tracks.text.size == 1) {
                extractTrack(file, tracks.text.first())
            } else {
                val chosen = chooseTrackDialog(tracks.text)
                if (chosen != null) extractTrack(file, chosen) else setExtractEnabled(true)
            }
        }
    }

    private class ProbeResult(val text: List<SubtitleTrack>, val imageOnly: Boolean, val debugOutput: String)

    /**
     * Uses ffprobe's default (non-JSON) output format on purpose: the JSON writer is an
     * optional module that some minimal/free ffmpeg builds strip out, which previously made
     * this silently return an empty list even when a subtitle track existed. The plain
     * "[STREAM] key=value [/STREAM]" default format is always compiled in, so this is safe
     * across builds.
     */
    private fun probeSubtitleTracks(file: File): ProbeResult {
        val command = "-v error -show_entries stream=index,codec_name,codec_type:stream_tags=language \"${file.absolutePath}\""
        val session = FFprobeKit.execute(command)
        val output = session.output ?: ""

        val textTracks = mutableListOf<SubtitleTrack>()
        var foundImageSub = false

        val blocks = output.split("[STREAM]").drop(1)
        for (block in blocks) {
            val body = block.substringBefore("[/STREAM]")
            val index = Regex("""(?m)^index=(\d+)""").find(body)?.groupValues?.get(1)?.toIntOrNull() ?: continue
            val codecType = Regex("""(?m)^codec_type=(\w+)""").find(body)?.groupValues?.get(1)
            if (codecType != "subtitle") continue
            val codec = Regex("""(?m)^codec_name=(\S+)""").find(body)?.groupValues?.get(1) ?: "unknown"
            val lang = Regex("""(?mi)^tag:language=(\S+)""").find(body)?.groupValues?.get(1)

            if (IMAGE_SUBTITLE_CODECS.contains(codec)) {
                foundImageSub = true
            } else {
                textTracks.add(SubtitleTrack(index, codec, lang))
            }
        }
        return ProbeResult(textTracks, foundImageSub && textTracks.isEmpty(), output)
    }

    private suspend fun chooseTrackDialog(tracks: List<SubtitleTrack>): SubtitleTrack? =
        kotlinx.coroutines.suspendCancellableCoroutine { cont ->
            val labels = tracks.map { "ردیف ${it.index} — ${it.language ?: "زبان نامشخص"} (${it.codec})" }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle("چند زیرنویس پیدا شد — یکی را انتخاب کن")
                .setItems(labels) { _, which -> cont.resume(tracks[which]) { } }
                .setOnCancelListener { cont.resume(null) { } }
                .show()
        }

    // ---------------- Step 3: extract + clean the chosen track ----------------

    private fun extractTrack(file: File, track: SubtitleTrack) {
        CoroutineScope(Dispatchers.Main).launch {
            setStatus("در حال استخراج متن (ردیف ${track.index}, کدک ${track.codec})…")
            val result = withContext(Dispatchers.IO) { runExtraction(file, track) }
            setExtractEnabled(true)

            if (result == null) {
                setStatus("استخراج ناموفق بود. ممکن است این فایل خراب باشد یا این فرمت زیرنویس خاص پشتیبانی نشود.")
                return@launch
            }
            if (result.isBlank()) {
                setStatus("زیرنویس پیدا شد ولی بعد از پاک‌سازی تگ‌ها متنی داخلش باقی نماند.")
                return@launch
            }

            pendingText = result
            setStatus("✅ استخراج موفق بود (${result.length} کاراکتر). حالا محل ذخیره فایل txt را انتخاب کن.")
            val suggestedName = originalDisplayName.substringBeforeLast('.') + ".txt"
            createDocLauncher.launch(suggestedName)
        }
    }

    /**
     * Two-stage strategy:
     *  1) Try a lossless stream copy into a format-matching container (.ass/.vtt/.srt).
     *     This needs no subtitle encoder at all, just demux+mux passthrough, so it works
     *     even on very minimal ffmpeg builds.
     *  2) If that fails for any reason, fall back to transcoding into .srt.
     */
    private fun runExtraction(file: File, track: SubtitleTrack): String? {
        val tag = System.currentTimeMillis()
        val rawExt = when (track.codec.lowercase()) {
            "ass", "ssa" -> "ass"
            "webvtt" -> "vtt"
            else -> "srt"
        }

        var resultFile: File? = null
        val copyFile = File(cacheDir, "sub_${tag}_copy.$rawExt")
        val copySession = FFmpegKit.execute(
            "-y -i \"${file.absolutePath}\" -map 0:${track.index} -c:s copy \"${copyFile.absolutePath}\""
        )
        if (ReturnCode.isSuccess(copySession.returnCode) && copyFile.exists() && copyFile.length() > 0) {
            resultFile = copyFile
        } else {
            copyFile.delete()
        }

        if (resultFile == null) {
            val srtFile = File(cacheDir, "sub_${tag}_fallback.srt")
            val srtSession = FFmpegKit.execute(
                "-y -i \"${file.absolutePath}\" -map 0:${track.index} -f srt \"${srtFile.absolutePath}\""
            )
            if (ReturnCode.isSuccess(srtSession.returnCode) && srtFile.exists() && srtFile.length() > 0) {
                resultFile = srtFile
            } else {
                srtFile.delete()
            }
        }

        val finalFile = resultFile ?: return null
        val ext = finalFile.extension.lowercase()
        val raw = finalFile.readText(Charsets.UTF_8)
        finalFile.delete()

        return if (ext == "ass" || ext == "ssa") assToPlainText(raw) else srtOrVttToPlainText(raw)
    }

    /** Strips SRT/VTT index numbers, timestamps, headers and basic style tags. */
    private fun srtOrVttToPlainText(input: String): String {
        val lines = input.replace("\r\n", "\n").split("\n")
        val out = StringBuilder()
        val timeRegex = Regex("""(\d{2}:)?\d{2}:\d{2}[,.]\d{3}\s*-->\s*(\d{2}:)?\d{2}:\d{2}[,.]\d{3}""")
        val indexRegex = Regex("""^\d+$""")
        val tagRegex = Regex("""\{[^}]*}|<[^>]*>""")

        for (rawLine in lines) {
            val line = rawLine.trim()
            if (line.isEmpty()) continue
            if (line.equals("WEBVTT", ignoreCase = true)) continue
            if (line.startsWith("NOTE") || line.startsWith("STYLE") ||
                line.startsWith("Kind:") || line.startsWith("Language:")
            ) continue
            if (indexRegex.matches(line)) continue
            if (timeRegex.containsMatchIn(line)) continue
            val cleaned = tagRegex.replace(line, "").trim()
            if (cleaned.isNotEmpty()) out.append(cleaned).append('\n')
        }
        return out.toString().trim()
    }

    /** Pulls just the dialogue text out of ASS/SSA "Dialogue:" lines, stripping override tags. */
    private fun assToPlainText(input: String): String {
        val lines = input.replace("\r\n", "\n").split("\n")
        val out = StringBuilder()
        // Dialogue: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text  (9 commas before Text)
        val dialogueRegex = Regex("""^Dialogue:\s*(?:[^,]*,){8}(.*)$""")
        val tagRegex = Regex("""\{[^}]*}""")

        for (rawLine in lines) {
            val match = dialogueRegex.find(rawLine.trim()) ?: continue
            var text = match.groupValues[1]
            text = tagRegex.replace(text, "")
            text = text.replace("\\N", "\n").replace("\\n", "\n").trim()
            if (text.isNotEmpty()) out.append(text).append('\n')
        }
        return out.toString().trim()
    }

    // ---------------- Step 4: save & share ----------------

    private fun writeTextToUri(uri: Uri) {
        try {
            contentResolver.openOutputStream(uri)?.use { out ->
                out.write(pendingText.toByteArray(Charsets.UTF_8))
            }
            lastSavedUri = uri
            btnShare.visibility = android.view.View.VISIBLE
            setStatus("فایل txt ذخیره شد ✅")
            Toast.makeText(this, "ذخیره شد", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            setStatus("ذخیره‌سازی فایل با خطا مواجه شد.")
        }
    }

    private fun shareSavedFile() {
        val uri = lastSavedUri ?: return
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "اشتراک‌گذاری فایل زیرنویس"))
    }

    // ---------------- helpers ----------------

    private fun setStatus(text: String) {
        tvStatus.text = text
    }

    private fun setExtractEnabled(enabled: Boolean) {
        btnExtract.isClickable = enabled
        btnExtract.alpha = if (enabled) 1f else 0.4f
    }
}
