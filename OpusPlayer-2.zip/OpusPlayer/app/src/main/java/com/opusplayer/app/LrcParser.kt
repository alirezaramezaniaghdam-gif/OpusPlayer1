package com.opusplayer.app

data class LyricLine(val timeMs: Long, val text: String)

/**
 * Parses the standard .lrc lyrics format:
 *   [00:12.34]Some line of lyrics
 *   [00:45.67][01:10.00]A line that repeats at two timestamps
 * Metadata tags like [ar:Artist] / [ti:Title] / [by:...] are ignored.
 */
object LrcParser {

    private val timeTagRegex = Regex("""\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?]""")

    fun parse(content: String): List<LyricLine> {
        val lines = mutableListOf<LyricLine>()

        for (rawLine in content.lineSequence()) {
            val tags = timeTagRegex.findAll(rawLine).toList()
            if (tags.isEmpty()) continue

            val text = rawLine.substring(tags.last().range.last + 1).trim()
            if (text.isEmpty()) continue

            for (match in tags) {
                val minutes = match.groupValues[1].toLongOrNull() ?: continue
                val seconds = match.groupValues[2].toLongOrNull() ?: continue
                val fracRaw = match.groupValues[3]
                val fractionMs = when (fracRaw.length) {
                    0 -> 0L
                    1 -> fracRaw.toLong() * 100L
                    2 -> fracRaw.toLong() * 10L
                    else -> fracRaw.take(3).toLong()
                }
                val timeMs = minutes * 60_000L + seconds * 1000L + fractionMs
                lines.add(LyricLine(timeMs, text))
            }
        }

        return lines.sortedBy { it.timeMs }
    }
}
