package com.opusplayer.app

import android.content.Context
import android.net.Uri

/**
 * Remembers which .lrc file the person picked for each track (by track id),
 * so it doesn't need to be re-selected every time. We also take a persistable
 * URI permission when it's picked, so we can still read the file after the
 * app (or the phone) restarts.
 */
object LrcRepository {
    private const val PREFS_NAME = "opus_player_lrc"

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getLrcUri(context: Context, trackId: Long): Uri? {
        val stored = prefs(context).getString(trackId.toString(), null) ?: return null
        return try {
            Uri.parse(stored)
        } catch (_: Exception) {
            null
        }
    }

    fun setLrcUri(context: Context, trackId: Long, uri: Uri) {
        try {
            context.contentResolver.takePersistableUriPermission(
                uri,
                android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: Exception) {
            // Some providers don't support persistable permissions; the file will
            // still work for this session even if it can't be re-read after a restart.
        }
        prefs(context).edit().putString(trackId.toString(), uri.toString()).apply()
    }

    fun removeLrcUri(context: Context, trackId: Long) {
        prefs(context).edit().remove(trackId.toString()).apply()
    }
}
