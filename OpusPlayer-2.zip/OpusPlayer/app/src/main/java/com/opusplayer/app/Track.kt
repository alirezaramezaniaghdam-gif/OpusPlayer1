package com.opusplayer.app

import android.net.Uri

data class Track(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val uri: Uri,
    val mimeType: String?,
    val folder: String = "Music",
    // Original file name without extension, e.g. "Song Name" from "Song Name.mp3".
    // Used to look up a matching "Song Name.lrc" lyrics file in the same folder.
    val fileBaseName: String = ""
) {
    val isOpus: Boolean
        get() = mimeType?.contains("opus", ignoreCase = true) == true ||
            title.endsWith(".opus", ignoreCase = true)
}
