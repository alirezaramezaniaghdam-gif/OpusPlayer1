package com.opusplayer.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Build
import android.util.LruCache
import android.util.Size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.util.Collections

/**
 * Loads embedded album art from audio files (works for mp3 ID3 covers,
 * flac/ogg/opus Vorbis-comment covers, m4a, etc.) and caches the decoded
 * bitmaps in memory so we don't re-read every file on every recomposition.
 *
 * Fast scrolling through a long list can otherwise fire off dozens of
 * MediaMetadataRetriever instances at once (each one is a real native
 * resource), which is what was causing lag and the occasional crash. To
 * keep that under control we: (1) cache by memory size rather than a fixed
 * item count, (2) never let more than a few decodes run at the same time,
 * and (3) catch OutOfMemoryError too, not just regular exceptions — a
 * single oversized cover shouldn't be able to take the whole app down.
 *
 * IMPORTANT: android.util.LruCache throws a NullPointerException if you
 * ever call put() with a null value. Most tracks in a real library have NO
 * embedded cover art, so naively caching "null" for those crashed the app
 * on literally the first track without artwork. We now keep a separate
 * "no art" id set for that case instead of ever putting null into the cache.
 *
 * Two separate caches/resolutions are kept: a small one (~160px) for list
 * rows where art is tiny on screen, and a bigger one (~640px) only decoded
 * on demand for the full-screen "now playing" view — using the small,
 * heavily-downsampled thumbnail there was what made the big spinning cover
 * look blurry/pixelated.
 */
object AlbumArtProvider {

    private const val LIST_ART_SIZE = 160
    private const val FULL_ART_SIZE = 640

    // Cache sized by kilobytes of bitmap memory (~100MB budget) rather than item count,
    // so covers of varying resolution don't blow past a fixed slot count. At the small
    // size we decode covers to (~160px), this comfortably holds close to a thousand
    // covers at once — enough for even quite large libraries to stay fully cached
    // without evicting art you already scrolled past. Only ever holds real, non-null bitmaps.
    private val cache = object : LruCache<Long, Bitmap>(100 * 1024) {
        override fun sizeOf(key: Long, value: Bitmap): Int {
            return (value.byteCount / 1024).coerceAtLeast(1)
        }
    }

    // Separate, much smaller cache for the handful of higher-resolution covers
    // shown in the full-screen player (only one is ever visible at a time, so
    // a small budget is plenty and keeps memory use predictable).
    private val highResCache = object : LruCache<Long, Bitmap>(16 * 1024) {
        override fun sizeOf(key: Long, value: Bitmap): Int {
            return (value.byteCount / 1024).coerceAtLeast(1)
        }
    }

    // Tracks we've already checked and confirmed have no embedded artwork,
    // so we don't re-run the expensive decode on them every time they scroll into view.
    private val noArtworkIds: MutableSet<Long> = Collections.synchronizedSet(mutableSetOf())

    // Caps how many files can be read/decoded at once during fast scrolling.
    private const val MAX_CONCURRENT_DECODES = 2
    private val semaphoreSlots = Semaphore(MAX_CONCURRENT_DECODES)

    /**
     * Synchronous, cache-only lookup — no decoding, no coroutine. Used so a
     * row that scrolls back into view can render its already-known art
     * immediately instead of flashing back to the placeholder icon first.
     */
    fun peek(trackId: Long): Bitmap? = cache.get(trackId)

    /** Same idea as [peek] but for the higher-resolution full-player cache. */
    fun peekHighRes(trackId: Long): Bitmap? = highResCache.get(trackId)

    /** Small thumbnail, good for list rows / mini player (~160px). */
    suspend fun getArt(context: Context, track: Track): Bitmap? =
        getArtInternal(context, track, LIST_ART_SIZE, cache)

    /** Larger decode for the full-screen "now playing" cover (~640px). */
    suspend fun getHighResArt(context: Context, track: Track): Bitmap? {
        // If we already know there's no art at all, don't bother re-decoding at a bigger size.
        if (noArtworkIds.contains(track.id)) return null
        return getArtInternal(context, track, FULL_ART_SIZE, highResCache)
    }

    private suspend fun getArtInternal(
        context: Context,
        track: Track,
        targetSize: Int,
        targetCache: LruCache<Long, Bitmap>
    ): Bitmap? {
        targetCache.get(track.id)?.let { return it }
        if (noArtworkIds.contains(track.id)) return null

        return semaphoreSlots.withPermit {
            // Re-check: another coroutine may have finished while we waited for a permit.
            targetCache.get(track.id)?.let { return@withPermit it }
            if (noArtworkIds.contains(track.id)) return@withPermit null

            withContext(Dispatchers.IO) {
                var bitmap: Bitmap? = null
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(context, track.uri)
                    val art = retriever.embeddedPicture
                    if (art != null) {
                        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeByteArray(art, 0, art.size, bounds)
                        val sample = calculateSampleSize(bounds.outWidth, bounds.outHeight, targetSize)
                        val options = BitmapFactory.Options().apply { inSampleSize = sample }
                        bitmap = BitmapFactory.decodeByteArray(art, 0, art.size, options)
                    }
                } catch (_: Throwable) {
                    // No embedded art, corrupt art, or the decode ran out of memory —
                    // any of these should just fall back to the default icon, never crash.
                    bitmap = null
                } finally {
                    try {
                        retriever.release()
                    } catch (_: Throwable) {
                    }
                }

                // Fallback: many files (especially ones downloaded without ID3/Vorbis
                // covers embedded) still have art the *system* knows about — this is
                // how other music players show a cover for files we'd otherwise treat
                // as "no artwork". MediaStore's own thumbnail pipeline handles this.
                if (bitmap == null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    try {
                        bitmap = context.contentResolver.loadThumbnail(
                            track.uri,
                            Size(targetSize, targetSize),
                            null
                        )
                    } catch (_: Throwable) {
                        bitmap = null
                    }
                }

                if (bitmap != null) {
                    targetCache.put(track.id, bitmap)
                } else {
                    noArtworkIds.add(track.id)
                }
                bitmap
            }
        }
    }

    private fun calculateSampleSize(width: Int, height: Int, targetSize: Int): Int {
        var sample = 1
        var w = width
        var h = height
        while (w / 2 >= targetSize && h / 2 >= targetSize) {
            sample *= 2
            w /= 2
            h /= 2
        }
        return sample
    }
}
