package com.opusplayer.app

import android.app.Application
import android.content.ComponentName
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class PlayerUiState(
    val allTracks: List<Track> = emptyList(),
    val playlists: List<Playlist> = emptyList(),
    val activeQueue: List<Track> = emptyList(),
    val activeQueueName: String = "All Songs",
    val currentIndex: Int = -1,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val isLoading: Boolean = true,
    val language: AppLanguage = AppLanguage.FA,
    val languageSelected: Boolean = true,
    val sleepTimerMinutesLeft: Int? = null,
    val equalizerReady: Boolean = false,
    val equalizerEnabled: Boolean = true,
    val bassBoostStrength: Int = 0,
    val shuffleEnabled: Boolean = false,
    val repeatMode: Int = 0, // 0=off, 1=one, 2=all (mirrors androidx.media3.common.Player.REPEAT_MODE_*)
    val darkMode: Boolean = true,
    val favoriteIds: Set<Long> = emptySet(),
    val crossfadeEnabled: Boolean = false,
    val currentLyrics: String? = null,
    val lyricsLoading: Boolean = false,
    val lyricsTrackId: Long? = null,
    val recentTrackIds: List<Long> = emptyList()
)

class PlayerViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(PlayerUiState())
    val uiState: StateFlow<PlayerUiState> = _uiState.asStateFlow()

    private var controller: MediaController? = null
    private var sleepTimerJob: Job? = null

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _uiState.value = _uiState.value.copy(isPlaying = isPlaying)
            if (!isPlaying) saveCurrentPlaybackPosition()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val index = controller?.currentMediaItemIndex ?: -1
            _uiState.value = _uiState.value.copy(currentIndex = index)
            val track = _uiState.value.activeQueue.getOrNull(index)
            if (track != null) {
                val updatedRecent = RecentlyPlayedRepository.recordPlayed(getApplication(), track.id)
                _uiState.value = _uiState.value.copy(recentTrackIds = updatedRecent)
            }
        }

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            _uiState.value = _uiState.value.copy(shuffleEnabled = shuffleModeEnabled)
        }

        override fun onRepeatModeChanged(repeatMode: Int) {
            _uiState.value = _uiState.value.copy(repeatMode = repeatMode)
        }
    }

    init {
        val context = application.applicationContext
        val language = SettingsRepository.loadLanguage(context)
        val languageSelected = SettingsRepository.hasChosenLanguage(context)
        val darkMode = SettingsRepository.loadDarkMode(context)
        val favorites = FavoritesRepository.loadFavorites(context)
        val crossfadeEnabled = SettingsRepository.loadCrossfadeEnabled(context)
        val recentTrackIds = RecentlyPlayedRepository.loadRecent(context)
        _uiState.value = _uiState.value.copy(
            language = language,
            languageSelected = languageSelected,
            darkMode = darkMode,
            favoriteIds = favorites,
            crossfadeEnabled = crossfadeEnabled,
            recentTrackIds = recentTrackIds
        )

        val sessionToken = SessionToken(context, ComponentName(context, PlayerService::class.java))
        val controllerFuture = MediaController.Builder(context, sessionToken).buildAsync()
        controllerFuture.addListener({
            controller = controllerFuture.get()
            controller?.addListener(playerListener)
            _uiState.value = _uiState.value.copy(
                shuffleEnabled = controller?.shuffleModeEnabled ?: false,
                repeatMode = controller?.repeatMode ?: 0
            )
            loadLibrary()
            startPositionPolling()
            startEqualizerPolling()
        }, MoreExecutors.directExecutor())
    }

    fun refreshLibrary() {
        loadLibrary()
    }

    private fun loadLibrary() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)

            val rawTracks = MusicRepository.loadTracks(getApplication())
            val overrides = TrackOverridesRepository.loadOverrides(getApplication())
            val tracks = rawTracks.map { track ->
                val override = overrides[track.id]
                if (override != null) track.copy(title = override.title, artist = override.artist) else track
            }
            val playlists = PlaylistRepository.loadPlaylists(getApplication())

            // Prefetch cover art for the first screenful of tracks before we
            // hide the loading spinner. This means the very first thing the
            // person sees is already fully rendered — no pop-in, no re-decode
            // flicker when they scroll down and back up to these same rows.
            // The rest of the library keeps loading its art lazily as it
            // scrolls into view, same as before.
            val context = getApplication<Application>()
            coroutineScope {
                tracks.take(INITIAL_PREFETCH_COUNT).map { track ->
                    async { AlbumArtProvider.getArt(context, track) }
                }.awaitAll()
            }

            _uiState.value = _uiState.value.copy(
                allTracks = tracks,
                playlists = playlists,
                activeQueue = tracks,
                activeQueueName = "All Songs",
                isLoading = false
            )
            setQueue(tracks, prepare = true)

            // Resume exactly where playback was left off last time, if we can
            // find that same track again — cued up and paused, ready to continue
            // with a single tap, rather than always starting back at track one.
            val lastPlayback = SettingsRepository.loadLastPlayback(context)
            if (lastPlayback != null) {
                val resumeIndex = tracks.indexOfFirst { it.id == lastPlayback.trackId }
                if (resumeIndex >= 0) {
                    controller?.seekTo(resumeIndex, lastPlayback.positionMs)
                    _uiState.value = _uiState.value.copy(currentIndex = resumeIndex, positionMs = lastPlayback.positionMs)
                }
            }

            // Keep warming the cache for the rest of the library in the background,
            // at low priority, so art you haven't scrolled to yet is *already* ready
            // by the time you get there — instead of only ever loading whatever is
            // currently on screen (which is what made it look like art kept
            // "unloading" every time you scrolled back to an earlier point).
            prefetchRemainingArtwork(tracks)
        }
    }

    private fun prefetchRemainingArtwork(tracks: List<Track>) {
        viewModelScope.launch {
            val context = getApplication<Application>()
            for (track in tracks.drop(INITIAL_PREFETCH_COUNT)) {
                AlbumArtProvider.getArt(context, track)
                // Small breather between each one so this background warm-up never
                // competes with whatever's happening on screen right now (like
                // scrolling) — better to finish a bit later than to cause jank.
                delay(40)
            }
        }
    }

    companion object {
        private const val INITIAL_PREFETCH_COUNT = 20
        private const val CROSSFADE_MS = 3000L
    }

    private fun saveCurrentPlaybackPosition() {
        val c = controller ?: return
        val currentTrack = _uiState.value.activeQueue.getOrNull(c.currentMediaItemIndex) ?: return
        SettingsRepository.saveLastPlayback(
            getApplication(),
            currentTrack.id,
            c.currentPosition.coerceAtLeast(0L),
            _uiState.value.activeQueueName
        )
    }

    private fun setQueue(tracks: List<Track>, prepare: Boolean) {
        val mediaItems = tracks.map { track ->
            MediaItem.Builder()
                .setUri(track.uri)
                .setMediaId(track.id.toString())
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(track.title)
                        .setArtist(track.artist)
                        .setAlbumTitle(track.album)
                        .build()
                )
                .build()
        }
        controller?.setMediaItems(mediaItems)
        if (prepare) controller?.prepare()
    }

    private fun startPositionPolling() {
        viewModelScope.launch {
            var ticksSinceSave = 0
            while (true) {
                val c = controller
                if (c != null) {
                    val position = c.currentPosition.coerceAtLeast(0L)
                    val duration = c.duration.coerceAtLeast(0L)
                    _uiState.value = _uiState.value.copy(
                        positionMs = position,
                        durationMs = duration,
                        currentIndex = c.currentMediaItemIndex
                    )

                    if (_uiState.value.crossfadeEnabled && duration > 0) {
                        applyCrossfadeVolume(c, position, duration)
                    } else if (c.volume < 1f) {
                        c.volume = 1f
                    }

                    // Remember where we are every ~5 seconds (not every tick — writing to
                    // disk on every 500ms poll would be wasteful) so a full app restart
                    // can pick up exactly where playback left off.
                    ticksSinceSave++
                    if (ticksSinceSave >= 10 && c.isPlaying) {
                        ticksSinceSave = 0
                        val currentTrack = _uiState.value.activeQueue.getOrNull(c.currentMediaItemIndex)
                        if (currentTrack != null) {
                            SettingsRepository.saveLastPlayback(
                                getApplication(),
                                currentTrack.id,
                                position,
                                _uiState.value.activeQueueName
                            )
                        }
                    }
                }
                delay(500)
            }
        }
    }

    /** Fades volume down near the end of a track and back up right after a transition,
     * giving a smooth "crossfade" feel without needing two overlapping players. */
    private fun applyCrossfadeVolume(controller: MediaController, position: Long, duration: Long) {
        val remaining = duration - position
        controller.volume = when {
            remaining <= CROSSFADE_MS -> (remaining.toFloat() / CROSSFADE_MS).coerceIn(0f, 1f)
            position <= CROSSFADE_MS -> (position.toFloat() / CROSSFADE_MS).coerceIn(0f, 1f)
            else -> 1f
        }
    }

    /** The equalizer only becomes attachable once ExoPlayer has an audio session, so poll briefly until ready. */
    private fun startEqualizerPolling() {
        viewModelScope.launch {
            while (!AudioEffectsManager.isReady) {
                delay(300)
            }
            _uiState.value = _uiState.value.copy(
                equalizerReady = true,
                bassBoostStrength = AudioEffectsManager.getBassBoostStrength().toInt()
            )
        }
    }

    private fun switchQueueAndPlay(queueName: String, tracks: List<Track>, index: Int) {
        val state = _uiState.value
        if (state.activeQueueName != queueName || state.activeQueue != tracks) {
            setQueue(tracks, prepare = false)
            _uiState.value = state.copy(activeQueue = tracks, activeQueueName = queueName)
        }
        controller?.seekTo(index, 0L)
        controller?.play()
    }

    fun playFromAllSongs(index: Int) {
        switchQueueAndPlay("All Songs", _uiState.value.allTracks, index)
    }

    fun playFromPlaylist(playlist: Playlist, index: Int) {
        val tracks = playlist.trackIds.mapNotNull { id -> _uiState.value.allTracks.find { it.id == id } }
        switchQueueAndPlay(playlist.name, tracks, index)
    }

    fun playFromFolder(folderName: String, tracks: List<Track>, index: Int) {
        switchQueueAndPlay(folderName, tracks, index)
    }

    /** Used by search/sort in the All Songs screen — same underlying queue name, possibly reordered/filtered. */
    fun playCustomQueue(queueName: String, tracks: List<Track>, index: Int) {
        switchQueueAndPlay(queueName, tracks, index)
    }

    fun toggleShuffle() {
        controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
    }

    fun cycleRepeatMode() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }

    fun togglePlayPause() {
        controller?.let {
            if (it.isPlaying) it.pause() else it.play()
        }
    }

    fun next() {
        controller?.seekToNextMediaItem()
    }

    fun previous() {
        controller?.seekToPreviousMediaItem()
    }

    fun seekTo(positionMs: Long) {
        controller?.seekTo(positionMs)
        // Update immediately rather than waiting up to 500ms for the next poll tick —
        // otherwise the seek bar visibly snaps back to the old position for a moment
        // right after you let go, before jumping to where you actually dragged to.
        _uiState.value = _uiState.value.copy(positionMs = positionMs)
    }

    // --- Playlist management ---

    fun createPlaylist(name: String) {
        if (name.isBlank()) return
        val updated = PlaylistRepository.createPlaylist(getApplication(), name.trim())
        _uiState.value = _uiState.value.copy(playlists = updated)
    }

    fun deletePlaylist(playlistId: String) {
        val updated = PlaylistRepository.deletePlaylist(getApplication(), playlistId)
        _uiState.value = _uiState.value.copy(playlists = updated)
    }

    fun addTrackToPlaylist(playlistId: String, trackId: Long) {
        val updated = PlaylistRepository.addTrackToPlaylist(getApplication(), playlistId, trackId)
        _uiState.value = _uiState.value.copy(playlists = updated)
    }

    fun removeTrackFromPlaylist(playlistId: String, trackId: Long) {
        val updated = PlaylistRepository.removeTrackFromPlaylist(getApplication(), playlistId, trackId)
        _uiState.value = _uiState.value.copy(playlists = updated)
    }

    fun moveTrackInPlaylist(playlistId: String, trackId: Long, delta: Int) {
        val updated = PlaylistRepository.moveTrackInPlaylist(getApplication(), playlistId, trackId, delta)
        _uiState.value = _uiState.value.copy(playlists = updated)
    }

    // --- Settings: language ---

    fun setLanguage(language: AppLanguage) {
        SettingsRepository.saveLanguage(getApplication(), language)
        _uiState.value = _uiState.value.copy(language = language, languageSelected = true)
    }

    fun setDarkMode(enabled: Boolean) {
        SettingsRepository.saveDarkMode(getApplication(), enabled)
        _uiState.value = _uiState.value.copy(darkMode = enabled)
    }

    fun setCrossfadeEnabled(enabled: Boolean) {
        SettingsRepository.saveCrossfadeEnabled(getApplication(), enabled)
        _uiState.value = _uiState.value.copy(crossfadeEnabled = enabled)
        if (!enabled) controller?.volume = 1f
    }

    // --- Manual title/artist correction (display-only, doesn't touch the file) ---

    fun setTrackOverride(trackId: Long, title: String, artist: String) {
        TrackOverridesRepository.setOverride(getApplication(), trackId, title, artist)
        fun applyOverride(track: Track) =
            if (track.id == trackId) track.copy(title = title.trim().ifBlank { track.title }, artist = artist.trim().ifBlank { track.artist })
            else track

        val state = _uiState.value
        val newAllTracks = state.allTracks.map(::applyOverride)
        val newActiveQueue = state.activeQueue.map(::applyOverride)
        _uiState.value = state.copy(allTracks = newAllTracks, activeQueue = newActiveQueue)
        setQueue(newActiveQueue, prepare = false)
    }

    // --- Lyrics (ID3 USLT embedded lyrics, mp3 only) ---

    fun loadLyricsFor(track: Track) {
        if (_uiState.value.lyricsTrackId == track.id) return // already loaded/loading for this track
        _uiState.value = _uiState.value.copy(lyricsLoading = true, currentLyrics = null, lyricsTrackId = track.id)
        viewModelScope.launch {
            val lyrics = LyricsProvider.getLyrics(getApplication(), track)
            if (_uiState.value.lyricsTrackId == track.id) {
                _uiState.value = _uiState.value.copy(currentLyrics = lyrics, lyricsLoading = false)
            }
        }
    }

    fun clearLyrics() {
        _uiState.value = _uiState.value.copy(currentLyrics = null, lyricsLoading = false, lyricsTrackId = null)
    }

    // --- Favorites ---

    fun toggleFavorite(trackId: Long) {
        val updated = FavoritesRepository.toggleFavorite(getApplication(), trackId)
        _uiState.value = _uiState.value.copy(favoriteIds = updated)
    }

    fun playFromFavorites(favoriteTracks: List<Track>, index: Int) {
        switchQueueAndPlay("Favorites", favoriteTracks, index)
    }

    // --- Recently played ---

    fun playFromRecentlyPlayed(recentTracks: List<Track>, index: Int) {
        switchQueueAndPlay("Recently Played", recentTracks, index)
    }

    // --- Shuffle entire library ---

    fun shufflePlayAllSongs() {
        val tracks = _uiState.value.allTracks
        if (tracks.isEmpty()) return
        val startIndex = tracks.indices.random()
        switchQueueAndPlay("All Songs", tracks, startIndex)
        if (controller?.shuffleModeEnabled != true) {
            controller?.shuffleModeEnabled = true
        }
    }

    fun removeTracksFromPlaylist(playlistId: String, trackIds: Set<Long>) {
        val updated = PlaylistRepository.removeTracksFromPlaylist(getApplication(), playlistId, trackIds)
        _uiState.value = _uiState.value.copy(playlists = updated)
    }

    // --- Sleep timer ---

    fun setSleepTimer(minutes: Int?) {
        sleepTimerJob?.cancel()
        if (minutes == null) {
            _uiState.value = _uiState.value.copy(sleepTimerMinutesLeft = null)
            return
        }
        _uiState.value = _uiState.value.copy(sleepTimerMinutesLeft = minutes)
        sleepTimerJob = viewModelScope.launch {
            var remaining = minutes
            while (remaining > 0) {
                delay(60_000L)
                remaining -= 1
                _uiState.value = _uiState.value.copy(sleepTimerMinutesLeft = remaining)
            }
            controller?.pause()
            _uiState.value = _uiState.value.copy(sleepTimerMinutesLeft = null)
        }
    }

    fun cancelSleepTimer() = setSleepTimer(null)

    // --- Equalizer ---

    fun equalizerBands() = AudioEffectsManager.getBands()

    fun getBandLevel(index: Int) = AudioEffectsManager.getBandLevel(index)

    fun setBandLevel(index: Int, level: Short) {
        AudioEffectsManager.setBandLevel(index, level)
    }

    fun equalizerPresets() = AudioEffectsManager.getPresets()

    fun useEqualizerPreset(index: Int) {
        AudioEffectsManager.usePreset(index)
    }

    fun setBassBoost(strength: Int) {
        AudioEffectsManager.setBassBoostStrength(strength.toShort())
        _uiState.value = _uiState.value.copy(bassBoostStrength = strength)
    }

    override fun onCleared() {
        saveCurrentPlaybackPosition()
        controller?.removeListener(playerListener)
        controller?.release()
        controller = null
        super.onCleared()
    }
}
