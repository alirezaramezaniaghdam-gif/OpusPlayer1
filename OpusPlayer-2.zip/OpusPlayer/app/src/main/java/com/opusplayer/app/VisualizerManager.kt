package com.opusplayer.app

import android.media.audiofx.Visualizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.sqrt

/**
 * Reads real, live frequency data from whatever is actually playing (via
 * Android's audio-session Visualizer effect — the same mechanism system
 * equalizers use) and reduces it down to a small number of "bands" so the
 * UI can draw a reacting bar around the album art. This is NOT a fake
 * animation; it genuinely reflects the bass/treble content of the audio.
 *
 * No microphone or RECORD_AUDIO permission is involved — this only taps
 * the audio session that's already playing inside our own app, the same
 * way the equalizer does.
 */
object VisualizerManager {

    const val BAND_COUNT = 24

    private var visualizer: Visualizer? = null
    private var currentSessionId: Int = -1
    private var captureEnabled = false

    private val _bands = MutableStateFlow(FloatArray(BAND_COUNT))
    val bands: StateFlow<FloatArray> = _bands.asStateFlow()

    fun attach(audioSessionId: Int) {
        if (audioSessionId == currentSessionId && visualizer != null) return
        release()
        if (audioSessionId == 0) return
        try {
            val captureSize = Visualizer.getCaptureSizeRange()[1]
            val rate = Visualizer.getMaxCaptureRate().coerceAtMost(15000)
            visualizer = Visualizer(audioSessionId).apply {
                this.captureSize = captureSize
                setDataCaptureListener(
                    object : Visualizer.OnDataCaptureListener {
                        override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, samplingRate: Int) {}
                        override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                            if (fft != null) updateBands(fft)
                        }
                    },
                    rate,
                    false,
                    true
                )
            }
            currentSessionId = audioSessionId
            visualizer?.enabled = captureEnabled
        } catch (_: Throwable) {
            // Some devices/OEM skins restrict the Visualizer effect for non-system apps.
            // If that happens we just quietly fall back to no visualizer, never crash.
            visualizer = null
        }
    }

    /** Only capture while the full-player screen is actually visible, to save battery. */
    fun setCaptureEnabled(enabled: Boolean) {
        captureEnabled = enabled
        try {
            visualizer?.enabled = enabled
        } catch (_: Throwable) {
        }
        if (!enabled) _bands.value = FloatArray(BAND_COUNT)
    }

    private fun updateBands(fft: ByteArray) {
        // Android's FFT capture format: index 0 = DC component (real),
        // index 1 = Nyquist (real), then alternating (real, imaginary) pairs.
        val n = fft.size / 2
        if (n <= 0) return
        val binsPerBand = (n / BAND_COUNT).coerceAtLeast(1)
        val previous = _bands.value
        val updated = FloatArray(BAND_COUNT)

        for (band in 0 until BAND_COUNT) {
            var sum = 0f
            val start = band * binsPerBand
            val end = (start + binsPerBand).coerceAtMost(n)
            for (i in start until end) {
                val re = fft.getOrElse(i * 2) { 0 }.toInt()
                val im = fft.getOrElse(i * 2 + 1) { 0 }.toInt()
                sum += sqrt((re * re + im * im).toFloat())
            }
            val avg = if (end > start) sum / (end - start) else 0f
            val normalized = (avg / 110f).coerceIn(0f, 1f)
            // Light smoothing so bars glide instead of jittering frame to frame.
            updated[band] = previous[band] * 0.55f + normalized * 0.45f
        }
        _bands.value = updated
    }

    fun release() {
        try {
            visualizer?.enabled = false
            visualizer?.release()
        } catch (_: Throwable) {
        }
        visualizer = null
        currentSessionId = -1
        _bands.value = FloatArray(BAND_COUNT)
    }
}
