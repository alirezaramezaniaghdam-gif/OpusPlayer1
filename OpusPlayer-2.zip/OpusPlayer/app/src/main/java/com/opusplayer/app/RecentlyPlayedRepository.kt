package com.opusplayer.app

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

object RecentlyPlayedRepository {
    private const val PREFS_NAME = "opus_player_recent"
    private const val KEY_RECENT = "recent_ids_json"
    private const val MAX_ENTRIES = 50

    private val gson = Gson()

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /** Most-recently-played first. */
    fun loadRecent(context: Context): List<Long> {
        val json = prefs(context).getString(KEY_RECENT, null) ?: return emptyList()
        val type = object : TypeToken<List<Long>>() {}.type
        return try {
            gson.fromJson(json, type) ?: emptyList()
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun recordPlayed(context: Context, trackId: Long): List<Long> {
        val current = loadRecent(context).toMutableList()
        current.remove(trackId) // move to front if already present
        current.add(0, trackId)
        val trimmed = current.take(MAX_ENTRIES)
        prefs(context).edit().putString(KEY_RECENT, gson.toJson(trimmed)).apply()
        return trimmed
    }
}
