package com.opusplayer.app

import android.content.Context

object SettingsRepository {
    private const val PREFS_NAME = "opus_player_settings"
    private const val KEY_LANGUAGE = "language"
    private const val KEY_DARK_MODE = "dark_mode"

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun loadLanguage(context: Context): AppLanguage {
        val value = prefs(context).getString(KEY_LANGUAGE, AppLanguage.FA.name)
        return try {
            AppLanguage.valueOf(value ?: AppLanguage.FA.name)
        } catch (_: Exception) {
            AppLanguage.FA
        }
    }

    /** True once the person has explicitly picked a language (first-launch prompt). */
    fun hasChosenLanguage(context: Context): Boolean =
        prefs(context).contains(KEY_LANGUAGE)

    fun saveLanguage(context: Context, language: AppLanguage) {
        prefs(context).edit().putString(KEY_LANGUAGE, language.name).apply()
    }

    fun loadDarkMode(context: Context): Boolean =
        prefs(context).getBoolean(KEY_DARK_MODE, true)

    fun saveDarkMode(context: Context, darkMode: Boolean) {
        prefs(context).edit().putBoolean(KEY_DARK_MODE, darkMode).apply()
    }
}
