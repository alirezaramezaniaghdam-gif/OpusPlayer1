package com.opusplayer.app

import android.content.Context

object SettingsRepository {
    private const val PREFS_NAME = "opus_player_settings"
    private const val KEY_LANGUAGE = "language"
    private const val KEY_DARK_MODE = "dark_mode"
    private const val KEY_LAST_TRACK_ID = "last_track_id"
    private const val KEY_LAST_POSITION_MS = "last_position_ms"
    private const val KEY_LAST_QUEUE_NAME = "last_queue_name"
    private const val KEY_CROSSFADE_ENABLED = "crossfade_enabled"

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun loadLanguage(context: Context): AppLanguage {
        val value = prefs(context).getString(KEY_LANGUAGE, AppLanguage.FA.name)
        return try {
            AppLanguage.valueOf(value ?: AppLanguage.FA.name)
        } catch (_: Exception) {
            AppLanguage.FA
        }
    }

    /** True once the person has explicitly picked a language (first-launch prompt). */
    fun hasChosenLanguage(context: Context): Boolean =
        prefs(context).contains(KEY_LANGUAGE)

    fun saveLanguage(context: Context, language: AppLanguage) {
        prefs(context).edit().putString(KEY_LANGUAGE, language.name).apply()
    }

    fun loadDarkMode(context: Context): Boolean =
        prefs(context).getBoolean(KEY_DARK_MODE, true)

    fun saveDarkMode(context: Context, darkMode: Boolean) {
        prefs(context).edit().putBoolean(KEY_DARK_MODE, darkMode).apply()
    }

    /** Remembers exactly where playback was left off so it can resume next launch. */
    fun saveLastPlayback(context: Context, trackId: Long, positionMs: Long, queueName: String) {
        prefs(context).edit()
            .putLong(KEY_LAST_TRACK_ID, trackId)
            .putLong(KEY_LAST_POSITION_MS, positionMs)
            .putString(KEY_LAST_QUEUE_NAME, queueName)
            .apply()
    }

    data class LastPlayback(val trackId: Long, val positionMs: Long, val queueName: String)

    fun loadLastPlayback(context: Context): LastPlayback? {
        val p = prefs(context)
        if (!p.contains(KEY_LAST_TRACK_ID)) return null
        val trackId = p.getLong(KEY_LAST_TRACK_ID, -1L)
        if (trackId < 0) return null
        val position = p.getLong(KEY_LAST_POSITION_MS, 0L)
        val queueName = p.getString(KEY_LAST_QUEUE_NAME, "All Songs") ?: "All Songs"
        return LastPlayback(trackId, position, queueName)
    }

    fun loadCrossfadeEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_CROSSFADE_ENABLED, false)

    fun saveCrossfadeEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_CROSSFADE_ENABLED, enabled).apply()
    }
}
