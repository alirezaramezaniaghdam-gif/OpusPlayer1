package com.opusplayer.app

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.InputStream

/**
 * Reads embedded lyrics from the "USLT" (Unsynchronised Lyrics/Text
 * Transcription) frame that ID3v2 tags support. This only works for MP3
 * files — FLAC/OGG/OPUS use a completely different tagging system
 * (Vorbis comments) which very rarely include lyrics at all, and WAV/M4A
 * have their own separate schemes we don't attempt to parse here. If no
 * lyrics are found (wrong format, no USLT frame, or anything unexpected
 * about the file), this always just returns null — never throws.
 */
object LyricsProvider {

    suspend fun getLyrics(context: Context, track: Track): String? = withContext(Dispatchers.IO) {
        val looksLikeMp3 = track.mimeType?.contains("mpeg", ignoreCase = true) == true ||
            track.mimeType?.contains("mp3", ignoreCase = true) == true ||
            track.title.endsWith(".mp3", ignoreCase = true)
        if (!looksLikeMp3) return@withContext null

        try {
            context.contentResolver.openInputStream(track.uri)?.use { raw ->
                val input = BufferedInputStream(raw)
                parseId3UsltLyrics(input)
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun parseId3UsltLyrics(input: InputStream): String? {
        val header = ByteArray(10)
        if (input.read(header) != 10) return null
        if (header[0] != 'I'.code.toByte() || header[1] != 'D'.code.toByte() || header[2] != '3'.code.toByte()) {
            return null
        }
        val majorVersion = header[3].toInt()
        val tagSize = syncSafeInt(header[6], header[7], header[8], header[9])

        var remaining = tagSize
        val frameHeaderSize = 10

        while (remaining > frameHeaderSize) {
            val frameHeader = ByteArray(frameHeaderSize)
            val readCount = input.read(frameHeader)
            if (readCount < frameHeaderSize) break
            remaining -= frameHeaderSize

            val frameId = String(frameHeader, 0, 4, Charsets.ISO_8859_1)
            if (frameId.isBlank() || frameId[0] == '\u0000') break // padding reached

            val frameSize = if (majorVersion >= 4) {
                syncSafeInt(frameHeader[4], frameHeader[5], frameHeader[6], frameHeader[7])
            } else {
                bigEndianInt(frameHeader[4], frameHeader[5], frameHeader[6], frameHeader[7])
            }
            if (frameSize <= 0 || frameSize > remaining) break

            if (frameId == "USLT") {
                val frameData = ByteArray(frameSize)
                if (input.read(frameData) != frameSize) return null
                return decodeUslt(frameData)
            } else {
                skipFully(input, frameSize.toLong())
            }
            remaining -= frameSize
        }
        return null
    }

    private fun decodeUslt(data: ByteArray): String? {
        if (data.isEmpty()) return null
        val encodingByte = data[0].toInt()
        // Bytes 1..3 are a 3-letter language code we don't need.
        var index = 4
        if (index >= data.size) return null

        val charset = when (encodingByte) {
            0 -> Charsets.ISO_8859_1
            1 -> Charsets.UTF_16
            2 -> Charsets.UTF_16BE
            3 -> Charsets.UTF_8
            else -> Charsets.ISO_8859_1
        }

        // Skip the null-terminated "content descriptor" before the actual lyrics text.
        val isDoubleByteCharset = encodingByte == 1 || encodingByte == 2
        val descriptorEnd = findNullTerminator(data, index, isDoubleByteCharset)
        index = descriptorEnd

        if (index >= data.size) return null
        val lyricsBytes = data.copyOfRange(index, data.size)
        val text = String(lyricsBytes, charset).trim('\u0000', ' ', '\n', '\r')
        return text.ifBlank { null }
    }

    private fun findNullTerminator(data: ByteArray, start: Int, doubleByte: Boolean): Int {
        var i = start
        if (doubleByte) {
            while (i + 1 < data.size) {
                if (data[i] == 0.toByte() && data[i + 1] == 0.toByte()) return i + 2
                i += 2
            }
            return data.size
        } else {
            while (i < data.size) {
                if (data[i] == 0.toByte()) return i + 1
                i++
            }
            return data.size
        }
    }

    private fun skipFully(input: InputStream, byteCount: Long) {
        var remaining = byteCount
        val buffer = ByteArray(4096)
        while (remaining > 0) {
            val toRead = minOf(remaining, buffer.size.toLong()).toInt()
            val read = input.read(buffer, 0, toRead)
            if (read <= 0) break
            remaining -= read
        }
    }

    private fun syncSafeInt(b0: Byte, b1: Byte, b2: Byte, b3: Byte): Int {
        return ((b0.toInt() and 0x7F) shl 21) or
            ((b1.toInt() and 0x7F) shl 14) or
            ((b2.toInt() and 0x7F) shl 7) or
            (b3.toInt() and 0x7F)
    }

    private fun bigEndianInt(b0: Byte, b1: Byte, b2: Byte, b3: Byte): Int {
        return ((b0.toInt() and 0xFF) shl 24) or
            ((b1.toInt() and 0xFF) shl 16) or
            ((b2.toInt() and 0xFF) shl 8) or
            (b3.toInt() and 0xFF)
    }
}
