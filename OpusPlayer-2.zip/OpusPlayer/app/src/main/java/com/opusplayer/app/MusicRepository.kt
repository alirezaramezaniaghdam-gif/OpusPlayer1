package com.opusplayer.app

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object MusicRepository {

    /**
     * Scans MediaStore for all audio files, including .opus files which are
     * sometimes not flagged as IS_MUSIC by the system. We query broadly and
     * then rely on Media3's ExoPlayer (which bundles an Ogg/WebM extractor)
     * to actually decode Opus at playback time.
     *
     * Every row is parsed defensively: a single malformed or unusual file
     * (missing column, weird metadata, whatever) is skipped rather than
     * allowed to throw and take the whole library scan down with it. This
     * matters a lot on libraries with hundreds/thousands of tracks, where
     * the odds of at least one "weird" file are much higher.
     */
    suspend fun loadTracks(context: Context): List<Track> = withContext(Dispatchers.IO) {
        val tracks = mutableListOf<Track>()

        try {
            val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

            val projection = arrayOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.MIME_TYPE,
                MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.RELATIVE_PATH
            )

            // No IS_MUSIC filter: some .opus files get tagged as podcasts/notifications
            // by the media scanner. We instead filter by mime-type/extension below.
            val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"

            context.contentResolver.query(collection, projection, null, null, sortOrder)?.use { cursor ->
                val idCol = cursor.getColumnIndex(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST)
                val albumCol = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM)
                val durationCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION)
                val mimeCol = cursor.getColumnIndex(MediaStore.Audio.Media.MIME_TYPE)
                val nameCol = cursor.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME)
                val pathCol = cursor.getColumnIndex(MediaStore.Audio.Media.RELATIVE_PATH)

                // If the essential columns aren't there at all, there's nothing safe to read.
                if (idCol < 0 || nameCol < 0) return@use

                while (cursor.moveToNext()) {
                    try {
                        val id = cursor.getLong(idCol)
                        val displayName = (if (nameCol >= 0) cursor.getString(nameCol) else null) ?: ""
                        val mime = if (mimeCol >= 0) cursor.getString(mimeCol) else null

                        val isAudioLike = mime?.startsWith("audio/") == true ||
                            displayName.endsWith(".opus", true) ||
                            displayName.endsWith(".ogg", true) ||
                            displayName.endsWith(".mp3", true) ||
                            displayName.endsWith(".m4a", true) ||
                            displayName.endsWith(".flac", true) ||
                            displayName.endsWith(".wav", true)

                        if (!isAudioLike) continue

                        val title = (if (titleCol >= 0) cursor.getString(titleCol) else null) ?: displayName
                        val artist = (if (artistCol >= 0) cursor.getString(artistCol) else null) ?: "Unknown Artist"
                        val album = (if (albumCol >= 0) cursor.getString(albumCol) else null) ?: "Unknown Album"
                        val duration = if (durationCol >= 0) cursor.getLong(durationCol) else 0L
                        val uri = ContentUris.withAppendedId(collection, id)
                        val relativePath = (if (pathCol >= 0) cursor.getString(pathCol) else null)?.trim('/')
                        val folder = relativePath?.ifBlank { "Music" } ?: "Music"
                        val fileBaseName = displayName.substringBeforeLast('.', displayName)

                        tracks.add(Track(id, title, artist, album, duration, uri, mime, folder, fileBaseName))
                    } catch (_: Throwable) {
                        // Skip this one row; one odd file should never take down the whole scan.
                        continue
                    }
                }
            }
        } catch (_: Throwable) {
            // If the query itself fails for any reason, return whatever we managed to collect
            // (possibly nothing) instead of crashing the app on startup.
        }

        tracks
    }
}
