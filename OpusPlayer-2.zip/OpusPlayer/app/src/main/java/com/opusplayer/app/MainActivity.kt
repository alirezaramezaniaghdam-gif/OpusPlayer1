package com.opusplayer.app

import android.Manifest
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.opusplayer.app.ui.theme.OpusPlayerTheme
import com.opusplayer.app.ui.theme.PurpleAccent
import kotlinx.coroutines.delay
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {

    private val viewModel: PlayerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        startService(Intent(this, PlayerService::class.java))

        setContent {
            val state by viewModel.uiState.collectAsState()
            OpusPlayerTheme(darkTheme = state.darkMode) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    if (!state.languageSelected) {
                        LanguageSelectionScreen(onSelect = { viewModel.setLanguage(it) })
                    } else {
                        RequestAudioPermission(onGranted = { viewModel.refreshLibrary() })
                        val strings = if (state.language == AppLanguage.FA) FaStrings else EnStrings
                        val direction = if (state.language == AppLanguage.FA) LayoutDirection.Rtl else LayoutDirection.Ltr

                        CompositionLocalProvider(
                            LocalAppStrings provides strings,
                            LocalAppLanguage provides state.language,
                            LocalLayoutDirection provides direction
                        ) {
                            RootScreen(viewModel)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LanguageSelectionScreen(onSelect: (AppLanguage) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Filled.GraphicEq,
            contentDescription = null,
            tint = PurpleAccent,
            modifier = Modifier.size(56.dp)
        )
        Spacer(modifier = Modifier.height(24.dp))
        Text("زبان برنامه را انتخاب کنید", style = MaterialTheme.typography.titleLarge)
        Text(
            "Choose your app language",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(modifier = Modifier.height(40.dp))

        Button(
            onClick = { onSelect(AppLanguage.FA) },
            colors = ButtonDefaults.buttonColors(containerColor = PurpleAccent),
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) {
            Text("فارسی", style = MaterialTheme.typography.titleMedium)
        }

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedButton(
            onClick = { onSelect(AppLanguage.EN) },
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) {
            Text("English", style = MaterialTheme.typography.titleMedium)
        }
    }
}

@Composable
fun RequestAudioPermission(onGranted: () -> Unit) {
    val permission = if (Build.VERSION.SDK_INT >= 33) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) onGranted()
    }

    LaunchedEffect(Unit) {
        launcher.launch(permission)
    }
}

private sealed class Screen {
    data object AllSongs : Screen()
    data object Folders : Screen()
    data object Playlists : Screen()
    data object Settings : Screen()
    data object FavoritesDetail : Screen()
    data object RecentlyPlayedDetail : Screen()
    data class FolderDetail(val folderName: String) : Screen()
    data class PlaylistDetail(val playlistId: String) : Screen()
}

@Composable
fun RootScreen(viewModel: PlayerViewModel) {
    val state by viewModel.uiState.collectAsState()
    val strings = LocalAppStrings.current
    var screen by remember { mutableStateOf<Screen>(Screen.AllSongs) }
    var addToPlaylistTrack by remember { mutableStateOf<Track?>(null) }
    var showCreatePlaylistDialog by remember { mutableStateOf(false) }
    var showFullPlayer by remember { mutableStateOf(false) }
    var showLyrics by remember { mutableStateOf(false) }
    var editingTrack by remember { mutableStateOf<Track?>(null) }

    // Make the system back button/gesture navigate *inside* the app first
    // (close the full player, step back out of a folder/playlist, return to
    // the Songs tab) instead of immediately exiting the whole app. It only
    // falls through to actually closing the app once we're already at the
    // top-level Songs tab with nothing open on top of it.
    BackHandler(enabled = showFullPlayer || screen !is Screen.AllSongs) {
        when {
            showFullPlayer -> showFullPlayer = false
            screen is Screen.FolderDetail -> screen = Screen.Folders
            screen is Screen.PlaylistDetail -> screen = Screen.Playlists
            screen is Screen.FavoritesDetail -> screen = Screen.Playlists
            screen is Screen.RecentlyPlayedDetail -> screen = Screen.Playlists
            else -> screen = Screen.AllSongs
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
    Column(modifier = Modifier.fillMaxSize()) {
        TopBar(title = strings.appName)

        Box(modifier = Modifier.weight(1f)) {
            AnimatedContent(
                targetState = screen,
                transitionSpec = {
                    (fadeIn(tween(220, easing = FastOutSlowInEasing)) +
                        slideInHorizontally(tween(260, easing = FastOutSlowInEasing)) { width -> width / 8 }) togetherWith
                        (fadeOut(tween(150)) +
                            slideOutHorizontally(tween(200)) { width -> -width / 8 })
                },
                label = "screenTransition"
            ) { targetScreen ->
                when (targetScreen) {
                is Screen.AllSongs -> {
                    when {
                        state.isLoading -> LoadingView()
                        state.allTracks.isEmpty() -> EmptyView(strings.emptyLibrary)
                        else -> AllSongsScreen(
                            tracks = state.allTracks,
                            currentIndex = state.currentIndex,
                            activeQueueName = state.activeQueueName,
                            strings = strings,
                            favoriteIds = state.favoriteIds,
                            isPlaying = state.isPlaying,
                            onTrackClick = { queue, index -> viewModel.playCustomQueue("All Songs", queue, index) },
                            onTrackLongClick = { track -> addToPlaylistTrack = track },
                            onToggleFavorite = { viewModel.toggleFavorite(it) },
                            onShufflePlayAll = { viewModel.shufflePlayAllSongs() }
                        )
                    }
                }
                is Screen.Folders -> FoldersScreen(
                    tracks = state.allTracks,
                    onOpenFolder = { folderName -> screen = Screen.FolderDetail(folderName) }
                )
                is Screen.FolderDetail -> {
                    val tracksInFolder = state.allTracks.filter { it.folder == targetScreen.folderName }
                    FolderDetailScreen(
                        folderName = targetScreen.folderName,
                        tracks = tracksInFolder,
                        currentIndex = if (state.activeQueueName == targetScreen.folderName) state.currentIndex else -1,
                        isPlaying = state.isPlaying,
                        onBack = { screen = Screen.Folders },
                        onTrackClick = { index -> viewModel.playFromFolder(targetScreen.folderName, tracksInFolder, index) },
                        onTrackLongClick = { track -> addToPlaylistTrack = track },
                        favoriteIds = state.favoriteIds,
                        onToggleFavorite = { viewModel.toggleFavorite(it) }
                    )
                }
                is Screen.Playlists -> PlaylistsScreen(
                    playlists = state.playlists,
                    favoritesCount = state.favoriteIds.size,
                    recentlyPlayedCount = state.recentTrackIds.size,
                    onCreateClick = { showCreatePlaylistDialog = true },
                    onOpenPlaylist = { playlist -> screen = Screen.PlaylistDetail(playlist.id) },
                    onOpenFavorites = { screen = Screen.FavoritesDetail },
                    onOpenRecentlyPlayed = { screen = Screen.RecentlyPlayedDetail },
                    onDeletePlaylist = { viewModel.deletePlaylist(it) }
                )
                is Screen.FavoritesDetail -> {
                    val favoriteTracks = state.allTracks.filter { state.favoriteIds.contains(it.id) }
                    FavoritesDetailScreen(
                        tracks = favoriteTracks,
                        currentIndex = if (state.activeQueueName == "Favorites") state.currentIndex else -1,
                        strings = strings,
                        isPlaying = state.isPlaying,
                        onBack = { screen = Screen.Playlists },
                        onTrackClick = { index -> viewModel.playFromFavorites(favoriteTracks, index) },
                        onToggleFavorite = { viewModel.toggleFavorite(it) }
                    )
                }
                is Screen.RecentlyPlayedDetail -> {
                    val tracksById = state.allTracks.associateBy { it.id }
                    val recentTracks = state.recentTrackIds.mapNotNull { tracksById[it] }
                    RecentlyPlayedDetailScreen(
                        tracks = recentTracks,
                        currentIndex = if (state.activeQueueName == "Recently Played") state.currentIndex else -1,
                        strings = strings,
                        favoriteIds = state.favoriteIds,
                        isPlaying = state.isPlaying,
                        onBack = { screen = Screen.Playlists },
                        onTrackClick = { index -> viewModel.playFromRecentlyPlayed(recentTracks, index) },
                        onToggleFavorite = { viewModel.toggleFavorite(it) }
                    )
                }
                is Screen.PlaylistDetail -> {
                    val playlist = state.playlists.find { it.id == targetScreen.playlistId }
                    if (playlist == null) {
                        screen = Screen.Playlists
                    } else {
                        val playlistTracks = playlist.trackIds.mapNotNull { id -> state.allTracks.find { it.id == id } }
                        PlaylistDetailScreen(
                            playlist = playlist,
                            tracks = playlistTracks,
                            currentIndex = if (state.activeQueueName == playlist.name) state.currentIndex else -1,
                            isPlaying = state.isPlaying,
                            onBack = { screen = Screen.Playlists },
                            onTrackClick = { index -> viewModel.playFromPlaylist(playlist, index) },
                            onRemoveTrack = { trackId -> viewModel.removeTrackFromPlaylist(playlist.id, trackId) },
                            onRemoveTracks = { trackIds -> viewModel.removeTracksFromPlaylist(playlist.id, trackIds) },
                            onMoveTrack = { trackId, delta -> viewModel.moveTrackInPlaylist(playlist.id, trackId, delta) }
                        )
                    }
                }
                is Screen.Settings -> SettingsScreen(viewModel = viewModel, state = state)
                }
            }
        }

        AnimatedVisibility(
            visible = state.currentIndex in state.activeQueue.indices,
            enter = slideInVertically(tween(240, easing = FastOutSlowInEasing)) { height -> height } + fadeIn(tween(200)),
            exit = fadeOut(tween(120))
        ) {
            if (state.currentIndex in state.activeQueue.indices) {
                NowPlayingBar(
                    track = state.activeQueue[state.currentIndex],
                    isPlaying = state.isPlaying,
                    positionMs = state.positionMs,
                    durationMs = state.durationMs,
                    shuffleEnabled = state.shuffleEnabled,
                    repeatMode = state.repeatMode,
                    onPlayPause = { viewModel.togglePlayPause() },
                    onNext = { viewModel.next() },
                    onPrevious = { viewModel.previous() },
                    onSeek = { viewModel.seekTo(it) },
                    onToggleShuffle = { viewModel.toggleShuffle() },
                    onCycleRepeat = { viewModel.cycleRepeatMode() },
                    onOpenFullPlayer = { showFullPlayer = true }
                )
            }
        }

        BottomNavBar(
            currentScreen = screen,
            strings = strings,
            onSelectAllSongs = { screen = Screen.AllSongs },
            onSelectFolders = { screen = Screen.Folders },
            onSelectPlaylists = { screen = Screen.Playlists },
            onSelectSettings = { screen = Screen.Settings }
        )
    }

    addToPlaylistTrack?.let { track ->
        AddToPlaylistDialog(
            track = track,
            playlists = state.playlists,
            strings = strings,
            onDismiss = { addToPlaylistTrack = null },
            onToggle = { playlistId, alreadyIn ->
                if (alreadyIn) viewModel.removeTrackFromPlaylist(playlistId, track.id)
                else viewModel.addTrackToPlaylist(playlistId, track.id)
            },
            onCreateNew = { showCreatePlaylistDialog = true }
        )
    }

    if (showCreatePlaylistDialog) {
        CreatePlaylistDialog(
            strings = strings,
            onDismiss = { showCreatePlaylistDialog = false },
            onCreate = { name ->
                viewModel.createPlaylist(name)
                showCreatePlaylistDialog = false
            }
        )
    }

    editingTrack?.let { track ->
        EditTrackDialog(
            track = track,
            onDismiss = { editingTrack = null },
            onSave = { title, artist ->
                viewModel.setTrackOverride(track.id, title, artist)
                editingTrack = null
            }
        )
    }

    if (state.currentIndex in state.activeQueue.indices) {
        val currentTrack = state.activeQueue[state.currentIndex]
        AnimatedVisibility(
            visible = showFullPlayer,
            enter = slideInVertically(tween(280, easing = FastOutSlowInEasing)) { height -> height } + fadeIn(tween(220)),
            exit = slideOutVertically(tween(220)) { height -> height } + fadeOut(tween(150))
        ) {
        FullPlayerScreen(
            track = currentTrack,
            isPlaying = state.isPlaying,
            positionMs = state.positionMs,
            durationMs = state.durationMs,
            isFavorite = state.favoriteIds.contains(currentTrack.id),
            shuffleEnabled = state.shuffleEnabled,
            repeatMode = state.repeatMode,
            showLyrics = showLyrics,
            lyricsText = if (state.lyricsTrackId == currentTrack.id) state.currentLyrics else null,
            lyricsLoading = state.lyricsTrackId == currentTrack.id && state.lyricsLoading,
            onClose = { showFullPlayer = false },
            onPlayPause = { viewModel.togglePlayPause() },
            onNext = { viewModel.next() },
            onPrevious = { viewModel.previous() },
            onSeek = { viewModel.seekTo(it) },
            onToggleShuffle = { viewModel.toggleShuffle() },
            onCycleRepeat = { viewModel.cycleRepeatMode() },
            onToggleFavorite = { viewModel.toggleFavorite(currentTrack.id) },
            onOpenEqualizer = {
                showFullPlayer = false
                screen = Screen.Settings
            },
            onEditTrack = { editingTrack = currentTrack },
            onToggleLyrics = {
                showLyrics = !showLyrics
                if (showLyrics) viewModel.loadLyricsFor(currentTrack) else viewModel.clearLyrics()
            }
        )
        }
    }
    }
}

@Composable
private fun BottomNavBar(
    currentScreen: Screen,
    strings: AppStrings,
    onSelectAllSongs: () -> Unit,
    onSelectFolders: () -> Unit,
    onSelectPlaylists: () -> Unit,
    onSelectSettings: () -> Unit
) {
    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
        val isSongs = currentScreen is Screen.AllSongs
        val isFolders = currentScreen is Screen.Folders || currentScreen is Screen.FolderDetail
        val isPlaylists = currentScreen is Screen.Playlists || currentScreen is Screen.PlaylistDetail ||
            currentScreen is Screen.FavoritesDetail || currentScreen is Screen.RecentlyPlayedDetail
        val isSettings = currentScreen is Screen.Settings

        NavigationBarItem(
            selected = isSongs,
            onClick = onSelectAllSongs,
            icon = { AnimatedNavIcon(Icons.Filled.LibraryMusic, isSongs) },
            label = { Text(strings.navSongs) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = PurpleAccent, indicatorColor = PurpleAccent.copy(alpha = 0.2f))
        )
        NavigationBarItem(
            selected = isFolders,
            onClick = onSelectFolders,
            icon = { AnimatedNavIcon(Icons.Filled.Folder, isFolders) },
            label = { Text(strings.navFolders) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = PurpleAccent, indicatorColor = PurpleAccent.copy(alpha = 0.2f))
        )
        NavigationBarItem(
            selected = isPlaylists,
            onClick = onSelectPlaylists,
            icon = { AnimatedNavIcon(Icons.Filled.QueueMusic, isPlaylists) },
            label = { Text(strings.navPlaylists) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = PurpleAccent, indicatorColor = PurpleAccent.copy(alpha = 0.2f))
        )
        NavigationBarItem(
            selected = isSettings,
            onClick = onSelectSettings,
            icon = { AnimatedNavIcon(Icons.Filled.Settings, isSettings) },
            label = { Text(strings.navSettings) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = PurpleAccent, indicatorColor = PurpleAccent.copy(alpha = 0.2f))
        )
    }
}

@Composable
private fun AnimatedNavIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean) {
    val scale by animateFloatAsState(
        targetValue = if (selected) 1.18f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "navIconScale"
    )
    Icon(icon, contentDescription = null, modifier = Modifier.scale(scale))
}

@Composable
fun TopBar(title: String) {
    val infiniteTransition = rememberInfiniteTransition(label = "logoGlow")
    val hueShift by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(3000, easing = LinearEasing), repeatMode = RepeatMode.Reverse),
        label = "logoHue"
    )
    val logoColor = androidx.compose.ui.graphics.lerp(PurpleAccent, Color(0xFFFF4FD8), hueShift)
    val logoScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(animation = tween(1200, easing = FastOutSlowInEasing), repeatMode = RepeatMode.Reverse),
        label = "logoScale"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            Icons.Filled.GraphicEq,
            contentDescription = null,
            tint = logoColor,
            modifier = Modifier.scale(logoScale)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(title, style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
fun LoadingView() {
    val strings = LocalAppStrings.current
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            EqualizerLoadingBars()
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                strings.loadingLibrary,
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )
        }
    }
}

@Composable
fun EqualizerLoadingBars() {
    val infiniteTransition = rememberInfiniteTransition(label = "eq")
    // Each bar animates on its own offset timing so they don't move in lockstep,
    // which is what makes a real equalizer look alive instead of mechanical.
    val heights = listOf(0, 150, 300, 450, 600).map { delayMs ->
        infiniteTransition.animateFloat(
            initialValue = 0.25f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 500, delayMillis = delayMs, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "bar$delayMs"
        )
    }

    Row(
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.height(48.dp)
    ) {
        heights.forEach { animatedHeight ->
            Box(
                modifier = Modifier
                    .width(6.dp)
                    .fillMaxHeight(animatedHeight.value)
                    .background(PurpleAccent, shape = RoundedCornerShape(3.dp))
            )
        }
    }
}

@Composable
fun EmptyView(message: String) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(
            message,
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(32.dp)
        )
    }
}

private enum class SortMode { TITLE, ARTIST, DURATION }

@Composable
fun AllSongsScreen(
    tracks: List<Track>,
    currentIndex: Int,
    activeQueueName: String,
    strings: AppStrings,
    favoriteIds: Set<Long>,
    isPlaying: Boolean,
    onTrackClick: (List<Track>, Int) -> Unit,
    onTrackLongClick: (Track) -> Unit,
    onToggleFavorite: (Long) -> Unit,
    onShufflePlayAll: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var sortMode by remember { mutableStateOf(SortMode.TITLE) }
    var sortMenuExpanded by remember { mutableStateOf(false) }

    val filteredSorted = remember(tracks, query, sortMode) {
        val filtered = if (query.isBlank()) tracks else tracks.filter {
            it.title.contains(query, ignoreCase = true) || it.artist.contains(query, ignoreCase = true)
        }
        when (sortMode) {
            SortMode.TITLE -> filtered.sortedBy { it.title.lowercase() }
            SortMode.ARTIST -> filtered.sortedBy { it.artist.lowercase() }
            SortMode.DURATION -> filtered.sortedBy { it.durationMs }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text(strings.searchHint, style = MaterialTheme.typography.bodySmall) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = PurpleAccent)
            )
            Spacer(modifier = Modifier.width(8.dp))
            if (tracks.isNotEmpty()) {
                IconButton(onClick = onShufflePlayAll) {
                    Icon(Icons.Filled.Shuffle, contentDescription = strings.shufflePlayAll, tint = PurpleAccent)
                }
            }
            Box {
                IconButton(onClick = { sortMenuExpanded = true }) {
                    Icon(Icons.Filled.Sort, contentDescription = "Sort")
                }
                DropdownMenu(expanded = sortMenuExpanded, onDismissRequest = { sortMenuExpanded = false }) {
                    DropdownMenuItem(text = { Text(strings.sortByTitle) }, onClick = { sortMode = SortMode.TITLE; sortMenuExpanded = false })
                    DropdownMenuItem(text = { Text(strings.sortByArtist) }, onClick = { sortMode = SortMode.ARTIST; sortMenuExpanded = false })
                    DropdownMenuItem(text = { Text(strings.sortByDuration) }, onClick = { sortMode = SortMode.DURATION; sortMenuExpanded = false })
                }
            }
        }

        TrackList(
            tracks = filteredSorted,
            currentIndex = if (activeQueueName == "All Songs") currentIndex else -1,
            isPlaying = isPlaying,
            onTrackClick = { index -> onTrackClick(filteredSorted, index) },
            onTrackLongClick = onTrackLongClick,
            favoriteIds = favoriteIds,
            onToggleFavorite = onToggleFavorite
        )
    }
}

@Composable
fun TrackList(
    tracks: List<Track>,
    currentIndex: Int,
    isPlaying: Boolean = false,
    onTrackClick: (Int) -> Unit,
    onTrackLongClick: (Track) -> Unit,
    favoriteIds: Set<Long> = emptySet(),
    onToggleFavorite: ((Long) -> Unit)? = null
) {
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(count = tracks.size, key = { index -> tracks[index].id }) { index ->
            val track = tracks[index]
            TrackRow(
                track = track,
                isCurrent = index == currentIndex,
                onClick = { onTrackClick(index) },
                onLongClick = { onTrackLongClick(track) },
                isFavorite = favoriteIds.contains(track.id),
                onToggleFavorite = onToggleFavorite?.let { { it(track.id) } },
                isPlaying = isPlaying
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun TrackRow(
    track: Track,
    isCurrent: Boolean,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    isFavorite: Boolean = false,
    onToggleFavorite: (() -> Unit)? = null,
    isPlaying: Boolean = false,
    trailing: (@Composable () -> Unit)? = null
) {
    val context = LocalContext.current
    var artwork by remember(track.id) { mutableStateOf(AlbumArtProvider.peek(track.id)) }

    LaunchedEffect(track.id) {
        if (artwork != null) return@LaunchedEffect
        // If this row scrolls out of view quickly, this coroutine gets cancelled
        // before the delay finishes, so we never even start the expensive decode.
        delay(120)
        artwork = AlbumArtProvider.getArt(context, track)
    }

    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val rowScale by animateFloatAsState(
        targetValue = if (isPressed) 0.97f else 1f,
        animationSpec = tween(100),
        label = "trackRowPress"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .scale(rowScale)
            .combinedClickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick,
                onLongClick = onLongClick
            )
            .background(if (isCurrent) PurpleAccent.copy(alpha = 0.15f) else Color.Transparent)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color.DarkGray),
            contentAlignment = Alignment.Center
        ) {
            val art = artwork
            if (art != null) {
                Image(
                    bitmap = art.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(
                    imageVector = Icons.Filled.MusicNote,
                    contentDescription = null,
                    tint = if (isCurrent) PurpleAccent else Color.Gray,
                    modifier = Modifier.size(24.dp)
                )
            }
            if (isCurrent) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.35f)),
                    contentAlignment = Alignment.Center
                ) {
                    MiniEqualizerBars(animate = isPlaying)
                }
            }
        }
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                track.title,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                track.artist,
                style = MaterialTheme.typography.bodySmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (onToggleFavorite != null) {
            val starScale by animateFloatAsState(
                targetValue = if (isFavorite) 1.15f else 1f,
                animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
                label = "favoriteScale"
            )
            IconButton(onClick = onToggleFavorite, modifier = Modifier.size(36.dp)) {
                Icon(
                    imageVector = if (isFavorite) Icons.Filled.Star else Icons.Filled.StarBorder,
                    contentDescription = "Favorite",
                    tint = if (isFavorite) PurpleAccent else Color.Gray,
                    modifier = Modifier
                        .scale(starScale)
                )
            }
        }
        if (track.isOpus) {
            OpusBadge()
        }
        trailing?.invoke()
    }
}

@Composable
fun MiniEqualizerBars(animate: Boolean) {
    val colors = listOf(Color(0xFFB84FF0), Color(0xFFFF4FD8), Color(0xFF4FA1FF))

    if (!animate) {
        // Paused: show static bars at a fixed "paused" height, no animation running at all.
        Row(
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            modifier = Modifier.height(20.dp)
        ) {
            listOf(0.45f, 0.7f, 0.55f).forEachIndexed { i, h ->
                Box(
                    modifier = Modifier
                        .width(3.dp)
                        .fillMaxHeight(h)
                        .background(colors[i], shape = RoundedCornerShape(2.dp))
                )
            }
        }
        return
    }

    val infiniteTransition = rememberInfiniteTransition(label = "miniEq")
    val heights = listOf(0, 180, 90).mapIndexed { i, delayMs ->
        infiniteTransition.animateFloat(
            initialValue = 0.3f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 420, delayMillis = delayMs, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "miniBar$i"
        )
    }

    Row(
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        modifier = Modifier.height(20.dp)
    ) {
        heights.forEachIndexed { i, animatedHeight ->
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .fillMaxHeight(animatedHeight.value)
                    .background(colors[i], shape = RoundedCornerShape(2.dp))
            )
        }
    }
}

@Composable
fun OpusBadge() {
    Box(
        modifier = Modifier
            .background(PurpleAccent, shape = MaterialTheme.shapes.small)
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text("OPUS", color = Color.White, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
    }
}

// --- Folders ---

@Composable
fun FoldersScreen(tracks: List<Track>, onOpenFolder: (String) -> Unit) {
    val strings = LocalAppStrings.current
    val folderGroups = remember(tracks) {
        tracks.groupBy { it.folder }.toSortedMap()
    }

    if (folderGroups.isEmpty()) {
        EmptyView(strings.emptyLibrary)
        return
    }

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(folderGroups.keys.toList()) { folderName ->
            val count = folderGroups[folderName]?.size ?: 0
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenFolder(folderName) }
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(PurpleAccent.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Folder, contentDescription = null, tint = PurpleAccent)
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(folderName, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("$count ${strings.songsCount}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun FolderDetailScreen(
    folderName: String,
    tracks: List<Track>,
    currentIndex: Int,
    isPlaying: Boolean,
    onBack: () -> Unit,
    onTrackClick: (Int) -> Unit,
    onTrackLongClick: (Track) -> Unit,
    favoriteIds: Set<Long> = emptySet(),
    onToggleFavorite: ((Long) -> Unit)? = null
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(folderName, style = MaterialTheme.typography.titleMedium)
        }
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(count = tracks.size, key = { index -> tracks[index].id }) { index ->
                val track = tracks[index]
                TrackRow(
                    track = track,
                    isCurrent = index == currentIndex,
                    onClick = { onTrackClick(index) },
                    onLongClick = { onTrackLongClick(track) },
                    isFavorite = favoriteIds.contains(track.id),
                    onToggleFavorite = onToggleFavorite?.let { { it(track.id) } },
                    isPlaying = isPlaying
                )
            }
        }
    }
}

// --- Playlists ---

@Composable
fun PlaylistsScreen(
    playlists: List<Playlist>,
    favoritesCount: Int,
    recentlyPlayedCount: Int,
    onCreateClick: () -> Unit,
    onOpenPlaylist: (Playlist) -> Unit,
    onOpenFavorites: () -> Unit,
    onOpenRecentlyPlayed: () -> Unit,
    onDeletePlaylist: (String) -> Unit
) {
    val strings = LocalAppStrings.current
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(strings.navPlaylists, style = MaterialTheme.typography.titleMedium)
            FilledTonalIconButton(
                onClick = onCreateClick,
                colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = PurpleAccent)
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Create playlist")
            }
        }

        // Favorites and Recently Played are built-in pseudo-playlists: always shown, never deletable.
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onOpenFavorites() }
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(PurpleAccent.copy(alpha = 0.25f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Star, contentDescription = null, tint = PurpleAccent)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(strings.favorites, style = MaterialTheme.typography.titleMedium)
                Text("$favoritesCount ${strings.songsCount}", style = MaterialTheme.typography.bodySmall)
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onOpenRecentlyPlayed() }
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(PurpleAccent.copy(alpha = 0.25f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.History, contentDescription = null, tint = PurpleAccent)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(strings.recentlyPlayed, style = MaterialTheme.typography.titleMedium)
                Text("$recentlyPlayedCount ${strings.songsCount}", style = MaterialTheme.typography.bodySmall)
            }
        }
        HorizontalDivider()

        if (playlists.isEmpty()) {
            EmptyView(strings.emptyPlaylists)
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(count = playlists.size, key = { index -> playlists[index].id }) { index ->
                    val playlist = playlists[index]
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenPlaylist(playlist) }
                            .padding(horizontal = 20.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(PurpleAccent.copy(alpha = 0.25f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.QueueMusic, contentDescription = null, tint = PurpleAccent)
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(playlist.name, style = MaterialTheme.typography.titleMedium)
                            Text("${playlist.trackIds.size} ${strings.songsCount}", style = MaterialTheme.typography.bodySmall)
                        }
                        IconButton(onClick = { onDeletePlaylist(playlist.id) }) {
                            Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete", tint = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PlaylistDetailScreen(
    playlist: Playlist,
    tracks: List<Track>,
    currentIndex: Int,
    isPlaying: Boolean,
    onBack: () -> Unit,
    onTrackClick: (Int) -> Unit,
    onRemoveTrack: (Long) -> Unit,
    onRemoveTracks: (Set<Long>) -> Unit,
    onMoveTrack: (Long, Int) -> Unit
) {
    val strings = LocalAppStrings.current
    var selectedIds by remember(playlist.id) { mutableStateOf(setOf<Long>()) }
    val selectionMode = selectedIds.isNotEmpty()

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (selectionMode) {
                IconButton(onClick = { selectedIds = emptySet() }) {
                    Icon(Icons.Filled.Close, contentDescription = strings.cancelSelection)
                }
                Text(
                    strings.selectedCount.format(selectedIds.size),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = {
                    onRemoveTracks(selectedIds)
                    selectedIds = emptySet()
                }) {
                    Icon(Icons.Filled.DeleteOutline, contentDescription = strings.deleteSelected)
                }
            } else {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                }
                Text(playlist.name, style = MaterialTheme.typography.titleMedium)
            }
        }

        if (tracks.isEmpty()) {
            EmptyView(strings.emptyPlaylistDetail)
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(count = tracks.size, key = { index -> tracks[index].id }) { index ->
                    val track = tracks[index]
                    val isSelected = selectedIds.contains(track.id)
                    TrackRow(
                        track = track,
                        isCurrent = index == currentIndex,
                        onClick = {
                            if (selectionMode) {
                                selectedIds = if (isSelected) selectedIds - track.id else selectedIds + track.id
                            } else {
                                onTrackClick(index)
                            }
                        },
                        onLongClick = { selectedIds = selectedIds + track.id },
                        isPlaying = isPlaying,
                        trailing = {
                            if (selectionMode) {
                                Checkbox(
                                    checked = isSelected,
                                    onCheckedChange = { checked ->
                                        selectedIds = if (checked) selectedIds + track.id else selectedIds - track.id
                                    },
                                    colors = CheckboxDefaults.colors(checkedColor = PurpleAccent)
                                )
                            } else {
                                Row {
                                    IconButton(onClick = { onMoveTrack(track.id, -1) }, enabled = index > 0) {
                                        Icon(Icons.Filled.KeyboardArrowUp, contentDescription = "Move up", tint = if (index > 0) Color.Gray else Color.DarkGray)
                                    }
                                    IconButton(onClick = { onMoveTrack(track.id, 1) }, enabled = index < tracks.size - 1) {
                                        Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Move down", tint = if (index < tracks.size - 1) Color.Gray else Color.DarkGray)
                                    }
                                    IconButton(onClick = { onRemoveTrack(track.id) }) {
                                        Icon(Icons.Filled.Close, contentDescription = "Remove", tint = Color.Gray)
                                    }
                                }
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun FavoritesDetailScreen(
    tracks: List<Track>,
    currentIndex: Int,
    strings: AppStrings,
    isPlaying: Boolean,
    onBack: () -> Unit,
    onTrackClick: (Int) -> Unit,
    onToggleFavorite: (Long) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(strings.favorites, style = MaterialTheme.typography.titleMedium)
        }

        if (tracks.isEmpty()) {
            EmptyView(strings.emptyFavorites)
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(count = tracks.size, key = { index -> tracks[index].id }) { index ->
                    val track = tracks[index]
                    TrackRow(
                        track = track,
                        isCurrent = index == currentIndex,
                        onClick = { onTrackClick(index) },
                        isFavorite = true,
                        onToggleFavorite = { onToggleFavorite(track.id) },
                        isPlaying = isPlaying
                    )
                }
            }
        }
    }
}

@Composable
fun RecentlyPlayedDetailScreen(
    tracks: List<Track>,
    currentIndex: Int,
    strings: AppStrings,
    favoriteIds: Set<Long>,
    isPlaying: Boolean,
    onBack: () -> Unit,
    onTrackClick: (Int) -> Unit,
    onToggleFavorite: (Long) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(strings.recentlyPlayed, style = MaterialTheme.typography.titleMedium)
        }

        if (tracks.isEmpty()) {
            EmptyView(strings.emptyRecentlyPlayed)
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(count = tracks.size, key = { index -> tracks[index].id }) { index ->
                    val track = tracks[index]
                    TrackRow(
                        track = track,
                        isCurrent = index == currentIndex,
                        onClick = { onTrackClick(index) },
                        isFavorite = favoriteIds.contains(track.id),
                        onToggleFavorite = { onToggleFavorite(track.id) },
                        isPlaying = isPlaying
                    )
                }
            }
        }
    }
}

@Composable
fun AddToPlaylistDialog(
    track: Track,
    playlists: List<Playlist>,
    strings: AppStrings,
    onDismiss: () -> Unit,
    onToggle: (playlistId: String, alreadyIn: Boolean) -> Unit,
    onCreateNew: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(strings.addToPlaylist) },
        text = {
            Column {
                Text(track.title, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(modifier = Modifier.height(12.dp))
                if (playlists.isEmpty()) {
                    Text(strings.emptyPlaylists, style = MaterialTheme.typography.bodyMedium)
                } else {
                    playlists.forEach { playlist ->
                        val alreadyIn = playlist.trackIds.contains(track.id)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onToggle(playlist.id, alreadyIn) }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = alreadyIn,
                                onCheckedChange = { onToggle(playlist.id, alreadyIn) },
                                colors = CheckboxDefaults.colors(checkedColor = PurpleAccent)
                            )
                            Text(playlist.name)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                TextButton(onClick = onCreateNew) {
                    Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(strings.createPlaylist)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(strings.close) }
        }
    )
}

@Composable
fun CreatePlaylistDialog(strings: AppStrings, onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(strings.createPlaylist) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text(strings.playlistName) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = PurpleAccent)
            )
        },
        confirmButton = {
            TextButton(onClick = { onCreate(name) }, enabled = name.isNotBlank()) {
                Text(strings.create)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(strings.cancel) }
        }
    )
}

@Composable
fun EditTrackDialog(track: Track, onDismiss: () -> Unit, onSave: (title: String, artist: String) -> Unit) {
    var title by remember(track.id) { mutableStateOf(track.title) }
    var artist by remember(track.id) { mutableStateOf(track.artist) }
    val strings = LocalAppStrings.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(strings.editTrackInfo) },
        text = {
            Column {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text(strings.editTitleLabel) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = PurpleAccent)
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = artist,
                    onValueChange = { artist = it },
                    label = { Text(strings.editArtistLabel) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = PurpleAccent)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(title, artist) }, enabled = title.isNotBlank()) {
                Text(strings.save)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(strings.cancel) }
        }
    )
}

// --- Settings (language, sleep timer, equalizer) ---

@Composable
fun SettingsScreen(viewModel: PlayerViewModel, state: PlayerUiState) {
    val strings = LocalAppStrings.current
    val scroll = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(20.dp)
    ) {
        Text(strings.settingsTitle, style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(20.dp))

        // Language
        Text(strings.languageLabel, style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            FilterChip(
                selected = state.language == AppLanguage.FA,
                onClick = { viewModel.setLanguage(AppLanguage.FA) },
                label = { Text(strings.persian) },
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PurpleAccent)
            )
            Spacer(modifier = Modifier.width(10.dp))
            FilterChip(
                selected = state.language == AppLanguage.EN,
                onClick = { viewModel.setLanguage(AppLanguage.EN) },
                label = { Text(strings.english) },
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PurpleAccent)
            )
        }

        Spacer(modifier = Modifier.height(28.dp))
        HorizontalDivider()
        Spacer(modifier = Modifier.height(20.dp))

        // Theme
        Text(strings.themeLabel, style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            FilterChip(
                selected = state.darkMode,
                onClick = { viewModel.setDarkMode(true) },
                label = { Text(strings.darkMode) },
                leadingIcon = { Icon(Icons.Filled.DarkMode, contentDescription = null, modifier = Modifier.size(18.dp)) },
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PurpleAccent)
            )
            Spacer(modifier = Modifier.width(10.dp))
            FilterChip(
                selected = !state.darkMode,
                onClick = { viewModel.setDarkMode(false) },
                label = { Text(strings.lightMode) },
                leadingIcon = { Icon(Icons.Filled.LightMode, contentDescription = null, modifier = Modifier.size(18.dp)) },
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PurpleAccent)
            )
        }

        Spacer(modifier = Modifier.height(28.dp))
        HorizontalDivider()
        Spacer(modifier = Modifier.height(20.dp))

        // Crossfade
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(strings.crossfadeLabel, style = MaterialTheme.typography.titleMedium)
                Text(strings.crossfadeDescription, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            }
            Switch(
                checked = state.crossfadeEnabled,
                onCheckedChange = { viewModel.setCrossfadeEnabled(it) },
                colors = SwitchDefaults.colors(checkedTrackColor = PurpleAccent)
            )
        }

        Spacer(modifier = Modifier.height(28.dp))
        HorizontalDivider()
        Spacer(modifier = Modifier.height(20.dp))

        // Sleep timer
        Text(strings.sleepTimerTitle, style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(8.dp))
        if (state.sleepTimerMinutesLeft != null) {
            Text(
                strings.sleepTimerActive.format(state.sleepTimerMinutesLeft),
                style = MaterialTheme.typography.bodyMedium,
                color = PurpleAccent
            )
            Spacer(modifier = Modifier.height(8.dp))
            TextButton(onClick = { viewModel.cancelSleepTimer() }) {
                Text(strings.sleepTimerOff)
            }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(15, 30, 45, 60).forEach { minutes ->
                    OutlinedButton(onClick = { viewModel.setSleepTimer(minutes) }) {
                        Text("$minutes")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))
        HorizontalDivider()
        Spacer(modifier = Modifier.height(20.dp))

        // Equalizer
        Text(strings.equalizerTitle, style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(12.dp))
        if (!state.equalizerReady) {
            Text("...", style = MaterialTheme.typography.bodySmall)
        } else {
            EqualizerControls(viewModel = viewModel, strings = strings, bassBoostStrength = state.bassBoostStrength)
        }
    }
}

@Composable
fun EqualizerControls(viewModel: PlayerViewModel, strings: AppStrings, bassBoostStrength: Int) {
    val bands = remember { viewModel.equalizerBands() }
    val presets = remember { viewModel.equalizerPresets() }

    if (bands.isEmpty()) {
        Text("—", style = MaterialTheme.typography.bodySmall)
        return
    }

    var levels by remember {
        mutableStateOf(bands.map { viewModel.getBandLevel(it.index).toFloat() })
    }

    Column {
        bands.forEachIndexed { i, band ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "${band.centerFreqHz}Hz",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.width(56.dp)
                )
                Slider(
                    value = levels[i],
                    onValueChange = { newValue ->
                        levels = levels.toMutableList().also { it[i] = newValue }
                        viewModel.setBandLevel(band.index, newValue.toInt().toShort())
                    },
                    valueRange = band.minLevel.toFloat()..band.maxLevel.toFloat(),
                    colors = SliderDefaults.colors(thumbColor = PurpleAccent, activeTrackColor = PurpleAccent),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(strings.bassBoost, style = MaterialTheme.typography.bodyMedium)
        Slider(
            value = bassBoostStrength.toFloat(),
            onValueChange = { viewModel.setBassBoost(it.toInt()) },
            valueRange = 0f..1000f,
            colors = SliderDefaults.colors(thumbColor = PurpleAccent, activeTrackColor = PurpleAccent)
        )

        if (presets.isNotEmpty()) {
            Spacer(modifier = Modifier.height(16.dp))
            Text(strings.presets, style = MaterialTheme.typography.bodyMedium)
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                presets.forEachIndexed { index, name ->
                    OutlinedButton(onClick = {
                        viewModel.useEqualizerPreset(index)
                        levels = bands.map { viewModel.getBandLevel(it.index).toFloat() }
                    }) {
                        Text(name)
                    }
                }
            }
        }
    }
}

@Composable
fun NowPlayingBar(
    track: Track,
    isPlaying: Boolean,
    positionMs: Long,
    durationMs: Long,
    shuffleEnabled: Boolean,
    repeatMode: Int,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Long) -> Unit,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    onOpenFullPlayer: () -> Unit
) {
    val context = LocalContext.current
    var artwork by remember(track.id) { mutableStateOf(AlbumArtProvider.peek(track.id)) }

    LaunchedEffect(track.id) {
        if (artwork != null) return@LaunchedEffect
        artwork = AlbumArtProvider.getArt(context, track)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.clickable { onOpenFullPlayer() }
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.DarkGray),
                contentAlignment = Alignment.Center
            ) {
                val art = artwork
                if (art != null) {
                    Image(
                        bitmap = art.asImageBitmap(),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(Icons.Filled.MusicNote, contentDescription = null, tint = Color.Gray)
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(track.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(track.artist, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        var isDraggingSeek by remember { mutableStateOf(false) }
        var seekDragValue by remember { mutableStateOf(0f) }
        val seekSliderValue = if (isDraggingSeek) {
            seekDragValue
        } else {
            if (durationMs > 0) positionMs.toFloat() / durationMs.toFloat() else 0f
        }

        Slider(
            value = seekSliderValue,
            onValueChange = { fraction ->
                isDraggingSeek = true
                seekDragValue = fraction
            },
            onValueChangeFinished = {
                onSeek((seekDragValue * durationMs).toLong())
                isDraggingSeek = false
            },
            colors = SliderDefaults.colors(thumbColor = PurpleAccent, activeTrackColor = PurpleAccent)
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            val displayedPositionMs = if (isDraggingSeek) (seekDragValue * durationMs).toLong() else positionMs
            Text(formatTime(displayedPositionMs), style = MaterialTheme.typography.bodySmall)
            Text(formatTime(durationMs), style = MaterialTheme.typography.bodySmall)
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onToggleShuffle) {
                Icon(
                    Icons.Filled.Shuffle,
                    contentDescription = "Shuffle",
                    tint = if (shuffleEnabled) PurpleAccent else Color.Gray
                )
            }
            IconButton(onClick = onPrevious) {
                Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous", modifier = Modifier.size(36.dp))
            }
            Spacer(modifier = Modifier.width(8.dp))
            val miniGlowTransition = rememberInfiniteTransition(label = "miniPlayGlow")
            val miniGlowScale by miniGlowTransition.animateFloat(
                initialValue = 1f,
                targetValue = 1.3f,
                animationSpec = infiniteRepeatable(animation = tween(900, easing = FastOutSlowInEasing), repeatMode = RepeatMode.Reverse),
                label = "miniGlowScale"
            )
            Box(contentAlignment = Alignment.Center) {
                androidx.compose.animation.AnimatedVisibility(
                    visible = isPlaying,
                    enter = fadeIn(tween(300)) + scaleIn(tween(300), initialScale = 0.7f),
                    exit = fadeOut(tween(450)) + scaleOut(tween(450), targetScale = 0.7f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .scale(miniGlowScale)
                            .clip(CircleShape)
                            .background(PurpleAccent.copy(alpha = 0.35f))
                    )
                }
                FilledIconButton(
                    onClick = onPlayPause,
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = PurpleAccent),
                    modifier = Modifier.size(56.dp)
                ) {
                    AnimatedContent(
                        targetState = isPlaying,
                        transitionSpec = { (scaleIn(tween(180)) + fadeIn(tween(180))) togetherWith (scaleOut(tween(120)) + fadeOut(tween(100))) },
                        label = "playPauseMini"
                    ) { playing ->
                        Icon(
                            if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = "Play/Pause",
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(onClick = onNext) {
                Icon(Icons.Filled.SkipNext, contentDescription = "Next", modifier = Modifier.size(36.dp))
            }
            IconButton(onClick = onCycleRepeat) {
                Icon(
                    imageVector = if (repeatMode == 1) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                    contentDescription = "Repeat",
                    tint = if (repeatMode != 0) PurpleAccent else Color.Gray
                )
            }
        }
    }
}

@Composable
fun FullPlayerScreen(
    track: Track,
    isPlaying: Boolean,
    positionMs: Long,
    durationMs: Long,
    isFavorite: Boolean,
    shuffleEnabled: Boolean,
    repeatMode: Int,
    showLyrics: Boolean,
    lyricsText: String?,
    lyricsLoading: Boolean,
    onClose: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Long) -> Unit,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    onToggleFavorite: () -> Unit,
    onOpenEqualizer: () -> Unit,
    onEditTrack: () -> Unit,
    onToggleLyrics: () -> Unit
) {
    val context = LocalContext.current
    var artwork by remember(track.id) { mutableStateOf(AlbumArtProvider.peekHighRes(track.id)) }

    LaunchedEffect(track.id) {
        if (artwork != null) return@LaunchedEffect
        artwork = AlbumArtProvider.getHighResArt(context, track)
    }

    // A manual frame-driven rotation (instead of an always-running infinite
    // transition) so that pausing genuinely freezes the disc at its current
    // angle, and resuming continues smoothly from exactly that angle —
    // rather than snapping to 0 on pause and jumping elsewhere on resume.
    var rotation by remember { mutableStateOf(0f) }
    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            var lastFrameNanos = withFrameNanos { it }
            while (true) {
                val frameNanos = withFrameNanos { it }
                val deltaSeconds = (frameNanos - lastFrameNanos) / 1_000_000_000f
                lastFrameNanos = frameNanos
                val degreesPerSecond = 360f / 9f // one full turn every 9 seconds
                rotation = (rotation + deltaSeconds * degreesPerSecond) % 360f
            }
        }
        // When isPlaying becomes false, this effect is cancelled right here,
        // and `rotation` simply keeps whatever value it last had — frozen.
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 24.dp, vertical = 16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) {
                Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Close", modifier = Modifier.size(32.dp))
            }
            Row {
                IconButton(onClick = onEditTrack) {
                    Icon(Icons.Filled.Edit, contentDescription = "Edit info")
                }
                IconButton(onClick = onToggleLyrics) {
                    Icon(
                        Icons.Filled.Subtitles,
                        contentDescription = "Lyrics",
                        tint = if (showLyrics) PurpleAccent else LocalContentColor.current
                    )
                }
                IconButton(onClick = onOpenEqualizer) {
                    Icon(Icons.Filled.Tune, contentDescription = "Equalizer")
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        val vinylGlowTransition = rememberInfiniteTransition(label = "vinylGlow")
        val vinylGlowScale by vinylGlowTransition.animateFloat(
            initialValue = 1f,
            targetValue = 1.06f,
            animationSpec = infiniteRepeatable(animation = tween(1500, easing = FastOutSlowInEasing), repeatMode = RepeatMode.Reverse),
            label = "vinylGlowScale"
        )
        val vinylGlowHue by vinylGlowTransition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(animation = tween(4000, easing = LinearEasing), repeatMode = RepeatMode.Reverse),
            label = "vinylGlowHue"
        )
        val vinylGlowColor = androidx.compose.ui.graphics.lerp(PurpleAccent, Color(0xFFFF4FD8), vinylGlowHue)

        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxWidth()) {
            androidx.compose.animation.AnimatedVisibility(
                visible = isPlaying,
                enter = fadeIn(tween(400)) + scaleIn(tween(400), initialScale = 0.85f),
                exit = fadeOut(tween(600)) + scaleOut(tween(600), targetScale = 0.85f)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.82f)
                        .aspectRatio(1f)
                        .scale(vinylGlowScale)
                        .clip(CircleShape)
                        .background(vinylGlowColor.copy(alpha = 0.35f))
                )
            }
        Box(
            modifier = Modifier
                .fillMaxWidth(0.82f)
                .aspectRatio(1f)
                .clip(CircleShape)
                .background(Color.DarkGray),
            contentAlignment = Alignment.Center
        ) {
            val art = artwork
            if (art != null) {
                Image(
                    bitmap = art.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(CircleShape)
                        .rotate(rotation)
                )
            } else {
                Icon(
                    Icons.Filled.MusicNote,
                    contentDescription = null,
                    tint = Color.Gray,
                    modifier = Modifier.size(96.dp)
                )
            }
            // A small centre "spindle hole" like a real vinyl record —
            // this is also what makes the rotation read as a disc instead
            // of just a spinning square with rounded edges.
            Box(
                modifier = Modifier
                    .size(18.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.background)
            )
        }
        }

        Spacer(modifier = Modifier.height(28.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    track.title,
                    style = MaterialTheme.typography.titleLarge,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    track.artist,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(onClick = onToggleFavorite) {
                val starScale by animateFloatAsState(
                    targetValue = if (isFavorite) 1.15f else 1f,
                    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
                    label = "favoriteScaleFull"
                )
                Icon(
                    imageVector = if (isFavorite) Icons.Filled.Star else Icons.Filled.StarBorder,
                    contentDescription = "Favorite",
                    tint = if (isFavorite) PurpleAccent else Color.Gray,
                    modifier = Modifier
                        .size(28.dp)
                        .scale(starScale)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        var isDraggingFullSeek by remember { mutableStateOf(false) }
        var fullSeekDragValue by remember { mutableStateOf(0f) }
        val fullSeekSliderValue = if (isDraggingFullSeek) {
            fullSeekDragValue
        } else {
            if (durationMs > 0) positionMs.toFloat() / durationMs.toFloat() else 0f
        }

        Slider(
            value = fullSeekSliderValue,
            onValueChange = { fraction ->
                isDraggingFullSeek = true
                fullSeekDragValue = fraction
            },
            onValueChangeFinished = {
                onSeek((fullSeekDragValue * durationMs).toLong())
                isDraggingFullSeek = false
            },
            colors = SliderDefaults.colors(thumbColor = PurpleAccent, activeTrackColor = PurpleAccent)
        )
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            val displayedFullPositionMs = if (isDraggingFullSeek) (fullSeekDragValue * durationMs).toLong() else positionMs
            Text(formatTime(displayedFullPositionMs), style = MaterialTheme.typography.bodySmall)
            Text(formatTime(durationMs), style = MaterialTheme.typography.bodySmall)
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onToggleShuffle) {
                Icon(
                    Icons.Filled.Shuffle,
                    contentDescription = "Shuffle",
                    tint = if (shuffleEnabled) PurpleAccent else Color.Gray
                )
            }
            IconButton(onClick = onPrevious) {
                Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous", modifier = Modifier.size(40.dp))
            }
            val glowTransition = rememberInfiniteTransition(label = "playGlow")
            val glowScale by glowTransition.animateFloat(
                initialValue = 1f,
                targetValue = 1.35f,
                animationSpec = infiniteRepeatable(animation = tween(900, easing = FastOutSlowInEasing), repeatMode = RepeatMode.Reverse),
                label = "glowScale"
            )
            Box(contentAlignment = Alignment.Center) {
                androidx.compose.animation.AnimatedVisibility(
                    visible = isPlaying,
                    enter = fadeIn(tween(300)) + scaleIn(tween(300), initialScale = 0.7f),
                    exit = fadeOut(tween(450)) + scaleOut(tween(450), targetScale = 0.7f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .scale(glowScale)
                            .clip(CircleShape)
                            .background(PurpleAccent.copy(alpha = 0.35f))
                    )
                }
                FilledIconButton(
                    onClick = onPlayPause,
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = PurpleAccent),
                    modifier = Modifier.size(72.dp)
                ) {
                    AnimatedContent(
                        targetState = isPlaying,
                        transitionSpec = { (scaleIn(tween(200)) + fadeIn(tween(200))) togetherWith (scaleOut(tween(140)) + fadeOut(tween(110))) },
                        label = "playPauseFull"
                    ) { playing ->
                        Icon(
                            if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = "Play/Pause",
                            modifier = Modifier.size(40.dp)
                        )
                    }
                }
            }
            IconButton(onClick = onNext) {
                Icon(Icons.Filled.SkipNext, contentDescription = "Next", modifier = Modifier.size(40.dp))
            }
            IconButton(onClick = onCycleRepeat) {
                Icon(
                    imageVector = if (repeatMode == 1) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                    contentDescription = "Repeat",
                    tint = if (repeatMode != 0) PurpleAccent else Color.Gray
                )
            }
        }

        AnimatedVisibility(visible = showLyrics) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp)
                    .heightIn(max = 160.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                val strings = LocalAppStrings.current
                Text(strings.lyricsTitle, style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(6.dp))
                when {
                    lyricsLoading -> Text(strings.loadingLyrics, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    lyricsText != null -> Text(lyricsText, style = MaterialTheme.typography.bodyMedium)
                    else -> Text(strings.noLyricsFound, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                }
            }
        }
    }
}

fun formatTime(ms: Long): String {
    if (ms <= 0) return "0:00"
    val minutes = TimeUnit.MILLISECONDS.toMinutes(ms)
    val seconds = TimeUnit.MILLISECONDS.toSeconds(ms) % 60
    return String.format("%d:%02d", minutes, seconds)
}
