package com.opusplayer.app

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

data class TrackOverride(val title: String, val artist: String)

/**
 * Lets someone fix a wrong title/artist shown in the app without touching
 * the actual audio file on disk (real ID3/Vorbis tag writing is a much
 * bigger, riskier undertaking across every format we support). This is
 * purely a local "display name" override layered on top of what MediaStore
 * reports.
 */
object TrackOverridesRepository {
    private const val PREFS_NAME = "opus_player_overrides"
    private const val KEY_OVERRIDES = "overrides_json"

    private val gson = Gson()

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun loadOverrides(context: Context): Map<Long, TrackOverride> {
        val json = prefs(context).getString(KEY_OVERRIDES, null) ?: return emptyMap()
        val type = object : TypeToken<Map<String, TrackOverride>>() {}.type
        return try {
            val raw: Map<String, TrackOverride> = gson.fromJson(json, type) ?: emptyMap()
            raw.mapKeys { it.key.toLong() }
        } catch (_: Exception) {
            emptyMap()
        }
    }

    fun setOverride(context: Context, trackId: Long, title: String, artist: String): Map<Long, TrackOverride> {
        val current = loadOverrides(context).toMutableMap()
        current[trackId] = TrackOverride(title.trim(), artist.trim())
        save(context, current)
        return current
    }

    fun clearOverride(context: Context, trackId: Long): Map<Long, TrackOverride> {
        val current = loadOverrides(context).toMutableMap()
        current.remove(trackId)
        save(context, current)
        return current
    }

    private fun save(context: Context, overrides: Map<Long, TrackOverride>) {
        val stringKeyed = overrides.mapKeys { it.key.toString() }
        prefs(context).edit().putString(KEY_OVERRIDES, gson.toJson(stringKeyed)).apply()
    }
}
