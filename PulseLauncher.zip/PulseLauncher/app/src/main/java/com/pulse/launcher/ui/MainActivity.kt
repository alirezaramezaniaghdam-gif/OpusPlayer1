package com.pulse.launcher.ui

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.pulse.launcher.R
import com.pulse.launcher.data.AppRepository
import com.pulse.launcher.data.PrefsManager

class MainActivity : AppCompatActivity() {

    private lateinit var homePager: ViewPager2
    private lateinit var pageIndicator: LinearLayout
    private lateinit var gestureDetector: GestureDetector
    private lateinit var scaleDetector: ScaleGestureDetector
    private var scaleAccumulated = 1.0f

    private val SWIPE_UP_VELOCITY_THRESHOLD = -1800f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        homePager = findViewById(R.id.homePager)
        pageIndicator = findViewById(R.id.pageIndicator)

        loadHomeApps()

        gestureDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(
                e1: MotionEvent?,
                e2: MotionEvent,
                velocityX: Float,
                velocityY: Float
            ): Boolean {
                val deltaY = e2.y - (e1?.y ?: e2.y)
                val deltaX = e2.x - (e1?.x ?: e2.x)
                if (velocityY < SWIPE_UP_VELOCITY_THRESHOLD && kotlin.math.abs(deltaY) > kotlin.math.abs(deltaX)) {
                    openDrawer()
                    return true
                }
                return false
            }

            // Long-press anywhere on the home screen opens Settings
            override fun onLongPress(e: MotionEvent) {
                startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
            }
        })

        scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                scaleAccumulated *= detector.scaleFactor
                return true
            }

            override fun onScaleEnd(detector: ScaleGestureDetector) {
                val current = PrefsManager.getGridColumns(this@MainActivity)
                // Pinch in (< 1) increases columns (denser grid), pinch out (> 1) decreases columns
                val delta = when {
                    scaleAccumulated < 0.85f -> 1
                    scaleAccumulated > 1.15f -> -1
                    else -> 0
                }
                if (delta != 0) {
                    PrefsManager.setGridColumns(this@MainActivity, current + delta)
                    loadHomeApps()
                }
                scaleAccumulated = 1.0f
            }
        })
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        gestureDetector.onTouchEvent(ev)
        scaleDetector.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    private fun openDrawer() {
        startActivity(Intent(this, AppDrawerActivity::class.java))
        overridePendingTransition(R.anim.slide_up_in, 0)
    }

    override fun onResume() {
        super.onResume()
        // Apps can change (installed/uninstalled) while the drawer or another app was in front
        loadHomeApps()
    }

    private var pageChangeCallbackRegistered = false

    private fun loadHomeApps() {
        val apps = AppRepository.getLaunchableApps(this)
        homePager.adapter = HomePagerAdapter(this, apps)
        buildPageIndicator(homePager.adapter!!.itemCount)

        if (!pageChangeCallbackRegistered) {
            pageChangeCallbackRegistered = true
            homePager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    val themeColor = PrefsManager.getThemeColor(this@MainActivity)
                    for (i in 0 until pageIndicator.childCount) {
                        val dot = pageIndicator.getChildAt(i)
                        dot.setBackgroundColor(if (i == position) themeColor else Color.argb(80, 255, 255, 255))
                    }
                }
            })
        }
    }

    private fun buildPageIndicator(count: Int) {
        pageIndicator.removeAllViews()
        val themeColor = PrefsManager.getThemeColor(this)
        for (i in 0 until count) {
            val dot = ImageView(this)
            val size = (8 * resources.displayMetrics.density).toInt()
            val params = LinearLayout.LayoutParams(size, size)
            params.marginStart = (4 * resources.displayMetrics.density).toInt()
            params.marginEnd = (4 * resources.displayMetrics.density).toInt()
            dot.layoutParams = params
            dot.setBackgroundColor(if (i == 0) themeColor else Color.argb(80, 255, 255, 255))
            dot.tag = "dot_$i"
            pageIndicator.addView(dot)
        }
    }
}
