package com.pulse.launcher.ui

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.pulse.launcher.R
import com.pulse.launcher.data.AppInfo
import com.pulse.launcher.data.AppRepository

class AppDrawerAdapter(
    private val context: Context,
    private val allApps: List<AppInfo>
) : RecyclerView.Adapter<AppDrawerAdapter.VH>() {

    private var shown: List<AppInfo> = allApps

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val icon: android.widget.ImageView = view.findViewById(R.id.rowIcon)
        val label: android.widget.TextView = view.findViewById(R.id.rowLabel)
    }

    fun filter(query: String) {
        shown = if (query.isBlank()) {
            allApps
        } else {
            allApps.filter { it.label.contains(query, ignoreCase = true) }
        }
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_app_drawer_row, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = shown[position]
        holder.icon.setImageDrawable(app.icon)
        holder.label.text = app.label
        holder.itemView.setOnClickListener {
            AppRepository.launch(context, app)
        }
    }

    override fun getItemCount() = shown.size
}
