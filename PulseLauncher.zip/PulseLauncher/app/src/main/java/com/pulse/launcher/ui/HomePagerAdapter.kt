package com.pulse.launcher.ui

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.pulse.launcher.R
import com.pulse.launcher.data.AppInfo
import com.pulse.launcher.data.PrefsManager

class HomePagerAdapter(
    private val context: Context,
    apps: List<AppInfo>
) : RecyclerView.Adapter<HomePagerAdapter.PageVH>() {

    private val columns = PrefsManager.getGridColumns(context)
    private val perPage = columns * 5 // 5 rows per page
    private val pages: List<List<AppInfo>> = apps.chunked(perPage).ifEmpty { listOf(emptyList()) }

    class PageVH(val recycler: RecyclerView) : RecyclerView.ViewHolder(recycler)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageVH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.page_home_grid, parent, false) as RecyclerView
        return PageVH(view)
    }

    override fun onBindViewHolder(holder: PageVH, position: Int) {
        holder.recycler.layoutManager = GridLayoutManager(context, columns)
        holder.recycler.adapter = AppGridAdapter(context, pages[position])
    }

    override fun getItemCount() = pages.size
}
