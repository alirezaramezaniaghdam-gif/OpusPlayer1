package com.pulse.launcher.ui

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.pulse.launcher.R
import com.pulse.launcher.data.AppRepository

class AppDrawerActivity : AppCompatActivity() {

    private lateinit var adapter: AppDrawerAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app_drawer)

        val apps = AppRepository.getLaunchableApps(this)
        adapter = AppDrawerAdapter(this, apps)

        val recycler = findViewById<RecyclerView>(R.id.drawerRecycler)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        val searchBox = findViewById<EditText>(R.id.searchBox)
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                adapter.filter(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(0, R.anim.slide_down_out)
    }

    override fun onBackPressed() {
        super.onBackPressed()
    }
}
