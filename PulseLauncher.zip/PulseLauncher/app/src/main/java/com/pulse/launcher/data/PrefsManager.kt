package com.pulse.launcher.data

import android.content.Context

object PrefsManager {
    private const val PREFS = "pulse_prefs"
    private const val KEY_THEME_COLOR = "theme_color"
    private const val KEY_ICON_STYLE = "icon_style"
    private const val KEY_FONT = "font_choice"
    private const val KEY_GRID_COLUMNS = "grid_columns"
    private const val KEY_ANIM_LEVEL = "anim_level"

    // Icon styles
    const val ICON_STYLE_ROUND = 0
    const val ICON_STYLE_SQUARE = 1
    const val ICON_STYLE_PILL_BG = 2

    // Font choices (index into Typefaces list)
    const val FONT_DEFAULT = 0
    const val FONT_SERIF = 1
    const val FONT_MONOSPACE = 2
    const val FONT_SANS_BOLD = 3

    // Animation intensity
    const val ANIM_SUBTLE = 0
    const val ANIM_NORMAL = 1
    const val ANIM_MAXIMUM = 2

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getThemeColor(context: Context): Int =
        prefs(context).getInt(KEY_THEME_COLOR, 0xFFB388FF.toInt())

    fun setThemeColor(context: Context, color: Int) {
        prefs(context).edit().putInt(KEY_THEME_COLOR, color).apply()
    }

    fun getIconStyle(context: Context): Int =
        prefs(context).getInt(KEY_ICON_STYLE, ICON_STYLE_PILL_BG)

    fun setIconStyle(context: Context, style: Int) {
        prefs(context).edit().putInt(KEY_ICON_STYLE, style).apply()
    }

    fun getFontChoice(context: Context): Int =
        prefs(context).getInt(KEY_FONT, FONT_DEFAULT)

    fun setFontChoice(context: Context, font: Int) {
        prefs(context).edit().putInt(KEY_FONT, font).apply()
    }

    fun getGridColumns(context: Context): Int =
        prefs(context).getInt(KEY_GRID_COLUMNS, 4)

    fun setGridColumns(context: Context, columns: Int) {
        prefs(context).edit().putInt(KEY_GRID_COLUMNS, columns.coerceIn(3, 6)).apply()
    }

    fun getAnimLevel(context: Context): Int =
        prefs(context).getInt(KEY_ANIM_LEVEL, ANIM_MAXIMUM)

    fun setAnimLevel(context: Context, level: Int) {
        prefs(context).edit().putInt(KEY_ANIM_LEVEL, level).apply()
    }
}
