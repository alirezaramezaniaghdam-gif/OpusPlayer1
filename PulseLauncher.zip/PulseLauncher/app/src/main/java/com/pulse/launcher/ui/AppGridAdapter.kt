package com.pulse.launcher.ui

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import androidx.recyclerview.widget.RecyclerView
import com.pulse.launcher.R
import com.pulse.launcher.data.AppInfo
import com.pulse.launcher.data.AppRepository
import com.pulse.launcher.data.PrefsManager
import com.pulse.launcher.util.StyleUtil

class AppGridAdapter(
    private val context: Context,
    private var apps: List<AppInfo>
) : RecyclerView.Adapter<AppGridAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val icon: android.widget.ImageView = view.findViewById(R.id.appIcon)
        val label: android.widget.TextView = view.findViewById(R.id.appLabel)
        val frame: android.widget.FrameLayout = view.findViewById(R.id.iconFrame)
    }

    fun submitList(newApps: List<AppInfo>) {
        apps = newApps
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_app_icon, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = apps[position]
        holder.icon.setImageDrawable(app.icon)
        holder.label.text = app.label
        holder.label.typeface = StyleUtil.typefaceFor(PrefsManager.getFontChoice(context))

        // Icon style: round clip, square (no clip), or translucent pill background
        when (PrefsManager.getIconStyle(context)) {
            PrefsManager.ICON_STYLE_ROUND -> {
                holder.frame.background = null
                holder.icon.clipToOutline = true
            }
            PrefsManager.ICON_STYLE_SQUARE -> {
                holder.frame.background = null
            }
            else -> {
                holder.frame.setBackgroundResource(R.drawable.bg_icon_pill)
            }
        }

        holder.itemView.startAnimation(AnimationUtils.loadAnimation(context, R.anim.icon_pop))
        holder.itemView.setOnClickListener {
            AppRepository.launch(context, app)
        }
    }

    override fun getItemCount() = apps.size
}
