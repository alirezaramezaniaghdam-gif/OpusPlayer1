package com.pulse.launcher.util

import android.graphics.Typeface
import com.pulse.launcher.data.PrefsManager

object StyleUtil {

    fun typefaceFor(choice: Int): Typeface = when (choice) {
        PrefsManager.FONT_SERIF -> Typeface.SERIF
        PrefsManager.FONT_MONOSPACE -> Typeface.MONOSPACE
        PrefsManager.FONT_SANS_BOLD -> Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        else -> Typeface.DEFAULT
    }

    /** Duration multiplier so "animation intensity" actually changes how lively things feel. */
    fun animDurationMultiplier(level: Int): Float = when (level) {
        PrefsManager.ANIM_SUBTLE -> 0.5f
        PrefsManager.ANIM_MAXIMUM -> 1.6f
        else -> 1.0f
    }
}
