package com.pulse.launcher.ui

import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.pulse.launcher.R
import com.pulse.launcher.data.PrefsManager

class SettingsActivity : AppCompatActivity() {

    private val presetColors = listOf(
        "#B388FF".toColorInt(), "#FF4FA3".toColorInt(), "#1DE9B6".toColorInt(),
        "#FF9E40".toColorInt(), "#448AFF".toColorInt(), "#FF5252".toColorInt()
    )
    private val fontLabels = listOf("پیش‌فرض", "سریف", "مونواسپیس", "بولد")
    private var selectedColor: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        selectedColor = PrefsManager.getThemeColor(this)
        buildColorSwatches()
        setupIconStyle()
        setupFontSpinner()
        setupGridDensity()
        setupAnimLevel()

        findViewById<Button>(R.id.saveButton).setOnClickListener {
            PrefsManager.setThemeColor(this, selectedColor)
            finish()
        }
    }

    private fun buildColorSwatches() {
        val row = findViewById<LinearLayout>(R.id.colorSwatchRow)
        presetColors.forEach { color ->
            val swatch = View(this)
            val size = (40 * resources.displayMetrics.density).toInt()
            val params = LinearLayout.LayoutParams(size, size)
            params.marginEnd = (12 * resources.displayMetrics.density).toInt()
            swatch.layoutParams = params
            swatch.setBackgroundColor(color)
            swatch.alpha = if (color == selectedColor) 1.0f else 0.5f
            swatch.setOnClickListener {
                selectedColor = color
                for (i in 0 until row.childCount) {
                    row.getChildAt(i).alpha = 0.5f
                }
                swatch.alpha = 1.0f
            }
            row.addView(swatch)
        }
    }

    private fun setupIconStyle() {
        val group = findViewById<RadioGroup>(R.id.iconStyleGroup)
        val ids = listOf(R.id.iconStyleRound, R.id.iconStyleSquare, R.id.iconStylePill)
        group.check(ids[PrefsManager.getIconStyle(this)])
        group.setOnCheckedChangeListener { _, checkedId ->
            val style = ids.indexOf(checkedId)
            if (style >= 0) PrefsManager.setIconStyle(this, style)
        }
    }

    private fun setupFontSpinner() {
        val spinner = findViewById<Spinner>(R.id.fontSpinner)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, fontLabels)
        spinner.setSelection(PrefsManager.getFontChoice(this))
        spinner.post {
            spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                    PrefsManager.setFontChoice(this@SettingsActivity, position)
                }
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            }
        }
    }

    private fun setupGridDensity() {
        val label = findViewById<TextView>(R.id.gridDensityLabel)
        val seek = findViewById<SeekBar>(R.id.gridDensitySeek)
        val current = PrefsManager.getGridColumns(this)
        seek.progress = current - 3 // seekbar range 0..3 maps to columns 3..6
        label.text = getString(R.string.grid_density_label, current)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val columns = progress + 3
                label.text = getString(R.string.grid_density_label, columns)
                PrefsManager.setGridColumns(this@SettingsActivity, columns)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun setupAnimLevel() {
        val group = findViewById<RadioGroup>(R.id.animLevelGroup)
        val ids = listOf(R.id.animSubtle, R.id.animNormal, R.id.animMax)
        group.check(ids[PrefsManager.getAnimLevel(this)])
        group.setOnCheckedChangeListener { _, checkedId ->
            val level = ids.indexOf(checkedId)
            if (level >= 0) PrefsManager.setAnimLevel(this, level)
        }
    }

    private fun String.toColorInt(): Int = Color.parseColor(this)
}
