package com.example.noisevolume

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min

/**
 * Foreground service:
 * - Continuously samples the microphone.
 * - Converts amplitude to an ambient noise level in dBFS (relative, since
 *   there's no calibrated reference — absolute dB SPL isn't possible from
 *   a phone mic without hardware calibration, but relative tracking works
 *   perfectly for "louder around me -> louder in my headphones").
 * - Smooths the level over a rolling window (ignores short spikes: a cough,
 *   a door slam, a single loud word).
 * - Only moves the media volume when the smoothed level has drifted past a
 *   hysteresis band, and moves it one step at a time (never jumps straight
 *   to max/min), so it feels natural instead of jarring.
 */
class NoiseVolumeService : Service() {

    companion object {
        const val CHANNEL_ID = "noise_volume_channel"
        const val NOTIF_ID = 1

        const val ACTION_START = "com.example.noisevolume.START"
        const val ACTION_STOP = "com.example.noisevolume.STOP"

        // Tunable calibration constants
        const val SAMPLE_RATE = 16000
        const val WINDOW_MS = 2500L          // how much recent audio we average over
        const val UPDATE_INTERVAL_MS = 400L  // how often we re-evaluate
        const val HYSTERESIS_DB = 3.0         // ignore drift smaller than this
        const val QUIET_DBFS = -55.0          // ambient level mapped to MIN_VOLUME_PCT
        const val LOUD_DBFS = -15.0           // ambient level mapped to MAX_VOLUME_PCT
        const val MIN_VOLUME_PCT = 0.15
        const val MAX_VOLUME_PCT = 1.0
        const val MAX_STEP_PER_UPDATE = 1     // max stream-volume-index change per cycle
    }

    private var audioRecord: AudioRecord? = null
    private var recordingThread: Thread? = null
    @Volatile private var running = false

    private val rmsWindow = ArrayDeque<Double>()
    private var lastAppliedDb: Double? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            else -> startForegroundMonitoring()
        }
        return START_STICKY
    }

    private fun startForegroundMonitoring() {
        if (running) return
        createNotificationChannel()
        val notification = buildNotification("در حال گوش‌دادن به صدای محیط…")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, notification)
        }

        running = true
        recordingThread = Thread { recordLoop() }.apply { start() }
    }

    private fun recordLoop() {
        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuf <= 0) return

        val bufferSize = minBuf * 2
        val record = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )
        } catch (e: SecurityException) {
            stopSelf()
            return
        }

        if (record.state != AudioRecord.STATE_INITIALIZED) {
            stopSelf()
            return
        }

        audioRecord = record
        val chunk = ShortArray(bufferSize / 2)
        record.startRecording()

        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        var lastUpdate = 0L
        val windowMaxSamples = (WINDOW_MS / 50) // ~50ms per read cycle target

        while (running) {
            val read = record.read(chunk, 0, chunk.size)
            if (read > 0) {
                val rms = computeRms(chunk, read)
                val dbfs = amplitudeToDbfs(rms)
                rmsWindow.addLast(dbfs)
                while (rmsWindow.size > windowMaxSamples) rmsWindow.removeFirst()
            }

            val now = System.currentTimeMillis()
            if (now - lastUpdate >= UPDATE_INTERVAL_MS && rmsWindow.isNotEmpty()) {
                lastUpdate = now
                val avgDb = rmsWindow.average()
                maybeAdjustVolume(audioManager, avgDb)
            }
        }

        record.stop()
        record.release()
        audioRecord = null
    }

    private fun computeRms(buffer: ShortArray, length: Int): Double {
        var sum = 0.0
        for (i in 0 until length) {
            val sample = buffer[i].toDouble()
            sum += sample * sample
        }
        return kotlin.math.sqrt(sum / length)
    }

    private fun amplitudeToDbfs(rms: Double): Double {
        val ref = 32768.0
        val ratio = max(rms, 1.0) / ref
        return 20 * log10(ratio)
    }

    private fun maybeAdjustVolume(audioManager: AudioManager, avgDb: Double) {
        val prev = lastAppliedDb
        if (prev != null && abs(avgDb - prev) < HYSTERESIS_DB) {
            return // within the dead zone: don't touch the volume
        }
        lastAppliedDb = avgDb

        val clampedDb = avgDb.coerceIn(QUIET_DBFS, LOUD_DBFS)
        val t = (clampedDb - QUIET_DBFS) / (LOUD_DBFS - QUIET_DBFS) // 0..1
        val targetPct = MIN_VOLUME_PCT + t * (MAX_VOLUME_PCT - MIN_VOLUME_PCT)

        val maxIndex = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val currentIndex = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val targetIndex = (targetPct * maxIndex).toInt().coerceIn(0, maxIndex)

        val step = (targetIndex - currentIndex).coerceIn(-MAX_STEP_PER_UPDATE, MAX_STEP_PER_UPDATE)
        val newIndex = (currentIndex + step).coerceIn(0, maxIndex)

        if (newIndex != currentIndex) {
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, newIndex, 0)
            updateNotification("صدای محیط: ${"%.0f".format(avgDb)} dB نسبی → صدای پخش: $newIndex/$maxIndex")
        }
    }

    private fun buildNotification(text: String): Notification {
        val stopIntent = Intent(this, NoiseVolumeService::class.java).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("تنظیم خودکار صدا")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
            .setOngoing(true)
            .addAction(0, "توقف", stopPending)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(text))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "تنظیم خودکار صدا", NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        running = false
        recordingThread?.join(500)
        audioRecord?.let {
            try { it.stop() } catch (_: Exception) {}
            it.release()
        }
        super.onDestroy()
    }
}
