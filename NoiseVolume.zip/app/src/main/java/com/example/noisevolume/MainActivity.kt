package com.example.noisevolume

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private var isRunning = false

    private val requestMicPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startService() else {
            findViewById<TextView>(R.id.statusText).text =
                "برای کارکردن اپ، دسترسی میکروفون لازمه."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toggleButton = findViewById<Button>(R.id.toggleButton)
        toggleButton.setOnClickListener {
            if (!isRunning) {
                ensurePermissionThenStart()
            } else {
                stopService()
            }
        }
    }

    private fun ensurePermissionThenStart() {
        val hasPermission = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (hasPermission) {
            startService()
        } else {
            requestMicPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun startService() {
        val intent = Intent(this, NoiseVolumeService::class.java).apply {
            action = NoiseVolumeService.ACTION_START
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        isRunning = true
        findViewById<Button>(R.id.toggleButton).text = "خاموش کردن"
        findViewById<TextView>(R.id.statusText).text = "در حال کار… صدا رو با محیط تنظیم می‌کنه."
    }

    private fun stopService() {
        val intent = Intent(this, NoiseVolumeService::class.java).apply {
            action = NoiseVolumeService.ACTION_STOP
        }
        startService(intent)
        isRunning = false
        findViewById<Button>(R.id.toggleButton).text = "روشن کردن"
        findViewById<TextView>(R.id.statusText).text = "خاموش."
    }
}
